﻿using ReportMaker.Model;
using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace ReportMaker.Helpers
{
    //
    // Creates an angular/typescript files based on the parameters needed and the
    // report that is selected
    //
    public static class AngularGenerator
    {
        public static void GenerateAngularFromReportModel(string outputPath, ReportModel rm)
        {
            List<string> AngularLines = new List<string>();


            //Imports///////////////////////////////////////////////////////////////////////

            //Get Import Template File
            string[] ImportTemplate = File.ReadAllLines("Templates\\Angular\\Component\\Imports.txt");
            List<string> ImportList = new List<string>(ImportTemplate);

            //Find where to insert new services
            int ImportInsertIndex = 0;
            for(int i = 0; i < ImportList.Count; i++)
            {
                if(ImportList[i].Contains("Import Custom Services Here"))
                {
                    ImportInsertIndex = i + 1;
                    break;
                }
            }

            //Check what services need to be added
            for(int i = 0; i < rm.Parameters.Count; i++)
            {
                //If the parameter calls a usp method then it uses a service
                ParameterModel pm = rm.Parameters[i];
                if (pm.ParmQuery.Contains("usp") && !pm.ParamCaptionLeft.Contains("Image"))
                {
                    //Get the plain name of the parameter, ex. @SchoolID -> School
                    string pmNamePlain = pm.ParamCaptionLeft.Replace(" ", "").Replace("@", "").Replace("ID", "");
                    
                    //Create the line to add
                    string toAdd = "import { " + pmNamePlain + "Service } from '../../../shared/services/" + pmNamePlain.ToLower() + ".service'";

                    //Add the line to the list of lines
                    ImportList.Insert(ImportInsertIndex, toAdd);
                    ImportInsertIndex++;
                }

            }

            //Add imports to the main list
            AngularLines.AddRange(ImportList);


            //Component/////////////////////////////////////////////////////////////////////

            //Get Component Template
            string[] ComponentTemplate = File.ReadAllLines("Templates\\Angular\\Component\\Component.txt");
            List<string> ComponentList = new List<string>(ComponentTemplate);

            //Change the URL
            for(int i = 0; i < ComponentList.Count; i++)
            {
                if (ComponentList[i].Contains("custom"))
                {
                    ComponentList[i] = ComponentList[i].Replace("custom", rm.ReportName.Replace(" ", "").ToLower());
                }
            }

            //Add to main list
            AngularLines.AddRange(ComponentList);


            //Export Class//////////////////////////////////////////////////////////////////

            //Get template
            string[] ExportClassTemplate = File.ReadAllLines("Templates\\Angular\\Component\\Export_Class.txt");
            List<string> ExportClassList = new List<string>(ExportClassTemplate);

            //Change component name
            for(int i = 0; i < ExportClassList.Count; i++)
            {
                if (ExportClassList[i].Contains("CustomComponent"))
                {
                    ExportClassList[i] = ExportClassList[i].Replace("CustomComponent", rm.ReportName.Replace(" ", "") + "Component");
                }

            }


            //Add Custom services
            //Get Insert Index
            int ExportInsertIndex = 0;
            for (int i = 0; i < ExportClassList.Count; i++)
            {
                if (ExportClassList[i].Contains("Insert Custom Services Here"))
                {
                    ExportInsertIndex = i + 1;
                    break;
                }

            }

            //Go through parameters and see which have services to be added
            for(int i = 0; i < rm.Parameters.Count; i++)
            {
                ParameterModel pm = rm.Parameters[i];
                //If the parameter needs a service, insert it
                if (pm.ParmQuery.Contains("usp") && !pm.ParamCaptionLeft.Contains("Image"))
                {
                    string plainName = pm.ParamCaptionLeft.Replace("@", "").Replace("ID", "");
                    string toAdd = "        private " + plainName.ToLower() + "Service: " + plainName + "Service,";

                    ExportClassList.Insert(ExportInsertIndex, toAdd);
                }
            }

            //Add lines to main list
            AngularLines.AddRange(ExportClassList);


            //Report////////////////////////////////////////////////////////////////////////

            //Get the template
            string[] ReportTemplate = File.ReadAllLines("Templates\\Angular\\Component\\Report.txt");
            List<string> ReportList = new List<string>(ReportTemplate);

            //Find insert index
            int ReportInsertIndex = 0;
            for(int i = 0; i < ReportList.Count; i++)
            {
                if(ReportList[i].Contains("Insert Custom Parameters Here"))
                {
                    ReportInsertIndex = i + 1;
                    break;
                }
            }

            //Add parameters and set default values
            for(int i = 0; i < rm.Parameters.Count; i++)
            {
                ParameterModel pm = rm.Parameters[i];

                //Decide what default value the parameter should have
                string defaultVal = "";

                if(pm.DataType == "DM")
                {
                    defaultVal = "new Date()";
                }
                else if(pm.DataType == "INT")
                {
                    defaultVal = "0";
                }
                else if (pm.DataType == "STR")
                {
                    //If the parameter is a string, check if there is a default value for it
                    if (pm.DefaultVal.Contains("|"))
                    {
                        //Take the first value, or the whole thing up to the 1st |
                        //Ex: Academy|Grade|Homeroom|Name, just take Academy
                        int upTo = pm.DefaultVal.IndexOf("|");
                        defaultVal = pm.DefaultVal.Substring(0, upTo);
                    }
                    //Else give it ""
                    else
                    {
                        defaultVal = "\"\"";
                    }
                }



                string toAdd = "        " + pm.ParamCaptionLeft.Replace("@", "") + ": " + defaultVal + ",";
                ReportList.Insert(ReportInsertIndex, toAdd);
                ReportInsertIndex++;
            }

            AngularLines.AddRange(ReportList);

            //Set up lists//////////////////////////////////////////////////////////////////

            //Get Template File
            string[] ListInitTemplate = File.ReadAllLines("Templates\\Angular\\Component\\SetUpLists.txt");
            List<string> ListInitList = new List<string>(ListInitTemplate);

            //Get Insert Index
            int ListInitInsertIndex = 0;
            for(int i = 0; i < ListInitList.Count; i++)
            {
                if(ListInitList[i].Contains("Insert Custom Lists Here"))
                {
                    ListInitInsertIndex = i + 1;
                    break;
                }
            }

            //Go through parameters that use a list and add the lists
            for(int i = 0; i < rm.Parameters.Count; i++)
            {
                ParameterModel pm = rm.Parameters[i];
                
                //Check if the parameter uses a dynamically loaded list
                if (pm.ParmQuery.Contains("usp"))
                {
                    //If so initialize it
                    string toAdd = "    " + pm.ParamCaptionLeft.Replace("@","").Replace("ID","") + "List: any = []";

                    //Insert into list
                    ListInitList.Insert(ListInitInsertIndex, toAdd);
                    ListInitInsertIndex++;
                }

            }

            //Add to main
            AngularLines.AddRange(ListInitList);


            //Static lists//////////////////////////////////////////////////////////////////

            //Go Through parameters
            for (int i = 0; i < rm.Parameters.Count; i++)
            {
                //Check if the parameter uses a static list
                ParameterModel pm = rm.Parameters[i];
                //If it does then create one from the template
                Console.WriteLine("Checking {0}", pm.ParmQuery);
                if (pm.ParmQuery.Contains("|"))
                {
                    Console.WriteLine("{0} Contains |", pm.ParmQuery);
                    //Get Template File
                    string[] StaticListTemplate = File.ReadAllLines("Templates\\Angular\\Component\\StaticLists.txt");
                    List<string> StaticListList = new List<string>(StaticListTemplate);

                    //Change the list name
                    for(int x = 0; x < StaticListList.Count; x++)
                    {
                        if (StaticListList[x].Contains("CustomList"))
                        {
                            StaticListList[x] = StaticListList[x].Replace("CustomList", pm.ParamCaptionLeft.Replace("@", "").Replace("ID", "") + "List");
                        }
                    }

                    //Get the insert index
                    int StaticListInsertIndex = 0;
                    for (int x = 0; x < StaticListList.Count; x++)
                    {
                        if (StaticListList[x].Contains("Insert Custom List Items Here"))
                        {
                            StaticListInsertIndex = x + 1;/////
                            break;
                        }
                    }

                    //Add Options
                    //Turn each option into a value in a string array
                    string[] Vals = pm.ParmQuery.Split("|");

                    //Go through string array and add the item
                    for(int z = 0; z < Vals.Length; z++)
                    {

                        string toAdd1 = "        {";
                        string toAdd2 = "			" + pm.ParamCaptionLeft.Replace("@", "").Replace("ID","") + "Name: '" + Vals[z] + "'";
                        string toAdd3 = "        }";

                        if (z < Vals.Length - 1)
                        {
                            toAdd3 += ",";
                        }

                        Console.WriteLine("\n\n");
                        for(int h = 0; h < StaticListList.Count; h++)
                        {
                            Console.WriteLine(StaticListList[h]);
                        }

                        Console.WriteLine("\n\n");
                        Console.WriteLine("I = {0} Inserting:\n{1}\n{2}\n{3}\n\n", i, toAdd1, toAdd2, toAdd3);


                        StaticListList.Insert(StaticListInsertIndex, toAdd1);
                        StaticListInsertIndex++;
                        StaticListList.Insert(StaticListInsertIndex, toAdd2);
                        StaticListInsertIndex++;
                        StaticListList.Insert(StaticListInsertIndex, toAdd3);
                        StaticListInsertIndex++;
                    }


                    //Add list to main list
                    AngularLines.AddRange(StaticListList);

                    //Add a blank line
                    AngularLines.Add("");
                }
            }
            //Events////////////////////////////////////////////////////////////////////////

            //Skipped for now



            //NgOnit////////////////////////////////////////////////////////////////////////

            //Load template
            string[] InitTemplate = File.ReadAllLines("Templates\\Angular\\Component\\OnInit.txt");
            List<string> InitList = new List<string>(InitTemplate);

            //Get Insert Index
            int InitInsertIndex = 0;
            for(int i = 0; i < InitList.Count; i++)
            {
                if(InitList[i].Contains("Insert Custom Init Methods Here"))
                {
                    InitInsertIndex = i + 1;
                    break;
                }
            }

            //Go through parameters and add a loadCustomList() Method for each one with a custom list
            for(int i = 0; i < rm.Parameters.Count; i++)
            {
                //If the method has a custom list then add it
                ParameterModel pm = rm.Parameters[i];
                if (pm.ParmQuery.Contains("usp") && !pm.ParamCaptionLeft.Contains("Image"))
                {
                    string toAdd = "        this.load" + pm.ParamCaptionLeft.Replace("@","").Replace("ID","") + "List()";
                    InitList.Insert(InitInsertIndex, toAdd);
                    InitInsertIndex++;
                }
            }

            //Add to main
            AngularLines.AddRange(InitList);


            //Custom Load Lists/////////////////////////////////////////////////////////////

            //Go through the parameters
            for(int i = 0; i < rm.Parameters.Count; i++)
            {
                //If the program dynamically loads a list then add the method
                ParameterModel pm = rm.Parameters[i];
                if (pm.ParmQuery.Contains("usp") && !pm.ParamCaptionLeft.Contains("Image"))
                {
                    //Load template
                    string[] LoadMethodTemplate = File.ReadAllLines("Templates\\Angular\\Component\\LoadList.txt");
                    List<string> LoadMethodList = new List<string>(LoadMethodTemplate);

                    //Replace "Custom"
                    string parmName = pm.ParamCaptionLeft.Replace("@", "").Replace("ID", "");

                    for(int k = 0; k < LoadMethodList.Count; k++)
                    {
                        if (LoadMethodList[k].Contains("Custom"))
                        {
                            LoadMethodList[k] = LoadMethodList[k].Replace("Custom", parmName);
                        }
                        if (LoadMethodList[k].Contains("AAA"))
                        {
                            string lowerName = parmName.Substring(0, 1).ToLower() + parmName.Substring(1);
                            LoadMethodList[k] = LoadMethodList[k].Replace("AAA", lowerName);
                        }
                    }

                    //Add the modified template to the main list
                    AngularLines.AddRange(LoadMethodList);
                }

            }
            //Print/////////////////////////////////////////////////////////////////////////

            //Load the template
            string[] PrintTemplate = File.ReadAllLines("Templates\\Angular\\Component\\Print.txt");
            List<string> PrintList = new List<string>(PrintTemplate);

            //Get Error Check Insert Index
            int ErrorCheckIndex = 0;
            for(int i = 0; i < PrintList.Count; i++)
            {
                if(PrintList[i].Contains("Insert Custom Error Checks Here"))
                {
                    ErrorCheckIndex = i + 1;
                }
            }

            //Insert Custom Error Checks
            for(int i = 0; i < rm.Parameters.Count; i++)
            {
                //Don't include anything for images
                if (!rm.Parameters[i].ParamCaptionLeft.Contains("Image"))
                {
                    string toAdd1 = "		if (!this.report." + rm.Parameters[i].ParamCaptionLeft.Replace("@", "") + ") {";
                    string toAdd2 = "			this.errorMessage = \"Select the " + rm.Parameters[i].ParamCaptionLeft.Replace("@", "").Replace("ID", "") + "\"";
                    string toAdd3 = "			return;";
                    string toAdd4 = "		}";
                    string toAdd5 = "";

                    PrintList.Insert(ErrorCheckIndex, toAdd1);
                    ErrorCheckIndex++;
                    PrintList.Insert(ErrorCheckIndex, toAdd2);
                    ErrorCheckIndex++;
                    PrintList.Insert(ErrorCheckIndex, toAdd3);
                    ErrorCheckIndex++;
                    PrintList.Insert(ErrorCheckIndex, toAdd4);
                    ErrorCheckIndex++;
                    PrintList.Insert(ErrorCheckIndex, toAdd5);
                    ErrorCheckIndex++;
                }
            }

            //Get the Custom Parameter insert index
            int CustomParmIndex = 0;
            for (int i = 0; i < PrintList.Count; i++)
            {
                if (PrintList[i].Contains("Insert Custom Parameters Here"))
                {
                    CustomParmIndex = i + 1;
                }
            }

            //Insert Parameters
            //Hardcode image if it's part of the report
            for(int i = 0; i < rm.Parameters.Count; i++)
            {
                ParameterModel pm = rm.Parameters[i];
                string pText = pm.ParamCaptionLeft.Replace("@", "");

                string toAdd1 = "        //Parameter " + (i + 1).ToString() + ": " + pText ;
                string toAdd2 = "";
                string addComma = "";
                if(i > 0 )
                {
                    addComma = "\",\" + ";
                }

                if (pm.DataType == "DTM")
                {
                    toAdd2 = "        strParam += " + addComma +" moment(this.report." + pText + ").format(\"MM/DD/YYYY\") + \"|" + pText + "\";"; 
                }
                else if (pm.ParamCaptionLeft.Contains("Image")) {
                    toAdd2 = "        strParam += \",8C87B20B-5813-4F74-8375-9898FD7B0C74|Imagelogo\"";         
                }
                else
                {
                    toAdd2 = "        strParam += " + addComma + "this.report." + pText + " + \"|" + pText + "\";";
                }

                string toAdd3 = "";

                PrintList.Insert(CustomParmIndex, toAdd1);
                CustomParmIndex++;
                PrintList.Insert(CustomParmIndex, toAdd2);
                CustomParmIndex++;
                PrintList.Insert(CustomParmIndex, toAdd3);
                CustomParmIndex++;
            }

            //Check if the parameters include school ID
            bool noSchoolID = true;
            for(int i = 0; i < rm.Parameters.Count; i++)
            {
                if (rm.Parameters[i].ParamCaptionLeft.Contains("School"))
                {
                    noSchoolID = false;
                    break;
                }
            }


            //Change Report ID
            for(int i = 0; i < PrintList.Count; i++)
            {
                //Change report ID
                if (PrintList[i].Contains("MyReportID"))
                {
                    PrintList[i] = PrintList[i].Replace("MyReportID", rm.ReportID.ToString());
                }
                //Change School ID to be a hardcoded value if not part of the parameters
                if (PrintList[i].Contains("this.report.SchoolID") && noSchoolID)
                {
                    PrintList[i] = PrintList[i].Replace("this.report.SchoolID", "202");
                }
            }

            //Add to main
            AngularLines.AddRange(PrintList);

            AngularLines.Add("}");

            
            //Add Angular lines to a file///////////////////////////////////////////////////
            string formattedName = rm.ReportName.Replace(" ", "").ToLower();
            string tsName = formattedName + ".component.ts";


            //Create Directory if it doesn't exist
            string filePath = Path.Combine(outputPath + "\\" + formattedName + "\\", tsName);
            FileInfo fi = new FileInfo(filePath);

            if (!fi.Directory.Exists)
            {
                Directory.CreateDirectory(fi.DirectoryName);
            }


            //Create the TypeScript File
            using (StreamWriter tsFile = new StreamWriter(filePath, true))
            {
                foreach (string line in AngularLines)
                {
                    tsFile.WriteLine(line);
                }
            }

        }

        //
        // Create Angular services for each parameter
        //
        public static void GenerateServicesFromReportModels(string outputPath, List<ReportModel> rms)
        {
            string filePath = Path.Combine(outputPath + "\\shared\\services\\example.service.ts");
            FileInfo fi = new FileInfo(filePath);

            if (!fi.Directory.Exists)
            {
                Directory.CreateDirectory(fi.DirectoryName);
            }


            //Go through all of the reports and their parameters
            for (int i = 0; i < rms.Count; i++)
            {
                for(int j = 0; j < rms[i].Parameters.Count; j++)
                {
                    ParameterModel nextpm = rms[i].Parameters[j];
                    if (nextpm.ParmQuery.Contains("usp"))
                    {
                        string pmn = nextpm.ParamCaptionLeft.Replace("@", "").Replace(" ", "").Replace("ID", "");
                        //Check if the service already exists
                        if (!File.Exists(outputPath + "\\shared\\services\\" + pmn + ".service.ts"))
                        {
                            //If not, create a new service
                            List<string> serviceLines = CreateService(nextpm);

                            //Write service lines to file
                            using (StreamWriter serviceFile = new StreamWriter(outputPath + "\\shared\\services\\" + pmn + ".service.ts", true))
                            {
                                foreach (string line in serviceLines)
                                {
                                    serviceFile.WriteLine(line);
                                }
                            }

                        }
                    }
                }

            }


        }

        private static List<string> CreateService(ParameterModel nextpm)
        {
            //Get the template
            string[] serviceTemplate = File.ReadAllLines("Templates\\Angular\\Service\\Service.txt");
            var serviceList = new List<string>(serviceTemplate);

            //Edit the template
            for(int i = 0; i < serviceList.Count; i++)
            {
                if (serviceList[i].Contains("Custom"))
                {
                    serviceList[i] = serviceList[i].Replace("Custom", nextpm.ParamCaptionLeft.Replace("@", "").Replace(" ", "").Replace("ID",""));
                }
            }

            return serviceList;
        }
    }
}

﻿using ReportMaker.Model;
using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace ReportMaker.Helpers
{
    //
    // Uses html templates to add parameters to a report form and can
    // create html files
    //
    public static class HTMLGenerator
    {

        // OLD METHODS /////////////////////////////////////////////////////////////////////////////
        //
        // Create and return a list of string with the html text to add to a file
        //
        /*public static List<string> HTMLLinesForReportModelOLD(ReportModel rm)
        {
            List<string> ans = new List<string>();

            //Get Basic Template from MainHTML.txt
            string[] mainTemplate = File.ReadAllLines("Templates\\HTML\\MainHTML.txt");
            var mainList = new List<string>(mainTemplate);

            //Add mainlist to ans
            ans.AddRange(mainList);

            //Start inserting new text after <!--START OPTIONS-->
            int StartIndex = 0;
            for(int i = 0; i < ans.Count; i++)
            {
                if(ans[i].Contains("<!--START OPTIONS-->"))
                {
                    StartIndex = i;
                }
            }

            //Go through rm's parameters
            for(int z = 0; z < rm.Parameters.Count; z++)
            {
                //If the parameter name matches a .txt file in existing param
                //Then add the text from the corresponding file
                string matchingFile = ParamMatchesExistingParam(rm.Parameters[z]);
                Console.WriteLine("00000000000000000000000000000000000000000000");
                Console.WriteLine("Parameter Name: {0}", rm.Parameters[z]);
                Console.WriteLine("Matching File = {0}", matchingFile);
                if (matchingFile != "NOTFOUND")
                {
                    Console.WriteLine("\n\n\nADDING EXISTING PARAM TO {0}\nPARAM = {1}\n\n\n", rm.ReportName, rm.Parameters[z]);

                    string[] existingTemplate = File.ReadAllLines("Templates\\HTML\\ExistingParam\\" + matchingFile);
                    var existingList = new List<string>(existingTemplate);

                    //Add existinglist to ans
                    for(int y = 0; y < existingList.Count; y++)
                    {
                        ans.Insert(StartIndex, existingList[y]);
                        StartIndex++;
                    }
                }
                //Else assume that it uses a dropdown list
                //Go through CustomList.txt and replace "CustomParm" with rm.ReportName
                //Then add the data to answer
                else
                {

                }




            }

            return ans;
        }
*/
        //
        // If the parameter name matches the name of a text file in \ExistingParam
        // Then return the file name. Else return NOTFOUND
        //
        private static string ParamMatchesExistingParam(string v)
        {
            string ans = "NOTFOUND";

            string[] files = Directory.GetFiles("Templates\\HTML\\ExistingParam", "*.txt");

            foreach(string file in files)
            {
                string checkFile = Path.GetFileName(file);
                Console.WriteLine("File Name: \"{0}\"\nInput Name: \"{1}\"", checkFile.Replace(".txt", ""), v);
                if (v.Trim().Equals(checkFile.Replace(".txt", "")))
                {
                    ans = checkFile;
                }
            }

            return ans;
        }

        //
        // Get the correct HTML Lines and write them to a {rm.ReportName}.Component.html file
        //
        /*public static void GenerateHTMLFromReportModelOLD(string docPath, ReportModel rm)
        {
            List<string> htmlLines = HTMLLinesForReportModel(rm);

            string formattedName = rm.ReportName.Replace(" ", "").ToLower();
            string htmlName = formattedName + ".component.html";


            //Create Directory if it doesn't exist
            string filePath = Path.Combine(docPath + "\\" + formattedName + "\\", htmlName);
            FileInfo fi = new FileInfo(filePath);

            if (!fi.Directory.Exists)
            {
                Directory.CreateDirectory(fi.DirectoryName);
            }


            //Create HTML File
            using (StreamWriter htmlFile = new StreamWriter(filePath, true))
            {
                foreach (string line in htmlLines)
                {
                    htmlFile.WriteLine(line);
                }
            }

        }
*/    
        // END OLD METHODS /////////////////////////////////////////////////////////////////////////



        // NEW METHODS /////////////////////////////////////////////////////////////////////////////

        //
        // New Method to generate HTML
        //
        public static void GenerateHTMLFromReportModel(string docPath, ReportModel rm)
        {
            List<string> htmlLines = HTMLLinesForReportModel(rm);

            string formattedName = rm.ReportName.Replace(" ", "").ToLower();
            string htmlName = formattedName + ".component.html";


            //Create Directory if it doesn't exist
            string filePath = Path.Combine(docPath + "\\" + formattedName + "\\", htmlName);
            FileInfo fi = new FileInfo(filePath);

            if (!fi.Directory.Exists)
            {
                Directory.CreateDirectory(fi.DirectoryName);
            }


            //Create HTML File
            using (StreamWriter htmlFile = new StreamWriter(filePath, true))
            {
                foreach (string line in htmlLines)
                {
                    htmlFile.WriteLine(line);
                }
            }
        }

        //
        // New Method that looks at parameter type and creates HTML as a list of strings
        //
        public static List<string> HTMLLinesForReportModel(ReportModel rm)
        {
            List<string> ans = new List<string>();

            //Get Basic Template from MainHTML.txt
            string[] mainTemplate = File.ReadAllLines("Templates\\HTML\\MainHTML.txt");
            var mainList = new List<string>(mainTemplate);

            //Add mainlist to ans
            ans.AddRange(mainList);

            //Start inserting new text after <!--START OPTIONS-->
            int StartIndex = 0;
            for (int i = 0; i < ans.Count; i++)
            {
                if (ans[i].Contains("<!--START OPTIONS-->"))
                {
                    StartIndex = i + 1;
                }
            }

            //Go through rm's parameters
            for (int z = 0; z < rm.Parameters.Count; z++)
            {
                ParameterModel nextParm = rm.Parameters[z];
                List<string> templateList = new List<string>();

                if (!nextParm.ParamCaptionLeft.Contains("Image"))
                {


                    //Check if the parameter is a ComboBox
                    if (nextParm.ControlType == "CCB" || nextParm.ControlType == "CBO")
                    {
                        //Get Template
                        string[] template = File.ReadAllLines("Templates\\HTML\\Controls\\ComboBox.txt");
                        templateList = new List<string>(template);

                        //Change Template
                        for (int a = 0; a < templateList.Count; a++)
                        {
                            if (templateList[a].Contains("Custom"))
                            {
                                templateList[a] = templateList[a].Replace("Custom", (nextParm.ParamCaptionLeft).Replace(" ", "").Replace("ID", ""));
                            }
                        }

                    }
                    //Check if the parameter is a DateTimePicker
                    else if (nextParm.ControlType == "DTP")
                    {
                        string[] template = File.ReadAllLines("Templates\\HTML\\Controls\\DatePicker.txt");
                        templateList = new List<string>(template);

                        //Change Template
                        for (int a = 0; a < templateList.Count; a++)
                        {
                            if (templateList[a].Contains("Custom With Space"))
                            {
                                templateList[a] = templateList[a].Replace("Custom With Space", nextParm.ParamCaptionLeft.Replace("ID", ""));
                            }
                            if (templateList[a].Contains("CustomCamelCase"))
                            {
                                templateList[a] = templateList[a].Replace("CustomCamelCase", (nextParm.ParamCaptionLeft).Replace(" ", "").Replace("ID", ""));
                            }
                        }
                    }
                    //Check if the parameter is a TextBox
                    else if (nextParm.ControlType == "TXT")
                    {
                        string[] template = File.ReadAllLines("Templates\\HTML\\Controls\\TextBox.txt");
                        templateList = new List<string>(template);

                        //Change Template
                    }
                    //Unknown Type
                    else
                    {

                    }
                }
                //Add comment before template and a blank line after the template
                templateList.Insert(0, "                    <!--" + nextParm.ParamCaptionLeft.Replace("@", "") + "-->");
                templateList.Add("");

                //Add templateList to ans
                for (int y = 0; y < templateList.Count; y++)
                {
                    ans.Insert(StartIndex, templateList[y]);
                    StartIndex++;
                }

            }

            return ans;
        }

        // END NEW METHODS /////////////////////////////////////////////////////////////////////////
    }
}

﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace ReportMaker.Helpers
{
    //
    // Create C# code to add items to the menu bar
    //

    public static class MenuItemGenerator
    {
        //Create 1 line to add to the CAASS.Api SecurityData.cs File
        public static string CreateSingleLink(string ComponentName)
        {
            //Template:
            //reportApplication.Children.Add(new ApplicationItem { ApplicationItemKey = "Report|SuspensionsNotAssignedMaximum", ApplicationItemName = "Suspensions Not Assigned Maximum Days" });
            string templatePartOne = "reportApplication.Children.Add(new ApplicationItem { ApplicationItemKey = \"Report|";
            //Text, one word, camelcase
            string templatePartTwo = "\", ApplicationItemName = \"";
            //Text, name with spaces
            string templatePartThree = "\" });";

            string camelCaseTitle = getCamelCase(ComponentName);
            string nameWithSpaces = getNameWithSpaces(ComponentName);

            return (templatePartOne + camelCaseTitle + templatePartTwo + nameWithSpaces + templatePartThree);
        }

        //Takes "suspensions without maximum days" and turns it into "SuspensionsWithoutMaximumDays"
        private static string getCamelCase(string lowerCaseSpacedOut)
        {
            List<string> words = new List<string>(lowerCaseSpacedOut.ToLower().Split(new[] { " " }, StringSplitOptions.RemoveEmptyEntries));

            string ans = "";
            for (int i = 0; i < words.Count; i++)
            {
                string toAdd = words[i];
                toAdd = toAdd.Substring(0, 1).ToUpper() + toAdd.Substring(1, toAdd.Length-1);
                ans += toAdd;
            }
            return ans;
        }

        //Turn suspensions without maximum days to Suspensions Without Maximum Days
        private static string getNameWithSpaces(string lowerCaseSpacedOut)
        {
            List<string> words = new List<string>(lowerCaseSpacedOut.ToLower().Split(new[] { " " }, StringSplitOptions.RemoveEmptyEntries));

            string ans = "";
            for (int i = 0; i < words.Count; i++)
            {
                string toAdd = words[i];
                toAdd = toAdd.Substring(0, 1).ToUpper() + toAdd.Substring(1, toAdd.Length - 1);
                ans += toAdd;
                if(i < words.Count - 1)
                {
                    ans += " ";
                }
            }
            return ans;
        }

        public static string CreateReportRouteLinks(string reportName)
        {
            string[] template = File.ReadAllLines("Templates\\Links\\report-routes.ts.txt");
            var templateList = new List<string>(template);

            string rnLowerCamel = reportName.Replace(" ", "").ToLower();
            //rnLowerCamel = rnLowerCamel.Substring(0, 1).ToLower() + rnLowerCamel.Substring(1);

            templateList[0] = templateList[0].Replace("customOneWordLowerCase", rnLowerCamel);
            templateList[0] = templateList[0].Replace("Custom Many Words CamelCase", reportName);
            templateList[0] = templateList[0].Replace("CustomCamelCase", reportName.Replace(" ", ""));

            return templateList[0];
        }

        public static string CreateIndexTSLinks(string reportName)
        {
            string[] template = File.ReadAllLines("Templates\\Links\\Index.ts.txt");
            var templateList = new List<string>(template);

            templateList[0] = templateList[0].Replace("Custom", reportName.Replace(" ", ""));
            templateList[0] = templateList[0].Replace("custom", reportName.ToLower().Replace(" ", ""));

            return templateList[0];
        }

        public static string CreateSecurityDataMenuItem(string reportName)
        {
            string[] template = File.ReadAllLines("Templates\\Links\\SecurityData.cs.txt");
            var templateList = new List<string>(template);

            templateList[0] = templateList[0].Replace("CustomCamelCase", reportName.Replace(" ", ""));
            templateList[0] = templateList[0].Replace("Custom Many Words", reportName);

            return templateList[0];
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Text;
using CsvHelper;
using CsvHelper.Configuration;
using CsvHelper.TypeConversion;
using ReportMaker.Model;

namespace ReportMaker.Helpers
{
    public static class Parser
    {

/*        //
        // Only Use for testing
        //
        public static string GetRawData(string path)
        {
            StreamReader reader = new StreamReader(path);
            CsvConfiguration config = new CsvConfiguration(CultureInfo.InvariantCulture);

            using (CsvReader csv = new CsvReader(reader, config))
            {

                // Skip titles
                csv.Read();

                // Parse data from the csv
                int i = 1;
                while (csv.Read())
                {
                    Console.WriteLine("Line {0}", i);
                    for (int x = 0; x < 17; x++)
                    {
                        if (!string.IsNullOrEmpty(csv[x]))
                        {
                            Console.WriteLine("Column {0}, Value {1}", x, csv[x]);
                        }
                    }

                    i++;
                }

                string ans = "";

                return ans;
            }
        }*/

        //
        // Create and return a list of report models from a csv file
        //
/*        public static List<ReportModel> GetReportModelsFromCSVOLD(string path)
        {
            Console.WriteLine("Running Get Report Models From CSV");

            StreamReader reader = new StreamReader(path);
            CsvConfiguration config = new CsvConfiguration(CultureInfo.InvariantCulture);

            List<ReportModel> ans = new List<ReportModel>();

            using (CsvReader csv = new CsvReader(reader, config))
            {

                // Skip titles
                csv.Read();


                // Parse data from the csv
                int i = 1;
                while (csv.Read())
                {
                    //Initialize Report Model Fields
                    string NextReportName = "";
                    bool NextReportFinished = false;
                    int NextReportID = 0;
                    List<string> NextReportParameters = new List<string>();

                    Console.WriteLine("Line {0}", i);
                    for (int x = 0; x < 17; x++)
                    {
                        if (!string.IsNullOrEmpty(csv[x]))
                        {
                            Console.WriteLine("Column {0}, Value {1}", x, csv[x]);
                        }

                    }

                    try
                    {
                        NextReportName = csv[0];
                        if (csv[1] == "N")
                        {
                            NextReportFinished = false;
                        }
                        else if (csv[1] == "Y")
                        {
                            NextReportFinished = true;
                        }

                        NextReportID = Int32.Parse(csv[2]);
                        for (int x = 3; x < 17; x++)
                        {
                            if (!string.IsNullOrEmpty(csv[x]))
                            {
                                NextReportParameters.Add(csv[x]);
                            }

                        }

                        Console.WriteLine("\nNext Report Parameters:\n");
                        Console.WriteLine("Name: {0}\nFinished?: {1}\nID: {2}", NextReportName, NextReportFinished, NextReportID);
                        
                        //Create Report and add it to the list
                        if (NextReportName != "" && NextReportID != 0 && NextReportParameters.Count > 0)
                        {
                            ReportModel NextReport = new ReportModel(NextReportName, NextReportFinished, NextReportID, NextReportParameters);
                            ans.Add(NextReport);
                        }
                    }
                    catch(Exception e)
                    {
                        Console.WriteLine("\nReport Could Not Be Created:\n");
                        Console.WriteLine("Name: {0}\nFinished?: {1}\nID: {2}", NextReportName, NextReportFinished, NextReportID);

                    }


                    i++;
                }

                return ans;
            }
        }
*/
        
        
        //
        // New version, get data from ReportParm Table as a CSV
        //
        public static List<ReportModel> GetReportModelsFromCSV(string path)
        {
            Console.WriteLine("Getting Report Models From CSV Using the new method");

            StreamReader reader = new StreamReader(path);
            CsvConfiguration config = new CsvConfiguration(CultureInfo.InvariantCulture);

            List<ReportModel> ans = new List<ReportModel>();

            using (CsvReader csv = new CsvReader(reader, config))
            {

                // Skip titles
                csv.Read();

                // Parse data from csv
                int i = 1;
                while (csv.Read())
                {
                    //Check if ReportParm's report exists yet
                    string ReportName = csv[0];
                    ReportModel addTo = null;
                    bool ReportExists = false;

                    Console.WriteLine("Checking if Report {0} Exists Yet", ReportName);

                    for (int x = 0; x < ans.Count; x++)
                    {
                        if(ans[x].ReportName == ReportName)
                        {
                            ReportExists = true;
                            addTo = ans[x];
                            break;
                        }
                    }

                    Console.WriteLine("Does the report exist? {0}", ReportExists);

                    //If not, create the report model
                    if (!ReportExists)
                    {
                        Console.WriteLine("Creating Report and adding it to the list");
                        addTo = new ReportModel(ReportName, false, Int32.Parse(csv[2]), new List<ParameterModel>());
                        ans.Add(addTo);
                    }

                    Console.WriteLine("Creating Parameter");
                    //Create the parameter model
                    ParameterModel nextParm = new ParameterModel();

                    int ReportID = Int32.Parse(csv[2]);
                    string ParmName = csv[7].Replace("@", "");
                    string ControlType = csv[4];
                    string DataType = csv[6];
                    string ParmQuery = csv[16];
                    string DefaultVal = csv[17];

                    nextParm.ReportID = ReportID;
                    nextParm.ParamCaptionLeft = ParmName;
                    nextParm.ControlType = ControlType;
                    nextParm.DataType = DataType;
                    nextParm.ParmQuery = ParmQuery;
                    nextParm.DefaultVal = DefaultVal;

                    Console.WriteLine("\nParmName: {0}\nReportID: {1}\nControlType: {2}\nDataType: {3}", ParmName, ReportID, ControlType, DataType);

                    Console.WriteLine("Adding Parameter to ReportModel");
                    //Add parameter model to report model's list of parameters
                    addTo.Parameters.Add(nextParm);

                }

                return ans;
            }
        }

    }
}

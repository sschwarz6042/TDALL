﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ReportMaker.Helpers
{
    public class ServiceGenerator
    {
    }
}

﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ReportMaker.Model
{
    public class ParameterModel
    {
        // Might use id when parsing CSV
        public int ReportID { get; set; }

        // Name of the parameter
        public string ParamCaptionLeft { get; set; } = "";

        // Control Type can be:
        // CCB/CBO: ComboBox
        // TXT: TextBox
        // DTP: DatePicker
        public string ControlType { get; set; } = "";

        // DataType can be:
        // INT, STR, DTM
        public string DataType { get; set; } = "";

        public string ParmQuery { get; set; } = "";
        public string DefaultVal { get; set; } = "";
    }
}

﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ReportMaker.Model
{
    public class ReportModel
    {
        public ReportModel(string nextReportName, bool nextReportFinished, int nextReportID, List<ParameterModel> nextReportParameters)
        {
            this.ReportName = nextReportName;
            this.Finished = nextReportFinished;
            this.ReportID = nextReportID;
            this.Parameters = nextReportParameters;
        }

        public string ReportName { get; set; }
        public bool Finished { get; set; }
        public int ReportID { get; set; }
        public List<ParameterModel> Parameters { get; set; }
    }
}

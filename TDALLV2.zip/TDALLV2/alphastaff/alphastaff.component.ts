import { Component, OnInit, AfterViewInit } from '@angular/core';
import { ReportService } from '../report.service';
//Import Custom Services Here
import { SchoolService } from '../../../shared/services/school.service'
import { PERSONTYPEService } from '../../../shared/services/persontype.service'
declare var moment: any;


@Component({
    templateUrl: './alphastaff.component.html',

})
export class AlphaStaffComponent implements OnInit {
    constructor(
        private reportService: ReportService,
        //Insert Custom Services Here
        private persontypeService: PERSONTYPEService,
        private schoolService: SchoolService,

    ) {

    }
    report = {
        //Insert Custom Parameters Here
        SchoolID: 0,
        PERSONTYPEID: 0,
        ORDERBY: "",
        ImageLogo: 0,

    }
    //Insert Custom Lists Here
    SchoolList: any = []
    PERSONTYPEList: any = []
    ImageLogoList: any = []
    

    user: any;
    errorMessage: any = "";
    isProcessing: any = false;
    
    ORDERBYList = [
        //Insert Custom List Items Here
        {
			ORDERBYName: 'Name'
        },
        {
			ORDERBYName: 'Staff Type'
        }

    ]

    ngOnInit() {
        //Insert Custom Init Methods Here
        this.loadSchoolList()
        this.loadPERSONTYPEList()
               
      }
    
    private loadSchoolList() {
      
        this.report.SchoolID = 0;
        var result = this.schoolService.loadSchoolList(this.report.SchoolID);
        result.subscribe(
            response => {
                this.SchoolList = response;

                if (this.SchoolList.length > 1) {
                    this.SchoolList.unshift({
                        SchoolID: 0,
                        SchoolDesc: "All Schools"
                    })
                } else {
                    this.report.SchoolID = this.SchoolList[0].SchoolID
                }


            },
            error => {
            }
        )

    }
    
    private loadPERSONTYPEList() {
      
        this.report.PERSONTYPEID = 0;
        var result = this.pERSONTYPEService.loadPERSONTYPEList(this.report.SchoolID);
        result.subscribe(
            response => {
                this.PERSONTYPEList = response;

                if (this.PERSONTYPEList.length > 1) {
                    this.PERSONTYPEList.unshift({
                        PERSONTYPEID: 0,
                        PERSONTYPEDesc: "All PERSONTYPEs"
                    })
                } else {
                    this.report.PERSONTYPEID = this.PERSONTYPEList[0].PERSONTYPEID
                }


            },
            error => {
            }
        )

    }
    Print() {

        var component = this;
        this.errorMessage = "";

        //Insert Custom Error Checks Here
		if (!this.report.SchoolID) {
			this.errorMessage = "Select the School"
			return;
		}

		if (!this.report.PERSONTYPEID) {
			this.errorMessage = "Select the PERSONTYPE"
			return;
		}

		if (!this.report.ORDERBY) {
			this.errorMessage = "Select the ORDERBY"
			return;
		}

      

        var strParam = "";
        this.isProcessing = true;
    
        //Insert Custom Parameters Here
        //Parameter 1: SchoolID
        strParam += this.report.SchoolID + "|SchoolID";

        //Parameter 2: PERSONTYPEID
        strParam += "," + this.report.PERSONTYPEID + "|PERSONTYPEID";

        //Parameter 3: ORDERBY
        strParam += "," + this.report.ORDERBY + "|ORDERBY";

        //Parameter 4: ImageLogo
        strParam += ",8C87B20B-5813-4F74-8375-9898FD7B0C74|Imagelogo"



        var reportID = 42;

        var result = this.reportService.Print(reportID, strParam, this.report.SchoolID);

        result.subscribe(
            (response: any) => {
                component.isProcessing = false;
                window.open(response);
            },
            error => {
                component.errorMessage = error
                component.isProcessing = false;
            }
        )
    }
}

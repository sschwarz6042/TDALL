import { Component, OnInit, AfterViewInit } from '@angular/core';
import { ReportService } from '../report.service';
//Import Custom Services Here
import { SchoolService } from '../../../shared/services/school.service'
import { GradeLevelService } from '../../../shared/services/gradelevel.service'
import { ACADEMYService } from '../../../shared/services/academy.service'
import { HOMEROOMService } from '../../../shared/services/homeroom.service'
import { GROUPService } from '../../../shared/services/group.service'
declare var moment: any;


@Component({
    templateUrl: './alphastudentlist.component.html',

})
export class AlphaStudentListComponent implements OnInit {
    constructor(
        private reportService: ReportService,
        //Insert Custom Services Here
        private groupService: GROUPService,
        private homeroomService: HOMEROOMService,
        private academyService: ACADEMYService,
        private gradelevelService: GradeLevelService,
        private schoolService: SchoolService,

    ) {

    }
    report = {
        //Insert Custom Parameters Here
        SchoolID: 0,
        GradeLevelID: 0,
        ACADEMYID: 0,
        HOMEROOMID: 0,
        GROUPID: 0,
        ORDERBY: "",
        ImageLogo: 0,

    }
    //Insert Custom Lists Here
    SchoolList: any = []
    GradeLevelList: any = []
    ACADEMYList: any = []
    HOMEROOMList: any = []
    GROUPList: any = []
    ImageLogoList: any = []
    

    user: any;
    errorMessage: any = "";
    isProcessing: any = false;
    
    ORDERBYList = [
        //Insert Custom List Items Here
        {
			ORDERBYName: 'Academy'
        },
        {
			ORDERBYName: 'Grade'
        },
        {
			ORDERBYName: 'Homeroom'
        },
        {
			ORDERBYName: 'Name'
        }

    ]

    ngOnInit() {
        //Insert Custom Init Methods Here
        this.loadSchoolList()
        this.loadGradeLevelList()
        this.loadACADEMYList()
        this.loadHOMEROOMList()
        this.loadGROUPList()
               
      }
    
    private loadSchoolList() {
      
        this.report.SchoolID = 0;
        var result = this.schoolService.loadSchoolList(this.report.SchoolID);
        result.subscribe(
            response => {
                this.SchoolList = response;

                if (this.SchoolList.length > 1) {
                    this.SchoolList.unshift({
                        SchoolID: 0,
                        SchoolDesc: "All Schools"
                    })
                } else {
                    this.report.SchoolID = this.SchoolList[0].SchoolID
                }


            },
            error => {
            }
        )

    }
    
    private loadGradeLevelList() {
      
        this.report.GradeLevelID = 0;
        var result = this.gradeLevelService.loadGradeLevelList(this.report.SchoolID);
        result.subscribe(
            response => {
                this.GradeLevelList = response;

                if (this.GradeLevelList.length > 1) {
                    this.GradeLevelList.unshift({
                        GradeLevelID: 0,
                        GradeLevelDesc: "All GradeLevels"
                    })
                } else {
                    this.report.GradeLevelID = this.GradeLevelList[0].GradeLevelID
                }


            },
            error => {
            }
        )

    }
    
    private loadACADEMYList() {
      
        this.report.ACADEMYID = 0;
        var result = this.aCADEMYService.loadACADEMYList(this.report.SchoolID);
        result.subscribe(
            response => {
                this.ACADEMYList = response;

                if (this.ACADEMYList.length > 1) {
                    this.ACADEMYList.unshift({
                        ACADEMYID: 0,
                        ACADEMYDesc: "All ACADEMYs"
                    })
                } else {
                    this.report.ACADEMYID = this.ACADEMYList[0].ACADEMYID
                }


            },
            error => {
            }
        )

    }
    
    private loadHOMEROOMList() {
      
        this.report.HOMEROOMID = 0;
        var result = this.hOMEROOMService.loadHOMEROOMList(this.report.SchoolID);
        result.subscribe(
            response => {
                this.HOMEROOMList = response;

                if (this.HOMEROOMList.length > 1) {
                    this.HOMEROOMList.unshift({
                        HOMEROOMID: 0,
                        HOMEROOMDesc: "All HOMEROOMs"
                    })
                } else {
                    this.report.HOMEROOMID = this.HOMEROOMList[0].HOMEROOMID
                }


            },
            error => {
            }
        )

    }
    
    private loadGROUPList() {
      
        this.report.GROUPID = 0;
        var result = this.gROUPService.loadGROUPList(this.report.SchoolID);
        result.subscribe(
            response => {
                this.GROUPList = response;

                if (this.GROUPList.length > 1) {
                    this.GROUPList.unshift({
                        GROUPID: 0,
                        GROUPDesc: "All GROUPs"
                    })
                } else {
                    this.report.GROUPID = this.GROUPList[0].GROUPID
                }


            },
            error => {
            }
        )

    }
    Print() {

        var component = this;
        this.errorMessage = "";

        //Insert Custom Error Checks Here
		if (!this.report.SchoolID) {
			this.errorMessage = "Select the School"
			return;
		}

		if (!this.report.GradeLevelID) {
			this.errorMessage = "Select the GradeLevel"
			return;
		}

		if (!this.report.ACADEMYID) {
			this.errorMessage = "Select the ACADEMY"
			return;
		}

		if (!this.report.HOMEROOMID) {
			this.errorMessage = "Select the HOMEROOM"
			return;
		}

		if (!this.report.GROUPID) {
			this.errorMessage = "Select the GROUP"
			return;
		}

		if (!this.report.ORDERBY) {
			this.errorMessage = "Select the ORDERBY"
			return;
		}

      

        var strParam = "";
        this.isProcessing = true;
    
        //Insert Custom Parameters Here
        //Parameter 1: SchoolID
        strParam += this.report.SchoolID + "|SchoolID";

        //Parameter 2: GradeLevelID
        strParam += "," + this.report.GradeLevelID + "|GradeLevelID";

        //Parameter 3: ACADEMYID
        strParam += "," + this.report.ACADEMYID + "|ACADEMYID";

        //Parameter 4: HOMEROOMID
        strParam += "," + this.report.HOMEROOMID + "|HOMEROOMID";

        //Parameter 5: GROUPID
        strParam += "," + this.report.GROUPID + "|GROUPID";

        //Parameter 6: ORDERBY
        strParam += "," + this.report.ORDERBY + "|ORDERBY";

        //Parameter 7: ImageLogo
        strParam += ",8C87B20B-5813-4F74-8375-9898FD7B0C74|Imagelogo"



        var reportID = 57;

        var result = this.reportService.Print(reportID, strParam, this.report.SchoolID);

        result.subscribe(
            (response: any) => {
                component.isProcessing = false;
                window.open(response);
            },
            error => {
                component.errorMessage = error
                component.isProcessing = false;
            }
        )
    }
}

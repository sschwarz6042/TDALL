import { Component, OnInit, AfterViewInit } from '@angular/core';
import { ReportService } from '../report.service';
//Import Custom Services Here
import { SchoolService } from '../../../shared/services/school.service'
import { StartMonthService } from '../../../shared/services/startmonth.service'
import { StartYearService } from '../../../shared/services/startyear.service'
declare var moment: any;


@Component({
    templateUrl: './attendancebyday.component.html',

})
export class AttendancebyDayComponent implements OnInit {
    constructor(
        private reportService: ReportService,
        //Insert Custom Services Here
        private startyearService: StartYearService,
        private startmonthService: StartMonthService,
        private schoolService: SchoolService,

    ) {

    }
    report = {
        //Insert Custom Parameters Here
        SchoolID: 0,
        PcentBaseAttendance: "",
        BaseStudentsCutting: 0,
        BaseClassCutsPerDay: 0,
        StartMonthID: 0,
        StartYearID: 0,
        ImageLogo: 0,

    }
    //Insert Custom Lists Here
    SchoolList: any = []
    StartMonthList: any = []
    StartYearList: any = []
    ImageLogoList: any = []
    

    user: any;
    errorMessage: any = "";
    isProcessing: any = false;
    ngOnInit() {
        //Insert Custom Init Methods Here
        this.loadSchoolList()
        this.loadStartMonthList()
        this.loadStartYearList()
               
      }
    
    private loadSchoolList() {
      
        this.report.SchoolID = 0;
        var result = this.schoolService.loadSchoolList(this.report.SchoolID);
        result.subscribe(
            response => {
                this.SchoolList = response;

                if (this.SchoolList.length > 1) {
                    this.SchoolList.unshift({
                        SchoolID: 0,
                        SchoolDesc: "All Schools"
                    })
                } else {
                    this.report.SchoolID = this.SchoolList[0].SchoolID
                }


            },
            error => {
            }
        )

    }
    
    private loadStartMonthList() {
      
        this.report.StartMonthID = 0;
        var result = this.startMonthService.loadStartMonthList(this.report.SchoolID);
        result.subscribe(
            response => {
                this.StartMonthList = response;

                if (this.StartMonthList.length > 1) {
                    this.StartMonthList.unshift({
                        StartMonthID: 0,
                        StartMonthDesc: "All StartMonths"
                    })
                } else {
                    this.report.StartMonthID = this.StartMonthList[0].StartMonthID
                }


            },
            error => {
            }
        )

    }
    
    private loadStartYearList() {
      
        this.report.StartYearID = 0;
        var result = this.startYearService.loadStartYearList(this.report.SchoolID);
        result.subscribe(
            response => {
                this.StartYearList = response;

                if (this.StartYearList.length > 1) {
                    this.StartYearList.unshift({
                        StartYearID: 0,
                        StartYearDesc: "All StartYears"
                    })
                } else {
                    this.report.StartYearID = this.StartYearList[0].StartYearID
                }


            },
            error => {
            }
        )

    }
    Print() {

        var component = this;
        this.errorMessage = "";

        //Insert Custom Error Checks Here
		if (!this.report.SchoolID) {
			this.errorMessage = "Select the School"
			return;
		}

		if (!this.report.PcentBaseAttendance) {
			this.errorMessage = "Select the PcentBaseAttendance"
			return;
		}

		if (!this.report.BaseStudentsCutting) {
			this.errorMessage = "Select the BaseStudentsCutting"
			return;
		}

		if (!this.report.BaseClassCutsPerDay) {
			this.errorMessage = "Select the BaseClassCutsPerDay"
			return;
		}

		if (!this.report.StartMonthID) {
			this.errorMessage = "Select the StartMonth"
			return;
		}

		if (!this.report.StartYearID) {
			this.errorMessage = "Select the StartYear"
			return;
		}

      

        var strParam = "";
        this.isProcessing = true;
    
        //Insert Custom Parameters Here
        //Parameter 1: SchoolID
        strParam += this.report.SchoolID + "|SchoolID";

        //Parameter 2: PcentBaseAttendance
        strParam += "," + this.report.PcentBaseAttendance + "|PcentBaseAttendance";

        //Parameter 3: BaseStudentsCutting
        strParam += "," + this.report.BaseStudentsCutting + "|BaseStudentsCutting";

        //Parameter 4: BaseClassCutsPerDay
        strParam += "," + this.report.BaseClassCutsPerDay + "|BaseClassCutsPerDay";

        //Parameter 5: StartMonthID
        strParam += "," + this.report.StartMonthID + "|StartMonthID";

        //Parameter 6: StartYearID
        strParam += "," + this.report.StartYearID + "|StartYearID";

        //Parameter 7: ImageLogo
        strParam += ",8C87B20B-5813-4F74-8375-9898FD7B0C74|Imagelogo"



        var reportID = 3;

        var result = this.reportService.Print(reportID, strParam, this.report.SchoolID);

        result.subscribe(
            (response: any) => {
                component.isProcessing = false;
                window.open(response);
            },
            error => {
                component.errorMessage = error
                component.isProcessing = false;
            }
        )
    }
}

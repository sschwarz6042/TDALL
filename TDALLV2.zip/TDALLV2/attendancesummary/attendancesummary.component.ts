import { Component, OnInit, AfterViewInit } from '@angular/core';
import { ReportService } from '../report.service';
//Import Custom Services Here
declare var moment: any;


@Component({
    templateUrl: './attendancesummary.component.html',

})
export class AttendanceSummaryComponent implements OnInit {
    constructor(
        private reportService: ReportService,
        //Insert Custom Services Here

    ) {

    }
    report = {
        //Insert Custom Parameters Here
        SchoolXML: "",
        GivenDate: ,
        ImageLogo: 0,

    }
    //Insert Custom Lists Here
    ImageLogoList: any = []
    

    user: any;
    errorMessage: any = "";
    isProcessing: any = false;
    ngOnInit() {
        //Insert Custom Init Methods Here
               
      }
    Print() {

        var component = this;
        this.errorMessage = "";

        //Insert Custom Error Checks Here
		if (!this.report.SchoolXML) {
			this.errorMessage = "Select the SchoolXML"
			return;
		}

		if (!this.report.GivenDate) {
			this.errorMessage = "Select the GivenDate"
			return;
		}

      

        var strParam = "";
        this.isProcessing = true;
    
        //Insert Custom Parameters Here
        //Parameter 1: SchoolXML
        strParam += this.report.SchoolXML + "|SchoolXML";

        //Parameter 2: GivenDate
        strParam += "," +  moment(this.report.GivenDate).format("MM/DD/YYYY") + "|GivenDate";

        //Parameter 3: ImageLogo
        strParam += ",8C87B20B-5813-4F74-8375-9898FD7B0C74|Imagelogo"



        var reportID = 7;

        var result = this.reportService.Print(reportID, strParam, this.report.SchoolID);

        result.subscribe(
            (response: any) => {
                component.isProcessing = false;
                window.open(response);
            },
            error => {
                component.errorMessage = error
                component.isProcessing = false;
            }
        )
    }
}

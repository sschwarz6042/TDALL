import { Component, OnInit, AfterViewInit } from '@angular/core';
import { ReportService } from '../report.service';
//Import Custom Services Here
import { DistrictSchoolService } from '../../../shared/services/districtschool.service'
import { MTACardTypeService } from '../../../shared/services/mtacardtype.service'
declare var moment: any;


@Component({
    templateUrl: './cardstatus.component.html',

})
export class CardStatusComponent implements OnInit {
    constructor(
        private reportService: ReportService,
        //Insert Custom Services Here
        private mtacardtypeService: MTACardTypeService,
        private districtschoolService: DistrictSchoolService,

    ) {

    }
    report = {
        //Insert Custom Parameters Here
        DistrictSchoolID: 0,
        StatusDate: ,
        ActiveStatus: "",
        MTACardTypeID: 0,
        SortBy: "",
        ImageLogo: 0,

    }
    //Insert Custom Lists Here
    DistrictSchoolList: any = []
    MTACardTypeList: any = []
    ImageLogoList: any = []
    

    user: any;
    errorMessage: any = "";
    isProcessing: any = false;
    
    ActiveStatusList = [
        //Insert Custom List Items Here
        {
			ActiveStatusName: 'All'
        },
        {
			ActiveStatusName: 'Active'
        },
        {
			ActiveStatusName: 'Inactive'
        }

    ]

    
    SortByList = [
        //Insert Custom List Items Here
        {
			SortByName: 'Active Status'
        },
        {
			SortByName: 'Date'
        },
        {
			SortByName: 'Name'
        },
        {
			SortByName: 'School'
        },
        {
			SortByName: 'UID'
        }

    ]

    ngOnInit() {
        //Insert Custom Init Methods Here
        this.loadDistrictSchoolList()
        this.loadMTACardTypeList()
               
      }
    
    private loadDistrictSchoolList() {
      
        this.report.DistrictSchoolID = 0;
        var result = this.districtSchoolService.loadDistrictSchoolList(this.report.SchoolID);
        result.subscribe(
            response => {
                this.DistrictSchoolList = response;

                if (this.DistrictSchoolList.length > 1) {
                    this.DistrictSchoolList.unshift({
                        DistrictSchoolID: 0,
                        DistrictSchoolDesc: "All DistrictSchools"
                    })
                } else {
                    this.report.DistrictSchoolID = this.DistrictSchoolList[0].DistrictSchoolID
                }


            },
            error => {
            }
        )

    }
    
    private loadMTACardTypeList() {
      
        this.report.MTACardTypeID = 0;
        var result = this.mTACardTypeService.loadMTACardTypeList(this.report.SchoolID);
        result.subscribe(
            response => {
                this.MTACardTypeList = response;

                if (this.MTACardTypeList.length > 1) {
                    this.MTACardTypeList.unshift({
                        MTACardTypeID: 0,
                        MTACardTypeDesc: "All MTACardTypes"
                    })
                } else {
                    this.report.MTACardTypeID = this.MTACardTypeList[0].MTACardTypeID
                }


            },
            error => {
            }
        )

    }
    Print() {

        var component = this;
        this.errorMessage = "";

        //Insert Custom Error Checks Here
		if (!this.report.DistrictSchoolID) {
			this.errorMessage = "Select the DistrictSchool"
			return;
		}

		if (!this.report.StatusDate) {
			this.errorMessage = "Select the StatusDate"
			return;
		}

		if (!this.report.ActiveStatus) {
			this.errorMessage = "Select the ActiveStatus"
			return;
		}

		if (!this.report.MTACardTypeID) {
			this.errorMessage = "Select the MTACardType"
			return;
		}

		if (!this.report.SortBy) {
			this.errorMessage = "Select the SortBy"
			return;
		}

      

        var strParam = "";
        this.isProcessing = true;
    
        //Insert Custom Parameters Here
        //Parameter 1: DistrictSchoolID
        strParam += this.report.DistrictSchoolID + "|DistrictSchoolID";

        //Parameter 2: StatusDate
        strParam += "," +  moment(this.report.StatusDate).format("MM/DD/YYYY") + "|StatusDate";

        //Parameter 3: ActiveStatus
        strParam += "," + this.report.ActiveStatus + "|ActiveStatus";

        //Parameter 4: MTACardTypeID
        strParam += "," + this.report.MTACardTypeID + "|MTACardTypeID";

        //Parameter 5: SortBy
        strParam += "," + this.report.SortBy + "|SortBy";

        //Parameter 6: ImageLogo
        strParam += ",8C87B20B-5813-4F74-8375-9898FD7B0C74|Imagelogo"



        var reportID = 403;

        var result = this.reportService.Print(reportID, strParam, this.report.SchoolID);

        result.subscribe(
            (response: any) => {
                component.isProcessing = false;
                window.open(response);
            },
            error => {
                component.errorMessage = error
                component.isProcessing = false;
            }
        )
    }
}

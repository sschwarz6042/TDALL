import { Component, OnInit, AfterViewInit } from '@angular/core';
import { ReportService } from '../report.service';
//Import Custom Services Here
import { SchoolService } from '../../../shared/services/school.service'
import { InstructorService } from '../../../shared/services/instructor.service'
import { CourseService } from '../../../shared/services/course.service'
import { SectionNoService } from '../../../shared/services/sectionno.service'
import { ClassAttendanceStatusService } from '../../../shared/services/classattendancestatus.service'
import { ClassAttendanceEntryTypeService } from '../../../shared/services/classattendanceentrytype.service'
declare var moment: any;


@Component({
    templateUrl: './classattendancesummary.component.html',

})
export class ClassAttendanceSummaryComponent implements OnInit {
    constructor(
        private reportService: ReportService,
        //Insert Custom Services Here
        private classattendanceentrytypeService: ClassAttendanceEntryTypeService,
        private classattendancestatusService: ClassAttendanceStatusService,
        private sectionnoService: SectionNoService,
        private courseService: CourseService,
        private instructorService: InstructorService,
        private schoolService: SchoolService,

    ) {

    }
    report = {
        //Insert Custom Parameters Here
        SchoolID: 0,
        InstructorID: 0,
        CourseID: 0,
        SectionNo: 0,
        StartDate: ,
        EndDate: ,
        ClassAttendanceStatusID: 0,
        ClassAttendanceEntryTypeID: 0,
        ImageLogo: 0,

    }
    //Insert Custom Lists Here
    SchoolList: any = []
    InstructorList: any = []
    CourseList: any = []
    SectionNoList: any = []
    ClassAttendanceStatusList: any = []
    ClassAttendanceEntryTypeList: any = []
    ImageLogoList: any = []
    

    user: any;
    errorMessage: any = "";
    isProcessing: any = false;
    ngOnInit() {
        //Insert Custom Init Methods Here
        this.loadSchoolList()
        this.loadInstructorList()
        this.loadCourseList()
        this.loadSectionNoList()
        this.loadClassAttendanceStatusList()
        this.loadClassAttendanceEntryTypeList()
               
      }
    
    private loadSchoolList() {
      
        this.report.SchoolID = 0;
        var result = this.schoolService.loadSchoolList(this.report.SchoolID);
        result.subscribe(
            response => {
                this.SchoolList = response;

                if (this.SchoolList.length > 1) {
                    this.SchoolList.unshift({
                        SchoolID: 0,
                        SchoolDesc: "All Schools"
                    })
                } else {
                    this.report.SchoolID = this.SchoolList[0].SchoolID
                }


            },
            error => {
            }
        )

    }
    
    private loadInstructorList() {
      
        this.report.InstructorID = 0;
        var result = this.instructorService.loadInstructorList(this.report.SchoolID);
        result.subscribe(
            response => {
                this.InstructorList = response;

                if (this.InstructorList.length > 1) {
                    this.InstructorList.unshift({
                        InstructorID: 0,
                        InstructorDesc: "All Instructors"
                    })
                } else {
                    this.report.InstructorID = this.InstructorList[0].InstructorID
                }


            },
            error => {
            }
        )

    }
    
    private loadCourseList() {
      
        this.report.CourseID = 0;
        var result = this.courseService.loadCourseList(this.report.SchoolID);
        result.subscribe(
            response => {
                this.CourseList = response;

                if (this.CourseList.length > 1) {
                    this.CourseList.unshift({
                        CourseID: 0,
                        CourseDesc: "All Courses"
                    })
                } else {
                    this.report.CourseID = this.CourseList[0].CourseID
                }


            },
            error => {
            }
        )

    }
    
    private loadSectionNoList() {
      
        this.report.SectionNoID = 0;
        var result = this.sectionNoService.loadSectionNoList(this.report.SchoolID);
        result.subscribe(
            response => {
                this.SectionNoList = response;

                if (this.SectionNoList.length > 1) {
                    this.SectionNoList.unshift({
                        SectionNoID: 0,
                        SectionNoDesc: "All SectionNos"
                    })
                } else {
                    this.report.SectionNoID = this.SectionNoList[0].SectionNoID
                }


            },
            error => {
            }
        )

    }
    
    private loadClassAttendanceStatusList() {
      
        this.report.ClassAttendanceStatusID = 0;
        var result = this.classAttendanceStatusService.loadClassAttendanceStatusList(this.report.SchoolID);
        result.subscribe(
            response => {
                this.ClassAttendanceStatusList = response;

                if (this.ClassAttendanceStatusList.length > 1) {
                    this.ClassAttendanceStatusList.unshift({
                        ClassAttendanceStatusID: 0,
                        ClassAttendanceStatusDesc: "All ClassAttendanceStatuss"
                    })
                } else {
                    this.report.ClassAttendanceStatusID = this.ClassAttendanceStatusList[0].ClassAttendanceStatusID
                }


            },
            error => {
            }
        )

    }
    
    private loadClassAttendanceEntryTypeList() {
      
        this.report.ClassAttendanceEntryTypeID = 0;
        var result = this.classAttendanceEntryTypeService.loadClassAttendanceEntryTypeList(this.report.SchoolID);
        result.subscribe(
            response => {
                this.ClassAttendanceEntryTypeList = response;

                if (this.ClassAttendanceEntryTypeList.length > 1) {
                    this.ClassAttendanceEntryTypeList.unshift({
                        ClassAttendanceEntryTypeID: 0,
                        ClassAttendanceEntryTypeDesc: "All ClassAttendanceEntryTypes"
                    })
                } else {
                    this.report.ClassAttendanceEntryTypeID = this.ClassAttendanceEntryTypeList[0].ClassAttendanceEntryTypeID
                }


            },
            error => {
            }
        )

    }
    Print() {

        var component = this;
        this.errorMessage = "";

        //Insert Custom Error Checks Here
		if (!this.report.SchoolID) {
			this.errorMessage = "Select the School"
			return;
		}

		if (!this.report.InstructorID) {
			this.errorMessage = "Select the Instructor"
			return;
		}

		if (!this.report.CourseID) {
			this.errorMessage = "Select the Course"
			return;
		}

		if (!this.report.SectionNo) {
			this.errorMessage = "Select the SectionNo"
			return;
		}

		if (!this.report.StartDate) {
			this.errorMessage = "Select the StartDate"
			return;
		}

		if (!this.report.EndDate) {
			this.errorMessage = "Select the EndDate"
			return;
		}

		if (!this.report.ClassAttendanceStatusID) {
			this.errorMessage = "Select the ClassAttendanceStatus"
			return;
		}

		if (!this.report.ClassAttendanceEntryTypeID) {
			this.errorMessage = "Select the ClassAttendanceEntryType"
			return;
		}

      

        var strParam = "";
        this.isProcessing = true;
    
        //Insert Custom Parameters Here
        //Parameter 1: SchoolID
        strParam += this.report.SchoolID + "|SchoolID";

        //Parameter 2: InstructorID
        strParam += "," + this.report.InstructorID + "|InstructorID";

        //Parameter 3: CourseID
        strParam += "," + this.report.CourseID + "|CourseID";

        //Parameter 4: SectionNo
        strParam += "," + this.report.SectionNo + "|SectionNo";

        //Parameter 5: StartDate
        strParam += "," +  moment(this.report.StartDate).format("MM/DD/YYYY") + "|StartDate";

        //Parameter 6: EndDate
        strParam += "," +  moment(this.report.EndDate).format("MM/DD/YYYY") + "|EndDate";

        //Parameter 7: ClassAttendanceStatusID
        strParam += "," + this.report.ClassAttendanceStatusID + "|ClassAttendanceStatusID";

        //Parameter 8: ClassAttendanceEntryTypeID
        strParam += "," + this.report.ClassAttendanceEntryTypeID + "|ClassAttendanceEntryTypeID";

        //Parameter 9: ImageLogo
        strParam += ",8C87B20B-5813-4F74-8375-9898FD7B0C74|Imagelogo"



        var reportID = 254;

        var result = this.reportService.Print(reportID, strParam, this.report.SchoolID);

        result.subscribe(
            (response: any) => {
                component.isProcessing = false;
                window.open(response);
            },
            error => {
                component.errorMessage = error
                component.isProcessing = false;
            }
        )
    }
}

import { Component, OnInit, AfterViewInit } from '@angular/core';
import { ReportService } from '../report.service';
//Import Custom Services Here
import { SchoolService } from '../../../shared/services/school.service'
import { InstructorService } from '../../../shared/services/instructor.service'
import { Course1Service } from '../../../shared/services/course1.service'
import { Course2Service } from '../../../shared/services/course2.service'
declare var moment: any;


@Component({
    templateUrl: './classattendancetrackingdetails.component.html',

})
export class ClassAttendanceTrackingDetailsComponent implements OnInit {
    constructor(
        private reportService: ReportService,
        //Insert Custom Services Here
        private course2Service: Course2Service,
        private course1Service: Course1Service,
        private instructorService: InstructorService,
        private schoolService: SchoolService,

    ) {

    }
    report = {
        //Insert Custom Parameters Here
        SchoolID: 0,
        StartDate: ,
        EndDate: ,
        InstructorID: 0,
        CourseID1: 0,
        CourseID2: 0,
        CourseLike: "",
        OrderBy: 0,
        ImageLogo: 0,

    }
    //Insert Custom Lists Here
    SchoolList: any = []
    InstructorList: any = []
    Course1List: any = []
    Course2List: any = []
    ImageLogoList: any = []
    

    user: any;
    errorMessage: any = "";
    isProcessing: any = false;
    
    OrderByList = [
        //Insert Custom List Items Here
        {
			OrderByName: 'Average Percent'
        },
        {
			OrderByName: 'Instructor'
        },
        {
			OrderByName: 'Instructor Code'
        }

    ]

    ngOnInit() {
        //Insert Custom Init Methods Here
        this.loadSchoolList()
        this.loadInstructorList()
        this.loadCourse1List()
        this.loadCourse2List()
               
      }
    
    private loadSchoolList() {
      
        this.report.SchoolID = 0;
        var result = this.schoolService.loadSchoolList(this.report.SchoolID);
        result.subscribe(
            response => {
                this.SchoolList = response;

                if (this.SchoolList.length > 1) {
                    this.SchoolList.unshift({
                        SchoolID: 0,
                        SchoolDesc: "All Schools"
                    })
                } else {
                    this.report.SchoolID = this.SchoolList[0].SchoolID
                }


            },
            error => {
            }
        )

    }
    
    private loadInstructorList() {
      
        this.report.InstructorID = 0;
        var result = this.instructorService.loadInstructorList(this.report.SchoolID);
        result.subscribe(
            response => {
                this.InstructorList = response;

                if (this.InstructorList.length > 1) {
                    this.InstructorList.unshift({
                        InstructorID: 0,
                        InstructorDesc: "All Instructors"
                    })
                } else {
                    this.report.InstructorID = this.InstructorList[0].InstructorID
                }


            },
            error => {
            }
        )

    }
    
    private loadCourse1List() {
      
        this.report.Course1ID = 0;
        var result = this.course1Service.loadCourse1List(this.report.SchoolID);
        result.subscribe(
            response => {
                this.Course1List = response;

                if (this.Course1List.length > 1) {
                    this.Course1List.unshift({
                        Course1ID: 0,
                        Course1Desc: "All Course1s"
                    })
                } else {
                    this.report.Course1ID = this.Course1List[0].Course1ID
                }


            },
            error => {
            }
        )

    }
    
    private loadCourse2List() {
      
        this.report.Course2ID = 0;
        var result = this.course2Service.loadCourse2List(this.report.SchoolID);
        result.subscribe(
            response => {
                this.Course2List = response;

                if (this.Course2List.length > 1) {
                    this.Course2List.unshift({
                        Course2ID: 0,
                        Course2Desc: "All Course2s"
                    })
                } else {
                    this.report.Course2ID = this.Course2List[0].Course2ID
                }


            },
            error => {
            }
        )

    }
    Print() {

        var component = this;
        this.errorMessage = "";

        //Insert Custom Error Checks Here
		if (!this.report.SchoolID) {
			this.errorMessage = "Select the School"
			return;
		}

		if (!this.report.StartDate) {
			this.errorMessage = "Select the StartDate"
			return;
		}

		if (!this.report.EndDate) {
			this.errorMessage = "Select the EndDate"
			return;
		}

		if (!this.report.InstructorID) {
			this.errorMessage = "Select the Instructor"
			return;
		}

		if (!this.report.CourseID1) {
			this.errorMessage = "Select the Course1"
			return;
		}

		if (!this.report.CourseID2) {
			this.errorMessage = "Select the Course2"
			return;
		}

		if (!this.report.CourseLike) {
			this.errorMessage = "Select the CourseLike"
			return;
		}

		if (!this.report.OrderBy) {
			this.errorMessage = "Select the OrderBy"
			return;
		}

      

        var strParam = "";
        this.isProcessing = true;
    
        //Insert Custom Parameters Here
        //Parameter 1: SchoolID
        strParam += this.report.SchoolID + "|SchoolID";

        //Parameter 2: StartDate
        strParam += "," +  moment(this.report.StartDate).format("MM/DD/YYYY") + "|StartDate";

        //Parameter 3: EndDate
        strParam += "," +  moment(this.report.EndDate).format("MM/DD/YYYY") + "|EndDate";

        //Parameter 4: InstructorID
        strParam += "," + this.report.InstructorID + "|InstructorID";

        //Parameter 5: CourseID1
        strParam += "," + this.report.CourseID1 + "|CourseID1";

        //Parameter 6: CourseID2
        strParam += "," + this.report.CourseID2 + "|CourseID2";

        //Parameter 7: CourseLike
        strParam += "," + this.report.CourseLike + "|CourseLike";

        //Parameter 8: OrderBy
        strParam += "," + this.report.OrderBy + "|OrderBy";

        //Parameter 9: ImageLogo
        strParam += ",8C87B20B-5813-4F74-8375-9898FD7B0C74|Imagelogo"



        var reportID = 271;

        var result = this.reportService.Print(reportID, strParam, this.report.SchoolID);

        result.subscribe(
            (response: any) => {
                component.isProcessing = false;
                window.open(response);
            },
            error => {
                component.errorMessage = error
                component.isProcessing = false;
            }
        )
    }
}

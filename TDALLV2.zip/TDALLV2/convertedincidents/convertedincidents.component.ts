import { Component, OnInit, AfterViewInit } from '@angular/core';
import { ReportService } from '../report.service';
//Import Custom Services Here
declare var moment: any;


@Component({
    templateUrl: './convertedincidents.component.html',

})
export class ConvertedIncidentsComponent implements OnInit {
    constructor(
        private reportService: ReportService,
        //Insert Custom Services Here

    ) {

    }
    report = {
        //Insert Custom Parameters Here
        StartDate: ,
        EndDate: ,
        OrderBy: 0,

    }
    //Insert Custom Lists Here
    

    user: any;
    errorMessage: any = "";
    isProcessing: any = false;
    
    OrderByList = [
        //Insert Custom List Items Here
        {
			OrderByName: 'Action'
        },
        {
			OrderByName: 'Date'
        },
        {
			OrderByName: 'Homeroom'
        },
        {
			OrderByName: 'Infraction'
        },
        {
			OrderByName: 'Name'
        }

    ]

    ngOnInit() {
        //Insert Custom Init Methods Here
               
      }
    Print() {

        var component = this;
        this.errorMessage = "";

        //Insert Custom Error Checks Here
		if (!this.report.StartDate) {
			this.errorMessage = "Select the StartDate"
			return;
		}

		if (!this.report.EndDate) {
			this.errorMessage = "Select the EndDate"
			return;
		}

		if (!this.report.OrderBy) {
			this.errorMessage = "Select the OrderBy"
			return;
		}

      

        var strParam = "";
        this.isProcessing = true;
    
        //Insert Custom Parameters Here
        //Parameter 1: StartDate
        strParam +=  moment(this.report.StartDate).format("MM/DD/YYYY") + "|StartDate";

        //Parameter 2: EndDate
        strParam += "," +  moment(this.report.EndDate).format("MM/DD/YYYY") + "|EndDate";

        //Parameter 3: OrderBy
        strParam += "," + this.report.OrderBy + "|OrderBy";



        var reportID = 370;

        var result = this.reportService.Print(reportID, strParam, 202);

        result.subscribe(
            (response: any) => {
                component.isProcessing = false;
                window.open(response);
            },
            error => {
                component.errorMessage = error
                component.isProcessing = false;
            }
        )
    }
}

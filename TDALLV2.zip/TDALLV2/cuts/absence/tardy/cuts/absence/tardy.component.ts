import { Component, OnInit, AfterViewInit } from '@angular/core';
import { ReportService } from '../report.service';
//Import Custom Services Here
import { NumTardiesService } from '../../../shared/services/numtardies.service'
import { NumAbsentsService } from '../../../shared/services/numabsents.service'
import { NumCutsService } from '../../../shared/services/numcuts.service'
declare var moment: any;


@Component({
    templateUrl: './cuts/absence/tardy.component.html',

})
export class Cuts/Absence/TardyComponent implements OnInit {
    constructor(
        private reportService: ReportService,
        //Insert Custom Services Here
        private numcutsService: NumCutsService,
        private numabsentsService: NumAbsentsService,
        private numtardiesService: NumTardiesService,

    ) {

    }
    report = {
        //Insert Custom Parameters Here
        SchoolXML: "",
        StartDate: ,
        EndDate: ,
        NumTardies: 0,
        NumAbsents: 0,
        NumCuts: 0,
        ShowDetail: "",
        OrderBy: 0,
        ImageLogo: 0,

    }
    //Insert Custom Lists Here
    NumTardiesList: any = []
    NumAbsentsList: any = []
    NumCutsList: any = []
    ImageLogoList: any = []
    

    user: any;
    errorMessage: any = "";
    isProcessing: any = false;
    
    ShowDetailList = [
        //Insert Custom List Items Here
        {
			ShowDetailName: 'No'
        },
        {
			ShowDetailName: 'Yes'
        }

    ]

    
    OrderByList = [
        //Insert Custom List Items Here
        {
			OrderByName: 'Cuts'
        },
        {
			OrderByName: 'Absences'
        },
        {
			OrderByName: 'Lates'
        },
        {
			OrderByName: 'Name'
        },
        {
			OrderByName: 'Academy'
        },
        {
			OrderByName: 'Grade'
        },
        {
			OrderByName: 'Homeroom'
        }

    ]

    ngOnInit() {
        //Insert Custom Init Methods Here
        this.loadNumTardiesList()
        this.loadNumAbsentsList()
        this.loadNumCutsList()
               
      }
    
    private loadNumTardiesList() {
      
        this.report.NumTardiesID = 0;
        var result = this.numTardiesService.loadNumTardiesList(this.report.SchoolID);
        result.subscribe(
            response => {
                this.NumTardiesList = response;

                if (this.NumTardiesList.length > 1) {
                    this.NumTardiesList.unshift({
                        NumTardiesID: 0,
                        NumTardiesDesc: "All NumTardiess"
                    })
                } else {
                    this.report.NumTardiesID = this.NumTardiesList[0].NumTardiesID
                }


            },
            error => {
            }
        )

    }
    
    private loadNumAbsentsList() {
      
        this.report.NumAbsentsID = 0;
        var result = this.numAbsentsService.loadNumAbsentsList(this.report.SchoolID);
        result.subscribe(
            response => {
                this.NumAbsentsList = response;

                if (this.NumAbsentsList.length > 1) {
                    this.NumAbsentsList.unshift({
                        NumAbsentsID: 0,
                        NumAbsentsDesc: "All NumAbsentss"
                    })
                } else {
                    this.report.NumAbsentsID = this.NumAbsentsList[0].NumAbsentsID
                }


            },
            error => {
            }
        )

    }
    
    private loadNumCutsList() {
      
        this.report.NumCutsID = 0;
        var result = this.numCutsService.loadNumCutsList(this.report.SchoolID);
        result.subscribe(
            response => {
                this.NumCutsList = response;

                if (this.NumCutsList.length > 1) {
                    this.NumCutsList.unshift({
                        NumCutsID: 0,
                        NumCutsDesc: "All NumCutss"
                    })
                } else {
                    this.report.NumCutsID = this.NumCutsList[0].NumCutsID
                }


            },
            error => {
            }
        )

    }
    Print() {

        var component = this;
        this.errorMessage = "";

        //Insert Custom Error Checks Here
		if (!this.report.SchoolXML) {
			this.errorMessage = "Select the SchoolXML"
			return;
		}

		if (!this.report.StartDate) {
			this.errorMessage = "Select the StartDate"
			return;
		}

		if (!this.report.EndDate) {
			this.errorMessage = "Select the EndDate"
			return;
		}

		if (!this.report.NumTardies) {
			this.errorMessage = "Select the NumTardies"
			return;
		}

		if (!this.report.NumAbsents) {
			this.errorMessage = "Select the NumAbsents"
			return;
		}

		if (!this.report.NumCuts) {
			this.errorMessage = "Select the NumCuts"
			return;
		}

		if (!this.report.ShowDetail) {
			this.errorMessage = "Select the ShowDetail"
			return;
		}

		if (!this.report.OrderBy) {
			this.errorMessage = "Select the OrderBy"
			return;
		}

      

        var strParam = "";
        this.isProcessing = true;
    
        //Insert Custom Parameters Here
        //Parameter 1: SchoolXML
        strParam += this.report.SchoolXML + "|SchoolXML";

        //Parameter 2: StartDate
        strParam += "," +  moment(this.report.StartDate).format("MM/DD/YYYY") + "|StartDate";

        //Parameter 3: EndDate
        strParam += "," +  moment(this.report.EndDate).format("MM/DD/YYYY") + "|EndDate";

        //Parameter 4: NumTardies
        strParam += "," + this.report.NumTardies + "|NumTardies";

        //Parameter 5: NumAbsents
        strParam += "," + this.report.NumAbsents + "|NumAbsents";

        //Parameter 6: NumCuts
        strParam += "," + this.report.NumCuts + "|NumCuts";

        //Parameter 7: ShowDetail
        strParam += "," + this.report.ShowDetail + "|ShowDetail";

        //Parameter 8: OrderBy
        strParam += "," + this.report.OrderBy + "|OrderBy";

        //Parameter 9: ImageLogo
        strParam += ",8C87B20B-5813-4F74-8375-9898FD7B0C74|Imagelogo"



        var reportID = 8;

        var result = this.reportService.Print(reportID, strParam, this.report.SchoolID);

        result.subscribe(
            (response: any) => {
                component.isProcessing = false;
                window.open(response);
            },
            error => {
                component.errorMessage = error
                component.isProcessing = false;
            }
        )
    }
}

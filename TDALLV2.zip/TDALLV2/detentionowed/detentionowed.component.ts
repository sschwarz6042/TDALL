import { Component, OnInit, AfterViewInit } from '@angular/core';
import { ReportService } from '../report.service';
//Import Custom Services Here
import { GradeLevelService } from '../../../shared/services/gradelevel.service'
import { HomeroomService } from '../../../shared/services/homeroom.service'
import { GroupService } from '../../../shared/services/group.service'
declare var moment: any;


@Component({
    templateUrl: './detentionowed.component.html',

})
export class DetentionOwedComponent implements OnInit {
    constructor(
        private reportService: ReportService,
        //Insert Custom Services Here
        private groupService: GroupService,
        private homeroomService: HomeroomService,
        private gradelevelService: GradeLevelService,

    ) {

    }
    report = {
        //Insert Custom Parameters Here
        InfractionType: 0,
        GradeLevelID: 0,
        HomeroomID: 0,
        GroupID: 0,
        StartDate: ,
        EndDate: ,
        OrderBy: 0,
        ImageLogo: 0,

    }
    //Insert Custom Lists Here
    GradeLevelList: any = []
    HomeroomList: any = []
    GroupList: any = []
    ImageLogoList: any = []
    

    user: any;
    errorMessage: any = "";
    isProcessing: any = false;
    
    InfractionTypeList = [
        //Insert Custom List Items Here
        {
			InfractionTypeName: 'All'
        },
        {
			InfractionTypeName: 'Unexcused Tardy'
        },
        {
			InfractionTypeName: 'Detention Not Served'
        }

    ]

    
    OrderByList = [
        //Insert Custom List Items Here
        {
			OrderByName: 'Date'
        },
        {
			OrderByName: 'Grade'
        },
        {
			OrderByName: 'Group'
        },
        {
			OrderByName: 'Homeroom'
        },
        {
			OrderByName: 'Name'
        }

    ]

    ngOnInit() {
        //Insert Custom Init Methods Here
        this.loadGradeLevelList()
        this.loadHomeroomList()
        this.loadGroupList()
               
      }
    
    private loadGradeLevelList() {
      
        this.report.GradeLevelID = 0;
        var result = this.gradeLevelService.loadGradeLevelList(this.report.SchoolID);
        result.subscribe(
            response => {
                this.GradeLevelList = response;

                if (this.GradeLevelList.length > 1) {
                    this.GradeLevelList.unshift({
                        GradeLevelID: 0,
                        GradeLevelDesc: "All GradeLevels"
                    })
                } else {
                    this.report.GradeLevelID = this.GradeLevelList[0].GradeLevelID
                }


            },
            error => {
            }
        )

    }
    
    private loadHomeroomList() {
      
        this.report.HomeroomID = 0;
        var result = this.homeroomService.loadHomeroomList(this.report.SchoolID);
        result.subscribe(
            response => {
                this.HomeroomList = response;

                if (this.HomeroomList.length > 1) {
                    this.HomeroomList.unshift({
                        HomeroomID: 0,
                        HomeroomDesc: "All Homerooms"
                    })
                } else {
                    this.report.HomeroomID = this.HomeroomList[0].HomeroomID
                }


            },
            error => {
            }
        )

    }
    
    private loadGroupList() {
      
        this.report.GroupID = 0;
        var result = this.groupService.loadGroupList(this.report.SchoolID);
        result.subscribe(
            response => {
                this.GroupList = response;

                if (this.GroupList.length > 1) {
                    this.GroupList.unshift({
                        GroupID: 0,
                        GroupDesc: "All Groups"
                    })
                } else {
                    this.report.GroupID = this.GroupList[0].GroupID
                }


            },
            error => {
            }
        )

    }
    Print() {

        var component = this;
        this.errorMessage = "";

        //Insert Custom Error Checks Here
		if (!this.report.InfractionType) {
			this.errorMessage = "Select the InfractionType"
			return;
		}

		if (!this.report.GradeLevelID) {
			this.errorMessage = "Select the GradeLevel"
			return;
		}

		if (!this.report.HomeroomID) {
			this.errorMessage = "Select the Homeroom"
			return;
		}

		if (!this.report.GroupID) {
			this.errorMessage = "Select the Group"
			return;
		}

		if (!this.report.StartDate) {
			this.errorMessage = "Select the StartDate"
			return;
		}

		if (!this.report.EndDate) {
			this.errorMessage = "Select the EndDate"
			return;
		}

		if (!this.report.OrderBy) {
			this.errorMessage = "Select the OrderBy"
			return;
		}

      

        var strParam = "";
        this.isProcessing = true;
    
        //Insert Custom Parameters Here
        //Parameter 1: InfractionType
        strParam += this.report.InfractionType + "|InfractionType";

        //Parameter 2: GradeLevelID
        strParam += "," + this.report.GradeLevelID + "|GradeLevelID";

        //Parameter 3: HomeroomID
        strParam += "," + this.report.HomeroomID + "|HomeroomID";

        //Parameter 4: GroupID
        strParam += "," + this.report.GroupID + "|GroupID";

        //Parameter 5: StartDate
        strParam += "," +  moment(this.report.StartDate).format("MM/DD/YYYY") + "|StartDate";

        //Parameter 6: EndDate
        strParam += "," +  moment(this.report.EndDate).format("MM/DD/YYYY") + "|EndDate";

        //Parameter 7: OrderBy
        strParam += "," + this.report.OrderBy + "|OrderBy";

        //Parameter 8: ImageLogo
        strParam += ",8C87B20B-5813-4F74-8375-9898FD7B0C74|Imagelogo"



        var reportID = 384;

        var result = this.reportService.Print(reportID, strParam, 202);

        result.subscribe(
            (response: any) => {
                component.isProcessing = false;
                window.open(response);
            },
            error => {
                component.errorMessage = error
                component.isProcessing = false;
            }
        )
    }
}

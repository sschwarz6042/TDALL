import { Component, OnInit, AfterViewInit } from '@angular/core';
import { ReportService } from '../report.service';
//Import Custom Services Here
import { SchoolGroupService } from '../../../shared/services/schoolgroup.service'
declare var moment: any;


@Component({
    templateUrl: './entryalertbycontainer.component.html',

})
export class EntryAlertbyContainerComponent implements OnInit {
    constructor(
        private reportService: ReportService,
        //Insert Custom Services Here
        private schoolgroupService: SchoolGroupService,

    ) {

    }
    report = {
        //Insert Custom Parameters Here
        SchoolGroupID: 0,
        Priority: "",
        ORDERBY: "",
        ImageLogo: 0,
        UserID: "",

    }
    //Insert Custom Lists Here
    SchoolGroupList: any = []
    ImageLogoList: any = []
    

    user: any;
    errorMessage: any = "";
    isProcessing: any = false;
    
    PriorityList = [
        //Insert Custom List Items Here
        {
			PriorityName: '1'
        },
        {
			PriorityName: '2'
        },
        {
			PriorityName: '3'
        },
        {
			PriorityName: '4'
        },
        {
			PriorityName: '5'
        }

    ]

    
    ORDERBYList = [
        //Insert Custom List Items Here
        {
			ORDERBYName: 'Infraction'
        },
        {
			ORDERBYName: 'Name'
        },
        {
			ORDERBYName: 'Penalty'
        }

    ]

    ngOnInit() {
        //Insert Custom Init Methods Here
        this.loadSchoolGroupList()
               
      }
    
    private loadSchoolGroupList() {
      
        this.report.SchoolGroupID = 0;
        var result = this.schoolGroupService.loadSchoolGroupList(this.report.SchoolID);
        result.subscribe(
            response => {
                this.SchoolGroupList = response;

                if (this.SchoolGroupList.length > 1) {
                    this.SchoolGroupList.unshift({
                        SchoolGroupID: 0,
                        SchoolGroupDesc: "All SchoolGroups"
                    })
                } else {
                    this.report.SchoolGroupID = this.SchoolGroupList[0].SchoolGroupID
                }


            },
            error => {
            }
        )

    }
    Print() {

        var component = this;
        this.errorMessage = "";

        //Insert Custom Error Checks Here
		if (!this.report.SchoolGroupID) {
			this.errorMessage = "Select the SchoolGroup"
			return;
		}

		if (!this.report.Priority) {
			this.errorMessage = "Select the Priority"
			return;
		}

		if (!this.report.ORDERBY) {
			this.errorMessage = "Select the ORDERBY"
			return;
		}

		if (!this.report.UserID) {
			this.errorMessage = "Select the User"
			return;
		}

      

        var strParam = "";
        this.isProcessing = true;
    
        //Insert Custom Parameters Here
        //Parameter 1: SchoolGroupID
        strParam += this.report.SchoolGroupID + "|SchoolGroupID";

        //Parameter 2: Priority
        strParam += "," + this.report.Priority + "|Priority";

        //Parameter 3: ORDERBY
        strParam += "," + this.report.ORDERBY + "|ORDERBY";

        //Parameter 4: ImageLogo
        strParam += ",8C87B20B-5813-4F74-8375-9898FD7B0C74|Imagelogo"

        //Parameter 5: UserID
        strParam += "," + this.report.UserID + "|UserID";



        var reportID = 392;

        var result = this.reportService.Print(reportID, strParam, this.report.SchoolID);

        result.subscribe(
            (response: any) => {
                component.isProcessing = false;
                window.open(response);
            },
            error => {
                component.errorMessage = error
                component.isProcessing = false;
            }
        )
    }
}

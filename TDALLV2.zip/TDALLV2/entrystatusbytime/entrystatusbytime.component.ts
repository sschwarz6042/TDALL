import { Component, OnInit, AfterViewInit } from '@angular/core';
import { ReportService } from '../report.service';
//Import Custom Services Here
import { SchoolService } from '../../../shared/services/school.service'
import { GradeLevelService } from '../../../shared/services/gradelevel.service'
import { AcademyService } from '../../../shared/services/academy.service'
import { HomeroomService } from '../../../shared/services/homeroom.service'
import { GROUPService } from '../../../shared/services/group.service'
declare var moment: any;


@Component({
    templateUrl: './entrystatusbytime.component.html',

})
export class EntryStatusbyTimeComponent implements OnInit {
    constructor(
        private reportService: ReportService,
        //Insert Custom Services Here
        private groupService: GROUPService,
        private homeroomService: HomeroomService,
        private academyService: AcademyService,
        private gradelevelService: GradeLevelService,
        private schoolService: SchoolService,

    ) {

    }
    report = {
        //Insert Custom Parameters Here
        SchoolID: 0,
        GradeLevelID: 0,
        AcademyID: 0,
        HomeroomID: 0,
        GROUPID: 0,
        STARTDATE: ,
        ENDDATE: ,
        STARTTIME: ,
        ENDTIME: ,
        TIMESFOR: 0,
        ORDERBY: "",
        ImageLogo: 0,

    }
    //Insert Custom Lists Here
    SchoolList: any = []
    GradeLevelList: any = []
    AcademyList: any = []
    HomeroomList: any = []
    GROUPList: any = []
    ImageLogoList: any = []
    

    user: any;
    errorMessage: any = "";
    isProcessing: any = false;
    
    TIMESFORList = [
        //Insert Custom List Items Here
        {
			TIMESFORName: 'Yes'
        },
        {
			TIMESFORName: 'No'
        }

    ]

    
    ORDERBYList = [
        //Insert Custom List Items Here
        {
			ORDERBYName: 'Academy'
        },
        {
			ORDERBYName: 'Entry status'
        },
        {
			ORDERBYName: 'Grade'
        },
        {
			ORDERBYName: 'Homeroom'
        },
        {
			ORDERBYName: 'Name'
        },
        {
			ORDERBYName: 'Time'
        }

    ]

    ngOnInit() {
        //Insert Custom Init Methods Here
        this.loadSchoolList()
        this.loadGradeLevelList()
        this.loadAcademyList()
        this.loadHomeroomList()
        this.loadGROUPList()
               
      }
    
    private loadSchoolList() {
      
        this.report.SchoolID = 0;
        var result = this.schoolService.loadSchoolList(this.report.SchoolID);
        result.subscribe(
            response => {
                this.SchoolList = response;

                if (this.SchoolList.length > 1) {
                    this.SchoolList.unshift({
                        SchoolID: 0,
                        SchoolDesc: "All Schools"
                    })
                } else {
                    this.report.SchoolID = this.SchoolList[0].SchoolID
                }


            },
            error => {
            }
        )

    }
    
    private loadGradeLevelList() {
      
        this.report.GradeLevelID = 0;
        var result = this.gradeLevelService.loadGradeLevelList(this.report.SchoolID);
        result.subscribe(
            response => {
                this.GradeLevelList = response;

                if (this.GradeLevelList.length > 1) {
                    this.GradeLevelList.unshift({
                        GradeLevelID: 0,
                        GradeLevelDesc: "All GradeLevels"
                    })
                } else {
                    this.report.GradeLevelID = this.GradeLevelList[0].GradeLevelID
                }


            },
            error => {
            }
        )

    }
    
    private loadAcademyList() {
      
        this.report.AcademyID = 0;
        var result = this.academyService.loadAcademyList(this.report.SchoolID);
        result.subscribe(
            response => {
                this.AcademyList = response;

                if (this.AcademyList.length > 1) {
                    this.AcademyList.unshift({
                        AcademyID: 0,
                        AcademyDesc: "All Academys"
                    })
                } else {
                    this.report.AcademyID = this.AcademyList[0].AcademyID
                }


            },
            error => {
            }
        )

    }
    
    private loadHomeroomList() {
      
        this.report.HomeroomID = 0;
        var result = this.homeroomService.loadHomeroomList(this.report.SchoolID);
        result.subscribe(
            response => {
                this.HomeroomList = response;

                if (this.HomeroomList.length > 1) {
                    this.HomeroomList.unshift({
                        HomeroomID: 0,
                        HomeroomDesc: "All Homerooms"
                    })
                } else {
                    this.report.HomeroomID = this.HomeroomList[0].HomeroomID
                }


            },
            error => {
            }
        )

    }
    
    private loadGROUPList() {
      
        this.report.GROUPID = 0;
        var result = this.gROUPService.loadGROUPList(this.report.SchoolID);
        result.subscribe(
            response => {
                this.GROUPList = response;

                if (this.GROUPList.length > 1) {
                    this.GROUPList.unshift({
                        GROUPID: 0,
                        GROUPDesc: "All GROUPs"
                    })
                } else {
                    this.report.GROUPID = this.GROUPList[0].GROUPID
                }


            },
            error => {
            }
        )

    }
    Print() {

        var component = this;
        this.errorMessage = "";

        //Insert Custom Error Checks Here
		if (!this.report.SchoolID) {
			this.errorMessage = "Select the School"
			return;
		}

		if (!this.report.GradeLevelID) {
			this.errorMessage = "Select the GradeLevel"
			return;
		}

		if (!this.report.AcademyID) {
			this.errorMessage = "Select the Academy"
			return;
		}

		if (!this.report.HomeroomID) {
			this.errorMessage = "Select the Homeroom"
			return;
		}

		if (!this.report.GROUPID) {
			this.errorMessage = "Select the GROUP"
			return;
		}

		if (!this.report.STARTDATE) {
			this.errorMessage = "Select the STARTDATE"
			return;
		}

		if (!this.report.ENDDATE) {
			this.errorMessage = "Select the ENDDATE"
			return;
		}

		if (!this.report.STARTTIME) {
			this.errorMessage = "Select the STARTTIME"
			return;
		}

		if (!this.report.ENDTIME) {
			this.errorMessage = "Select the ENDTIME"
			return;
		}

		if (!this.report.TIMESFOR) {
			this.errorMessage = "Select the TIMESFOR"
			return;
		}

		if (!this.report.ORDERBY) {
			this.errorMessage = "Select the ORDERBY"
			return;
		}

      

        var strParam = "";
        this.isProcessing = true;
    
        //Insert Custom Parameters Here
        //Parameter 1: SchoolID
        strParam += this.report.SchoolID + "|SchoolID";

        //Parameter 2: GradeLevelID
        strParam += "," + this.report.GradeLevelID + "|GradeLevelID";

        //Parameter 3: AcademyID
        strParam += "," + this.report.AcademyID + "|AcademyID";

        //Parameter 4: HomeroomID
        strParam += "," + this.report.HomeroomID + "|HomeroomID";

        //Parameter 5: GROUPID
        strParam += "," + this.report.GROUPID + "|GROUPID";

        //Parameter 6: STARTDATE
        strParam += "," +  moment(this.report.STARTDATE).format("MM/DD/YYYY") + "|STARTDATE";

        //Parameter 7: ENDDATE
        strParam += "," +  moment(this.report.ENDDATE).format("MM/DD/YYYY") + "|ENDDATE";

        //Parameter 8: STARTTIME
        strParam += "," +  moment(this.report.STARTTIME).format("MM/DD/YYYY") + "|STARTTIME";

        //Parameter 9: ENDTIME
        strParam += "," +  moment(this.report.ENDTIME).format("MM/DD/YYYY") + "|ENDTIME";

        //Parameter 10: TIMESFOR
        strParam += "," + this.report.TIMESFOR + "|TIMESFOR";

        //Parameter 11: ORDERBY
        strParam += "," + this.report.ORDERBY + "|ORDERBY";

        //Parameter 12: ImageLogo
        strParam += ",8C87B20B-5813-4F74-8375-9898FD7B0C74|Imagelogo"



        var reportID = 167;

        var result = this.reportService.Print(reportID, strParam, this.report.SchoolID);

        result.subscribe(
            (response: any) => {
                component.isProcessing = false;
                window.open(response);
            },
            error => {
                component.errorMessage = error
                component.isProcessing = false;
            }
        )
    }
}

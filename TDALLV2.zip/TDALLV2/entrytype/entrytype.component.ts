import { Component, OnInit, AfterViewInit } from '@angular/core';
import { ReportService } from '../report.service';
//Import Custom Services Here
import { SchoolService } from '../../../shared/services/school.service'
import { EntryTypeService } from '../../../shared/services/entrytype.service'
import { NumOfDaysService } from '../../../shared/services/numofdays.service'
declare var moment: any;


@Component({
    templateUrl: './entrytype.component.html',

})
export class EntryTypeComponent implements OnInit {
    constructor(
        private reportService: ReportService,
        //Insert Custom Services Here
        private numofdaysService: NumOfDaysService,
        private entrytypeService: EntryTypeService,
        private schoolService: SchoolService,

    ) {

    }
    report = {
        //Insert Custom Parameters Here
        SchoolID: 0,
        EntryTypeID: 0,
        StartDate: ,
        EndDate: ,
        NumOfDays: 0,
        ImageLogo: 0,

    }
    //Insert Custom Lists Here
    SchoolList: any = []
    EntryTypeList: any = []
    NumOfDaysList: any = []
    ImageLogoList: any = []
    

    user: any;
    errorMessage: any = "";
    isProcessing: any = false;
    ngOnInit() {
        //Insert Custom Init Methods Here
        this.loadSchoolList()
        this.loadEntryTypeList()
        this.loadNumOfDaysList()
               
      }
    
    private loadSchoolList() {
      
        this.report.SchoolID = 0;
        var result = this.schoolService.loadSchoolList(this.report.SchoolID);
        result.subscribe(
            response => {
                this.SchoolList = response;

                if (this.SchoolList.length > 1) {
                    this.SchoolList.unshift({
                        SchoolID: 0,
                        SchoolDesc: "All Schools"
                    })
                } else {
                    this.report.SchoolID = this.SchoolList[0].SchoolID
                }


            },
            error => {
            }
        )

    }
    
    private loadEntryTypeList() {
      
        this.report.EntryTypeID = 0;
        var result = this.entryTypeService.loadEntryTypeList(this.report.SchoolID);
        result.subscribe(
            response => {
                this.EntryTypeList = response;

                if (this.EntryTypeList.length > 1) {
                    this.EntryTypeList.unshift({
                        EntryTypeID: 0,
                        EntryTypeDesc: "All EntryTypes"
                    })
                } else {
                    this.report.EntryTypeID = this.EntryTypeList[0].EntryTypeID
                }


            },
            error => {
            }
        )

    }
    
    private loadNumOfDaysList() {
      
        this.report.NumOfDaysID = 0;
        var result = this.numOfDaysService.loadNumOfDaysList(this.report.SchoolID);
        result.subscribe(
            response => {
                this.NumOfDaysList = response;

                if (this.NumOfDaysList.length > 1) {
                    this.NumOfDaysList.unshift({
                        NumOfDaysID: 0,
                        NumOfDaysDesc: "All NumOfDayss"
                    })
                } else {
                    this.report.NumOfDaysID = this.NumOfDaysList[0].NumOfDaysID
                }


            },
            error => {
            }
        )

    }
    Print() {

        var component = this;
        this.errorMessage = "";

        //Insert Custom Error Checks Here
		if (!this.report.SchoolID) {
			this.errorMessage = "Select the School"
			return;
		}

		if (!this.report.EntryTypeID) {
			this.errorMessage = "Select the EntryType"
			return;
		}

		if (!this.report.StartDate) {
			this.errorMessage = "Select the StartDate"
			return;
		}

		if (!this.report.EndDate) {
			this.errorMessage = "Select the EndDate"
			return;
		}

		if (!this.report.NumOfDays) {
			this.errorMessage = "Select the NumOfDays"
			return;
		}

      

        var strParam = "";
        this.isProcessing = true;
    
        //Insert Custom Parameters Here
        //Parameter 1: SchoolID
        strParam += this.report.SchoolID + "|SchoolID";

        //Parameter 2: EntryTypeID
        strParam += "," + this.report.EntryTypeID + "|EntryTypeID";

        //Parameter 3: StartDate
        strParam += "," +  moment(this.report.StartDate).format("MM/DD/YYYY") + "|StartDate";

        //Parameter 4: EndDate
        strParam += "," +  moment(this.report.EndDate).format("MM/DD/YYYY") + "|EndDate";

        //Parameter 5: NumOfDays
        strParam += "," + this.report.NumOfDays + "|NumOfDays";

        //Parameter 6: ImageLogo
        strParam += ",8C87B20B-5813-4F74-8375-9898FD7B0C74|Imagelogo"



        var reportID = 12;

        var result = this.reportService.Print(reportID, strParam, this.report.SchoolID);

        result.subscribe(
            (response: any) => {
                component.isProcessing = false;
                window.open(response);
            },
            error => {
                component.errorMessage = error
                component.isProcessing = false;
            }
        )
    }
}

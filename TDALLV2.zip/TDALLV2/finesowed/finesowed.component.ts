import { Component, OnInit, AfterViewInit } from '@angular/core';
import { ReportService } from '../report.service';
//Import Custom Services Here
import { BalLoService } from '../../../shared/services/ballo.service'
import { BalHiService } from '../../../shared/services/balhi.service'
declare var moment: any;


@Component({
    templateUrl: './finesowed.component.html',

})
export class FinesOwedComponent implements OnInit {
    constructor(
        private reportService: ReportService,
        //Insert Custom Services Here
        private balhiService: BalHiService,
        private balloService: BalLoService,

    ) {

    }
    report = {
        //Insert Custom Parameters Here
        SchoolXML: "",
        BalLo: ,
        BalHi: ,
        StartDate: ,
        EndDate: ,
        SortBy: "",
        StudentStatus: "",
        ShowDetail: "",
        ImageLogo: 0,

    }
    //Insert Custom Lists Here
    BalLoList: any = []
    BalHiList: any = []
    ImageLogoList: any = []
    

    user: any;
    errorMessage: any = "";
    isProcessing: any = false;
    
    SortByList = [
        //Insert Custom List Items Here
        {
			SortByName: 'Amount'
        },
        {
			SortByName: 'Academy'
        },
        {
			SortByName: 'Grade'
        },
        {
			SortByName: 'Homeroom'
        },
        {
			SortByName: 'Name'
        }

    ]

    
    StudentStatusList = [
        //Insert Custom List Items Here
        {
			StudentStatusName: 'Active'
        },
        {
			StudentStatusName: 'Inactive'
        },
        {
			StudentStatusName: 'All'
        }

    ]

    
    ShowDetailList = [
        //Insert Custom List Items Here
        {
			ShowDetailName: 'No'
        },
        {
			ShowDetailName: 'Yes'
        }

    ]

    ngOnInit() {
        //Insert Custom Init Methods Here
        this.loadBalLoList()
        this.loadBalHiList()
               
      }
    
    private loadBalLoList() {
      
        this.report.BalLoID = 0;
        var result = this.balLoService.loadBalLoList(this.report.SchoolID);
        result.subscribe(
            response => {
                this.BalLoList = response;

                if (this.BalLoList.length > 1) {
                    this.BalLoList.unshift({
                        BalLoID: 0,
                        BalLoDesc: "All BalLos"
                    })
                } else {
                    this.report.BalLoID = this.BalLoList[0].BalLoID
                }


            },
            error => {
            }
        )

    }
    
    private loadBalHiList() {
      
        this.report.BalHiID = 0;
        var result = this.balHiService.loadBalHiList(this.report.SchoolID);
        result.subscribe(
            response => {
                this.BalHiList = response;

                if (this.BalHiList.length > 1) {
                    this.BalHiList.unshift({
                        BalHiID: 0,
                        BalHiDesc: "All BalHis"
                    })
                } else {
                    this.report.BalHiID = this.BalHiList[0].BalHiID
                }


            },
            error => {
            }
        )

    }
    Print() {

        var component = this;
        this.errorMessage = "";

        //Insert Custom Error Checks Here
		if (!this.report.SchoolXML) {
			this.errorMessage = "Select the SchoolXML"
			return;
		}

		if (!this.report.BalLo) {
			this.errorMessage = "Select the BalLo"
			return;
		}

		if (!this.report.BalHi) {
			this.errorMessage = "Select the BalHi"
			return;
		}

		if (!this.report.StartDate) {
			this.errorMessage = "Select the StartDate"
			return;
		}

		if (!this.report.EndDate) {
			this.errorMessage = "Select the EndDate"
			return;
		}

		if (!this.report.SortBy) {
			this.errorMessage = "Select the SortBy"
			return;
		}

		if (!this.report.StudentStatus) {
			this.errorMessage = "Select the StudentStatus"
			return;
		}

		if (!this.report.ShowDetail) {
			this.errorMessage = "Select the ShowDetail"
			return;
		}

      

        var strParam = "";
        this.isProcessing = true;
    
        //Insert Custom Parameters Here
        //Parameter 1: SchoolXML
        strParam += this.report.SchoolXML + "|SchoolXML";

        //Parameter 2: BalLo
        strParam += "," + this.report.BalLo + "|BalLo";

        //Parameter 3: BalHi
        strParam += "," + this.report.BalHi + "|BalHi";

        //Parameter 4: StartDate
        strParam += "," +  moment(this.report.StartDate).format("MM/DD/YYYY") + "|StartDate";

        //Parameter 5: EndDate
        strParam += "," +  moment(this.report.EndDate).format("MM/DD/YYYY") + "|EndDate";

        //Parameter 6: SortBy
        strParam += "," + this.report.SortBy + "|SortBy";

        //Parameter 7: StudentStatus
        strParam += "," + this.report.StudentStatus + "|StudentStatus";

        //Parameter 8: ShowDetail
        strParam += "," + this.report.ShowDetail + "|ShowDetail";

        //Parameter 9: ImageLogo
        strParam += ",8C87B20B-5813-4F74-8375-9898FD7B0C74|Imagelogo"



        var reportID = 233;

        var result = this.reportService.Print(reportID, strParam, this.report.SchoolID);

        result.subscribe(
            (response: any) => {
                component.isProcessing = false;
                window.open(response);
            },
            error => {
                component.errorMessage = error
                component.isProcessing = false;
            }
        )
    }
}

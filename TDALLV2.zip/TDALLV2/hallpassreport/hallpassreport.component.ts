import { Component, OnInit, AfterViewInit } from '@angular/core';
import { ReportService } from '../report.service';
//Import Custom Services Here
import { SchoolService } from '../../../shared/services/school.service'
import { ReasonService } from '../../../shared/services/reason.service'
declare var moment: any;


@Component({
    templateUrl: './hallpassreport.component.html',

})
export class HallPassReportComponent implements OnInit {
    constructor(
        private reportService: ReportService,
        //Insert Custom Services Here
        private reasonService: ReasonService,
        private schoolService: SchoolService,

    ) {

    }
    report = {
        //Insert Custom Parameters Here
        SchoolID: 0,
        StartDate: ,
        EndDate: ,
        ReasonID: 0,
        OrderBy: 0,
        ImageLogo: 0,
        ShowDetail: 0,

    }
    //Insert Custom Lists Here
    SchoolList: any = []
    ReasonList: any = []
    ImageLogoList: any = []
    

    user: any;
    errorMessage: any = "";
    isProcessing: any = false;
    
    OrderByList = [
        //Insert Custom List Items Here
        {
			OrderByName: 'Duration'
        },
        {
			OrderByName: 'Date'
        },
        {
			OrderByName: 'Name'
        },
        {
			OrderByName: 'Reason'
        },
        {
			OrderByName: 'Start Time'
        }

    ]

    
    ShowDetailList = [
        //Insert Custom List Items Here
        {
			ShowDetailName: 'No'
        },
        {
			ShowDetailName: 'Yes'
        }

    ]

    ngOnInit() {
        //Insert Custom Init Methods Here
        this.loadSchoolList()
        this.loadReasonList()
               
      }
    
    private loadSchoolList() {
      
        this.report.SchoolID = 0;
        var result = this.schoolService.loadSchoolList(this.report.SchoolID);
        result.subscribe(
            response => {
                this.SchoolList = response;

                if (this.SchoolList.length > 1) {
                    this.SchoolList.unshift({
                        SchoolID: 0,
                        SchoolDesc: "All Schools"
                    })
                } else {
                    this.report.SchoolID = this.SchoolList[0].SchoolID
                }


            },
            error => {
            }
        )

    }
    
    private loadReasonList() {
      
        this.report.ReasonID = 0;
        var result = this.reasonService.loadReasonList(this.report.SchoolID);
        result.subscribe(
            response => {
                this.ReasonList = response;

                if (this.ReasonList.length > 1) {
                    this.ReasonList.unshift({
                        ReasonID: 0,
                        ReasonDesc: "All Reasons"
                    })
                } else {
                    this.report.ReasonID = this.ReasonList[0].ReasonID
                }


            },
            error => {
            }
        )

    }
    Print() {

        var component = this;
        this.errorMessage = "";

        //Insert Custom Error Checks Here
		if (!this.report.SchoolID) {
			this.errorMessage = "Select the School"
			return;
		}

		if (!this.report.StartDate) {
			this.errorMessage = "Select the StartDate"
			return;
		}

		if (!this.report.EndDate) {
			this.errorMessage = "Select the EndDate"
			return;
		}

		if (!this.report.ReasonID) {
			this.errorMessage = "Select the Reason"
			return;
		}

		if (!this.report.OrderBy) {
			this.errorMessage = "Select the OrderBy"
			return;
		}

		if (!this.report.ShowDetail) {
			this.errorMessage = "Select the ShowDetail"
			return;
		}

      

        var strParam = "";
        this.isProcessing = true;
    
        //Insert Custom Parameters Here
        //Parameter 1: SchoolID
        strParam += this.report.SchoolID + "|SchoolID";

        //Parameter 2: StartDate
        strParam += "," +  moment(this.report.StartDate).format("MM/DD/YYYY") + "|StartDate";

        //Parameter 3: EndDate
        strParam += "," +  moment(this.report.EndDate).format("MM/DD/YYYY") + "|EndDate";

        //Parameter 4: ReasonID
        strParam += "," + this.report.ReasonID + "|ReasonID";

        //Parameter 5: OrderBy
        strParam += "," + this.report.OrderBy + "|OrderBy";

        //Parameter 6: ImageLogo
        strParam += ",8C87B20B-5813-4F74-8375-9898FD7B0C74|Imagelogo"

        //Parameter 7: ShowDetail
        strParam += "," + this.report.ShowDetail + "|ShowDetail";



        var reportID = 348;

        var result = this.reportService.Print(reportID, strParam, this.report.SchoolID);

        result.subscribe(
            (response: any) => {
                component.isProcessing = false;
                window.open(response);
            },
            error => {
                component.errorMessage = error
                component.isProcessing = false;
            }
        )
    }
}

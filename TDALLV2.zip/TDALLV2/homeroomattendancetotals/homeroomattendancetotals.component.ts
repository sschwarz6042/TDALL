import { Component, OnInit, AfterViewInit } from '@angular/core';
import { ReportService } from '../report.service';
//Import Custom Services Here
import { HomeRoomService } from '../../../shared/services/homeroom.service'
declare var moment: any;


@Component({
    templateUrl: './homeroomattendancetotals.component.html',

})
export class HomeroomAttendanceTotalsComponent implements OnInit {
    constructor(
        private reportService: ReportService,
        //Insert Custom Services Here
        private homeroomService: HomeRoomService,

    ) {

    }
    report = {
        //Insert Custom Parameters Here
        SchoolXML: "",
        HomeRoomID: 0,
        STARTDATE: ,
        ENDDATE: ,
        ShowDetail: "",
        ImageLogo: 0,

    }
    //Insert Custom Lists Here
    HomeRoomList: any = []
    ImageLogoList: any = []
    

    user: any;
    errorMessage: any = "";
    isProcessing: any = false;
    
    ShowDetailList = [
        //Insert Custom List Items Here
        {
			ShowDetailName: 'No'
        },
        {
			ShowDetailName: 'Yes'
        }

    ]

    ngOnInit() {
        //Insert Custom Init Methods Here
        this.loadHomeRoomList()
               
      }
    
    private loadHomeRoomList() {
      
        this.report.HomeRoomID = 0;
        var result = this.homeRoomService.loadHomeRoomList(this.report.SchoolID);
        result.subscribe(
            response => {
                this.HomeRoomList = response;

                if (this.HomeRoomList.length > 1) {
                    this.HomeRoomList.unshift({
                        HomeRoomID: 0,
                        HomeRoomDesc: "All HomeRooms"
                    })
                } else {
                    this.report.HomeRoomID = this.HomeRoomList[0].HomeRoomID
                }


            },
            error => {
            }
        )

    }
    Print() {

        var component = this;
        this.errorMessage = "";

        //Insert Custom Error Checks Here
		if (!this.report.SchoolXML) {
			this.errorMessage = "Select the SchoolXML"
			return;
		}

		if (!this.report.HomeRoomID) {
			this.errorMessage = "Select the HomeRoom"
			return;
		}

		if (!this.report.STARTDATE) {
			this.errorMessage = "Select the STARTDATE"
			return;
		}

		if (!this.report.ENDDATE) {
			this.errorMessage = "Select the ENDDATE"
			return;
		}

		if (!this.report.ShowDetail) {
			this.errorMessage = "Select the ShowDetail"
			return;
		}

      

        var strParam = "";
        this.isProcessing = true;
    
        //Insert Custom Parameters Here
        //Parameter 1: SchoolXML
        strParam += this.report.SchoolXML + "|SchoolXML";

        //Parameter 2: HomeRoomID
        strParam += "," + this.report.HomeRoomID + "|HomeRoomID";

        //Parameter 3: STARTDATE
        strParam += "," +  moment(this.report.STARTDATE).format("MM/DD/YYYY") + "|STARTDATE";

        //Parameter 4: ENDDATE
        strParam += "," +  moment(this.report.ENDDATE).format("MM/DD/YYYY") + "|ENDDATE";

        //Parameter 5: ShowDetail
        strParam += "," + this.report.ShowDetail + "|ShowDetail";

        //Parameter 6: ImageLogo
        strParam += ",8C87B20B-5813-4F74-8375-9898FD7B0C74|Imagelogo"



        var reportID = 152;

        var result = this.reportService.Print(reportID, strParam, this.report.SchoolID);

        result.subscribe(
            (response: any) => {
                component.isProcessing = false;
                window.open(response);
            },
            error => {
                component.errorMessage = error
                component.isProcessing = false;
            }
        )
    }
}

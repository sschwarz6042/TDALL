import { Component, OnInit, AfterViewInit } from '@angular/core';
import { ReportService } from '../report.service';
//Import Custom Services Here
import { GradeLevelService } from '../../../shared/services/gradelevel.service'
import { ACADEMYService } from '../../../shared/services/academy.service'
import { HOMEROOMService } from '../../../shared/services/homeroom.service'
import { GROUPService } from '../../../shared/services/group.service'
declare var moment: any;


@Component({
    templateUrl: './idcardsprinted.component.html',

})
export class IDCardsPrintedComponent implements OnInit {
    constructor(
        private reportService: ReportService,
        //Insert Custom Services Here
        private groupService: GROUPService,
        private homeroomService: HOMEROOMService,
        private academyService: ACADEMYService,
        private gradelevelService: GradeLevelService,

    ) {

    }
    report = {
        //Insert Custom Parameters Here
        GradeLevelID: 0,
        ACADEMYID: 0,
        HOMEROOMID: 0,
        GROUPID: 0,
        STARTDATE: ,
        ENDDATE: ,
        ORDERBY: "",

    }
    //Insert Custom Lists Here
    GradeLevelList: any = []
    ACADEMYList: any = []
    HOMEROOMList: any = []
    GROUPList: any = []
    

    user: any;
    errorMessage: any = "";
    isProcessing: any = false;
    
    ORDERBYList = [
        //Insert Custom List Items Here
        {
			ORDERBYName: 'Academy'
        },
        {
			ORDERBYName: 'Grade'
        },
        {
			ORDERBYName: 'Homeroom'
        },
        {
			ORDERBYName: 'Issue Date'
        },
        {
			ORDERBYName: 'Name'
        }

    ]

    ngOnInit() {
        //Insert Custom Init Methods Here
        this.loadGradeLevelList()
        this.loadACADEMYList()
        this.loadHOMEROOMList()
        this.loadGROUPList()
               
      }
    
    private loadGradeLevelList() {
      
        this.report.GradeLevelID = 0;
        var result = this.gradeLevelService.loadGradeLevelList(this.report.SchoolID);
        result.subscribe(
            response => {
                this.GradeLevelList = response;

                if (this.GradeLevelList.length > 1) {
                    this.GradeLevelList.unshift({
                        GradeLevelID: 0,
                        GradeLevelDesc: "All GradeLevels"
                    })
                } else {
                    this.report.GradeLevelID = this.GradeLevelList[0].GradeLevelID
                }


            },
            error => {
            }
        )

    }
    
    private loadACADEMYList() {
      
        this.report.ACADEMYID = 0;
        var result = this.aCADEMYService.loadACADEMYList(this.report.SchoolID);
        result.subscribe(
            response => {
                this.ACADEMYList = response;

                if (this.ACADEMYList.length > 1) {
                    this.ACADEMYList.unshift({
                        ACADEMYID: 0,
                        ACADEMYDesc: "All ACADEMYs"
                    })
                } else {
                    this.report.ACADEMYID = this.ACADEMYList[0].ACADEMYID
                }


            },
            error => {
            }
        )

    }
    
    private loadHOMEROOMList() {
      
        this.report.HOMEROOMID = 0;
        var result = this.hOMEROOMService.loadHOMEROOMList(this.report.SchoolID);
        result.subscribe(
            response => {
                this.HOMEROOMList = response;

                if (this.HOMEROOMList.length > 1) {
                    this.HOMEROOMList.unshift({
                        HOMEROOMID: 0,
                        HOMEROOMDesc: "All HOMEROOMs"
                    })
                } else {
                    this.report.HOMEROOMID = this.HOMEROOMList[0].HOMEROOMID
                }


            },
            error => {
            }
        )

    }
    
    private loadGROUPList() {
      
        this.report.GROUPID = 0;
        var result = this.gROUPService.loadGROUPList(this.report.SchoolID);
        result.subscribe(
            response => {
                this.GROUPList = response;

                if (this.GROUPList.length > 1) {
                    this.GROUPList.unshift({
                        GROUPID: 0,
                        GROUPDesc: "All GROUPs"
                    })
                } else {
                    this.report.GROUPID = this.GROUPList[0].GROUPID
                }


            },
            error => {
            }
        )

    }
    Print() {

        var component = this;
        this.errorMessage = "";

        //Insert Custom Error Checks Here
		if (!this.report.GradeLevelID) {
			this.errorMessage = "Select the GradeLevel"
			return;
		}

		if (!this.report.ACADEMYID) {
			this.errorMessage = "Select the ACADEMY"
			return;
		}

		if (!this.report.HOMEROOMID) {
			this.errorMessage = "Select the HOMEROOM"
			return;
		}

		if (!this.report.GROUPID) {
			this.errorMessage = "Select the GROUP"
			return;
		}

		if (!this.report.STARTDATE) {
			this.errorMessage = "Select the STARTDATE"
			return;
		}

		if (!this.report.ENDDATE) {
			this.errorMessage = "Select the ENDDATE"
			return;
		}

		if (!this.report.ORDERBY) {
			this.errorMessage = "Select the ORDERBY"
			return;
		}

      

        var strParam = "";
        this.isProcessing = true;
    
        //Insert Custom Parameters Here
        //Parameter 1: GradeLevelID
        strParam += this.report.GradeLevelID + "|GradeLevelID";

        //Parameter 2: ACADEMYID
        strParam += "," + this.report.ACADEMYID + "|ACADEMYID";

        //Parameter 3: HOMEROOMID
        strParam += "," + this.report.HOMEROOMID + "|HOMEROOMID";

        //Parameter 4: GROUPID
        strParam += "," + this.report.GROUPID + "|GROUPID";

        //Parameter 5: STARTDATE
        strParam += "," +  moment(this.report.STARTDATE).format("MM/DD/YYYY") + "|STARTDATE";

        //Parameter 6: ENDDATE
        strParam += "," +  moment(this.report.ENDDATE).format("MM/DD/YYYY") + "|ENDDATE";

        //Parameter 7: ORDERBY
        strParam += "," + this.report.ORDERBY + "|ORDERBY";



        var reportID = 162;

        var result = this.reportService.Print(reportID, strParam, 202);

        result.subscribe(
            (response: any) => {
                component.isProcessing = false;
                window.open(response);
            },
            error => {
                component.errorMessage = error
                component.isProcessing = false;
            }
        )
    }
}

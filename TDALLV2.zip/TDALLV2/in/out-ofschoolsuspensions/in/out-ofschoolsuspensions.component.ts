import { Component, OnInit, AfterViewInit } from '@angular/core';
import { ReportService } from '../report.service';
//Import Custom Services Here
declare var moment: any;


@Component({
    templateUrl: './in/out-ofschoolsuspensions.component.html',

})
export class In/Out-ofSchoolSuspensionsComponent implements OnInit {
    constructor(
        private reportService: ReportService,
        //Insert Custom Services Here

    ) {

    }
    report = {
        //Insert Custom Parameters Here
        SchoolXML: "",
        StartDate: ,
        EndDate: ,
        ShowDetail: "",
        ImageLogo: 0,

    }
    //Insert Custom Lists Here
    ImageLogoList: any = []
    

    user: any;
    errorMessage: any = "";
    isProcessing: any = false;
    
    ShowDetailList = [
        //Insert Custom List Items Here
        {
			ShowDetailName: 'No'
        },
        {
			ShowDetailName: 'Yes'
        }

    ]

    ngOnInit() {
        //Insert Custom Init Methods Here
               
      }
    Print() {

        var component = this;
        this.errorMessage = "";

        //Insert Custom Error Checks Here
		if (!this.report.SchoolXML) {
			this.errorMessage = "Select the SchoolXML"
			return;
		}

		if (!this.report.StartDate) {
			this.errorMessage = "Select the StartDate"
			return;
		}

		if (!this.report.EndDate) {
			this.errorMessage = "Select the EndDate"
			return;
		}

		if (!this.report.ShowDetail) {
			this.errorMessage = "Select the ShowDetail"
			return;
		}

      

        var strParam = "";
        this.isProcessing = true;
    
        //Insert Custom Parameters Here
        //Parameter 1: SchoolXML
        strParam += this.report.SchoolXML + "|SchoolXML";

        //Parameter 2: StartDate
        strParam += "," +  moment(this.report.StartDate).format("MM/DD/YYYY") + "|StartDate";

        //Parameter 3: EndDate
        strParam += "," +  moment(this.report.EndDate).format("MM/DD/YYYY") + "|EndDate";

        //Parameter 4: ShowDetail
        strParam += "," + this.report.ShowDetail + "|ShowDetail";

        //Parameter 5: ImageLogo
        strParam += ",8C87B20B-5813-4F74-8375-9898FD7B0C74|Imagelogo"



        var reportID = 331;

        var result = this.reportService.Print(reportID, strParam, this.report.SchoolID);

        result.subscribe(
            (response: any) => {
                component.isProcessing = false;
                window.open(response);
            },
            error => {
                component.errorMessage = error
                component.isProcessing = false;
            }
        )
    }
}

import { Component, OnInit, AfterViewInit } from '@angular/core';
import { ReportService } from '../report.service';
//Import Custom Services Here
import { DistrictSchoolService } from '../../../shared/services/districtschool.service'
import { ActionTypeService } from '../../../shared/services/actiontype.service'
import { SchoolGroupService } from '../../../shared/services/schoolgroup.service'
import { ExclusionService } from '../../../shared/services/exclusion.service'
declare var moment: any;


@Component({
    templateUrl: './incidentsbycohort.component.html',

})
export class IncidentsbyCohortComponent implements OnInit {
    constructor(
        private reportService: ReportService,
        //Insert Custom Services Here
        private exclusionService: ExclusionService,
        private schoolgroupService: SchoolGroupService,
        private actiontypeService: ActionTypeService,
        private districtschoolService: DistrictSchoolService,

    ) {

    }
    report = {
        //Insert Custom Parameters Here
        DistrictSchoolID: 0,
        StartDate: ,
        EndDate: ,
        ActionType: 0,
        SchoolGroupID: 0,
        ShowDetail: "",
        Exclusion: "",
        ImageLogo: 0,

    }
    //Insert Custom Lists Here
    DistrictSchoolList: any = []
    ActionTypeList: any = []
    SchoolGroupList: any = []
    ExclusionList: any = []
    ImageLogoList: any = []
    

    user: any;
    errorMessage: any = "";
    isProcessing: any = false;
    
    ShowDetailList = [
        //Insert Custom List Items Here
        {
			ShowDetailName: 'No'
        },
        {
			ShowDetailName: 'Yes'
        }

    ]

    
    ExclusionList = [
        //Insert Custom List Items Here
        {
			ExclusionName: 'All'
        },
        {
			ExclusionName: 'None'
        },
        {
			ExclusionName: 'Suspended Entry'
        },
        {
			ExclusionName: 'Emergency Condition'
        }

    ]

    ngOnInit() {
        //Insert Custom Init Methods Here
        this.loadDistrictSchoolList()
        this.loadActionTypeList()
        this.loadSchoolGroupList()
        this.loadExclusionList()
               
      }
    
    private loadDistrictSchoolList() {
      
        this.report.DistrictSchoolID = 0;
        var result = this.districtSchoolService.loadDistrictSchoolList(this.report.SchoolID);
        result.subscribe(
            response => {
                this.DistrictSchoolList = response;

                if (this.DistrictSchoolList.length > 1) {
                    this.DistrictSchoolList.unshift({
                        DistrictSchoolID: 0,
                        DistrictSchoolDesc: "All DistrictSchools"
                    })
                } else {
                    this.report.DistrictSchoolID = this.DistrictSchoolList[0].DistrictSchoolID
                }


            },
            error => {
            }
        )

    }
    
    private loadActionTypeList() {
      
        this.report.ActionTypeID = 0;
        var result = this.actionTypeService.loadActionTypeList(this.report.SchoolID);
        result.subscribe(
            response => {
                this.ActionTypeList = response;

                if (this.ActionTypeList.length > 1) {
                    this.ActionTypeList.unshift({
                        ActionTypeID: 0,
                        ActionTypeDesc: "All ActionTypes"
                    })
                } else {
                    this.report.ActionTypeID = this.ActionTypeList[0].ActionTypeID
                }


            },
            error => {
            }
        )

    }
    
    private loadSchoolGroupList() {
      
        this.report.SchoolGroupID = 0;
        var result = this.schoolGroupService.loadSchoolGroupList(this.report.SchoolID);
        result.subscribe(
            response => {
                this.SchoolGroupList = response;

                if (this.SchoolGroupList.length > 1) {
                    this.SchoolGroupList.unshift({
                        SchoolGroupID: 0,
                        SchoolGroupDesc: "All SchoolGroups"
                    })
                } else {
                    this.report.SchoolGroupID = this.SchoolGroupList[0].SchoolGroupID
                }


            },
            error => {
            }
        )

    }
    
    private loadExclusionList() {
      
        this.report.ExclusionID = 0;
        var result = this.exclusionService.loadExclusionList(this.report.SchoolID);
        result.subscribe(
            response => {
                this.ExclusionList = response;

                if (this.ExclusionList.length > 1) {
                    this.ExclusionList.unshift({
                        ExclusionID: 0,
                        ExclusionDesc: "All Exclusions"
                    })
                } else {
                    this.report.ExclusionID = this.ExclusionList[0].ExclusionID
                }


            },
            error => {
            }
        )

    }
    Print() {

        var component = this;
        this.errorMessage = "";

        //Insert Custom Error Checks Here
		if (!this.report.DistrictSchoolID) {
			this.errorMessage = "Select the DistrictSchool"
			return;
		}

		if (!this.report.StartDate) {
			this.errorMessage = "Select the StartDate"
			return;
		}

		if (!this.report.EndDate) {
			this.errorMessage = "Select the EndDate"
			return;
		}

		if (!this.report.ActionType) {
			this.errorMessage = "Select the ActionType"
			return;
		}

		if (!this.report.SchoolGroupID) {
			this.errorMessage = "Select the SchoolGroup"
			return;
		}

		if (!this.report.ShowDetail) {
			this.errorMessage = "Select the ShowDetail"
			return;
		}

		if (!this.report.Exclusion) {
			this.errorMessage = "Select the Exclusion"
			return;
		}

      

        var strParam = "";
        this.isProcessing = true;
    
        //Insert Custom Parameters Here
        //Parameter 1: DistrictSchoolID
        strParam += this.report.DistrictSchoolID + "|DistrictSchoolID";

        //Parameter 2: StartDate
        strParam += "," +  moment(this.report.StartDate).format("MM/DD/YYYY") + "|StartDate";

        //Parameter 3: EndDate
        strParam += "," +  moment(this.report.EndDate).format("MM/DD/YYYY") + "|EndDate";

        //Parameter 4: ActionType
        strParam += "," + this.report.ActionType + "|ActionType";

        //Parameter 5: SchoolGroupID
        strParam += "," + this.report.SchoolGroupID + "|SchoolGroupID";

        //Parameter 6: ShowDetail
        strParam += "," + this.report.ShowDetail + "|ShowDetail";

        //Parameter 7: Exclusion
        strParam += "," + this.report.Exclusion + "|Exclusion";

        //Parameter 8: ImageLogo
        strParam += ",8C87B20B-5813-4F74-8375-9898FD7B0C74|Imagelogo"



        var reportID = 323;

        var result = this.reportService.Print(reportID, strParam, this.report.SchoolID);

        result.subscribe(
            (response: any) => {
                component.isProcessing = false;
                window.open(response);
            },
            error => {
                component.errorMessage = error
                component.isProcessing = false;
            }
        )
    }
}

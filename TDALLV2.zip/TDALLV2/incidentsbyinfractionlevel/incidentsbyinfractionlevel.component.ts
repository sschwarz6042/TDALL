import { Component, OnInit, AfterViewInit } from '@angular/core';
import { ReportService } from '../report.service';
//Import Custom Services Here
import { DistrictSchoolService } from '../../../shared/services/districtschool.service'
import { ActionTypeService } from '../../../shared/services/actiontype.service'
import { InfractionLevelService } from '../../../shared/services/infractionlevel.service'
import { SchoolGroupService } from '../../../shared/services/schoolgroup.service'
declare var moment: any;


@Component({
    templateUrl: './incidentsbyinfractionlevel.component.html',

})
export class IncidentsbyInfractionLevelComponent implements OnInit {
    constructor(
        private reportService: ReportService,
        //Insert Custom Services Here
        private schoolgroupService: SchoolGroupService,
        private infractionlevelService: InfractionLevelService,
        private actiontypeService: ActionTypeService,
        private districtschoolService: DistrictSchoolService,

    ) {

    }
    report = {
        //Insert Custom Parameters Here
        DistrictSchoolID: 0,
        StartDate: ,
        EndDate: ,
        ActionType: 0,
        InfractionLevelID: 0,
        SchoolGroupID: 0,
        ShowDetail: "",
        ImageLogo: 0,

    }
    //Insert Custom Lists Here
    DistrictSchoolList: any = []
    ActionTypeList: any = []
    InfractionLevelList: any = []
    SchoolGroupList: any = []
    ImageLogoList: any = []
    

    user: any;
    errorMessage: any = "";
    isProcessing: any = false;
    
    ShowDetailList = [
        //Insert Custom List Items Here
        {
			ShowDetailName: 'No'
        },
        {
			ShowDetailName: 'Yes'
        }

    ]

    ngOnInit() {
        //Insert Custom Init Methods Here
        this.loadDistrictSchoolList()
        this.loadActionTypeList()
        this.loadInfractionLevelList()
        this.loadSchoolGroupList()
               
      }
    
    private loadDistrictSchoolList() {
      
        this.report.DistrictSchoolID = 0;
        var result = this.districtSchoolService.loadDistrictSchoolList(this.report.SchoolID);
        result.subscribe(
            response => {
                this.DistrictSchoolList = response;

                if (this.DistrictSchoolList.length > 1) {
                    this.DistrictSchoolList.unshift({
                        DistrictSchoolID: 0,
                        DistrictSchoolDesc: "All DistrictSchools"
                    })
                } else {
                    this.report.DistrictSchoolID = this.DistrictSchoolList[0].DistrictSchoolID
                }


            },
            error => {
            }
        )

    }
    
    private loadActionTypeList() {
      
        this.report.ActionTypeID = 0;
        var result = this.actionTypeService.loadActionTypeList(this.report.SchoolID);
        result.subscribe(
            response => {
                this.ActionTypeList = response;

                if (this.ActionTypeList.length > 1) {
                    this.ActionTypeList.unshift({
                        ActionTypeID: 0,
                        ActionTypeDesc: "All ActionTypes"
                    })
                } else {
                    this.report.ActionTypeID = this.ActionTypeList[0].ActionTypeID
                }


            },
            error => {
            }
        )

    }
    
    private loadInfractionLevelList() {
      
        this.report.InfractionLevelID = 0;
        var result = this.infractionLevelService.loadInfractionLevelList(this.report.SchoolID);
        result.subscribe(
            response => {
                this.InfractionLevelList = response;

                if (this.InfractionLevelList.length > 1) {
                    this.InfractionLevelList.unshift({
                        InfractionLevelID: 0,
                        InfractionLevelDesc: "All InfractionLevels"
                    })
                } else {
                    this.report.InfractionLevelID = this.InfractionLevelList[0].InfractionLevelID
                }


            },
            error => {
            }
        )

    }
    
    private loadSchoolGroupList() {
      
        this.report.SchoolGroupID = 0;
        var result = this.schoolGroupService.loadSchoolGroupList(this.report.SchoolID);
        result.subscribe(
            response => {
                this.SchoolGroupList = response;

                if (this.SchoolGroupList.length > 1) {
                    this.SchoolGroupList.unshift({
                        SchoolGroupID: 0,
                        SchoolGroupDesc: "All SchoolGroups"
                    })
                } else {
                    this.report.SchoolGroupID = this.SchoolGroupList[0].SchoolGroupID
                }


            },
            error => {
            }
        )

    }
    Print() {

        var component = this;
        this.errorMessage = "";

        //Insert Custom Error Checks Here
		if (!this.report.DistrictSchoolID) {
			this.errorMessage = "Select the DistrictSchool"
			return;
		}

		if (!this.report.StartDate) {
			this.errorMessage = "Select the StartDate"
			return;
		}

		if (!this.report.EndDate) {
			this.errorMessage = "Select the EndDate"
			return;
		}

		if (!this.report.ActionType) {
			this.errorMessage = "Select the ActionType"
			return;
		}

		if (!this.report.InfractionLevelID) {
			this.errorMessage = "Select the InfractionLevel"
			return;
		}

		if (!this.report.SchoolGroupID) {
			this.errorMessage = "Select the SchoolGroup"
			return;
		}

		if (!this.report.ShowDetail) {
			this.errorMessage = "Select the ShowDetail"
			return;
		}

      

        var strParam = "";
        this.isProcessing = true;
    
        //Insert Custom Parameters Here
        //Parameter 1: DistrictSchoolID
        strParam += this.report.DistrictSchoolID + "|DistrictSchoolID";

        //Parameter 2: StartDate
        strParam += "," +  moment(this.report.StartDate).format("MM/DD/YYYY") + "|StartDate";

        //Parameter 3: EndDate
        strParam += "," +  moment(this.report.EndDate).format("MM/DD/YYYY") + "|EndDate";

        //Parameter 4: ActionType
        strParam += "," + this.report.ActionType + "|ActionType";

        //Parameter 5: InfractionLevelID
        strParam += "," + this.report.InfractionLevelID + "|InfractionLevelID";

        //Parameter 6: SchoolGroupID
        strParam += "," + this.report.SchoolGroupID + "|SchoolGroupID";

        //Parameter 7: ShowDetail
        strParam += "," + this.report.ShowDetail + "|ShowDetail";

        //Parameter 8: ImageLogo
        strParam += ",8C87B20B-5813-4F74-8375-9898FD7B0C74|Imagelogo"



        var reportID = 317;

        var result = this.reportService.Print(reportID, strParam, this.report.SchoolID);

        result.subscribe(
            (response: any) => {
                component.isProcessing = false;
                window.open(response);
            },
            error => {
                component.errorMessage = error
                component.isProcessing = false;
            }
        )
    }
}

import { Component, OnInit, AfterViewInit } from '@angular/core';
import { ReportService } from '../report.service';
//Import Custom Services Here
import { StartMonthService } from '../../../shared/services/startmonth.service'
import { StartYearService } from '../../../shared/services/startyear.service'
import { EndMonthService } from '../../../shared/services/endmonth.service'
import { EndYearService } from '../../../shared/services/endyear.service'
import { InfractionLevelService } from '../../../shared/services/infractionlevel.service'
declare var moment: any;


@Component({
    templateUrl: './incidentsbymonth/infractionlevel.component.html',

})
export class IncidentsbyMonth/InfractionLevelComponent implements OnInit {
    constructor(
        private reportService: ReportService,
        //Insert Custom Services Here
        private infractionlevelService: InfractionLevelService,
        private endyearService: EndYearService,
        private endmonthService: EndMonthService,
        private startyearService: StartYearService,
        private startmonthService: StartMonthService,

    ) {

    }
    report = {
        //Insert Custom Parameters Here
        SchoolXML: "",
        StartMonthID: 0,
        StartYearID: 0,
        EndMonthID: 0,
        EndYearID: 0,
        InfractionLevelID: 0,
        ShowDetail: "",
        ImageLogo: 0,

    }
    //Insert Custom Lists Here
    StartMonthList: any = []
    StartYearList: any = []
    EndMonthList: any = []
    EndYearList: any = []
    InfractionLevelList: any = []
    ImageLogoList: any = []
    

    user: any;
    errorMessage: any = "";
    isProcessing: any = false;
    
    ShowDetailList = [
        //Insert Custom List Items Here
        {
			ShowDetailName: 'No'
        },
        {
			ShowDetailName: 'Yes'
        }

    ]

    ngOnInit() {
        //Insert Custom Init Methods Here
        this.loadStartMonthList()
        this.loadStartYearList()
        this.loadEndMonthList()
        this.loadEndYearList()
        this.loadInfractionLevelList()
               
      }
    
    private loadStartMonthList() {
      
        this.report.StartMonthID = 0;
        var result = this.startMonthService.loadStartMonthList(this.report.SchoolID);
        result.subscribe(
            response => {
                this.StartMonthList = response;

                if (this.StartMonthList.length > 1) {
                    this.StartMonthList.unshift({
                        StartMonthID: 0,
                        StartMonthDesc: "All StartMonths"
                    })
                } else {
                    this.report.StartMonthID = this.StartMonthList[0].StartMonthID
                }


            },
            error => {
            }
        )

    }
    
    private loadStartYearList() {
      
        this.report.StartYearID = 0;
        var result = this.startYearService.loadStartYearList(this.report.SchoolID);
        result.subscribe(
            response => {
                this.StartYearList = response;

                if (this.StartYearList.length > 1) {
                    this.StartYearList.unshift({
                        StartYearID: 0,
                        StartYearDesc: "All StartYears"
                    })
                } else {
                    this.report.StartYearID = this.StartYearList[0].StartYearID
                }


            },
            error => {
            }
        )

    }
    
    private loadEndMonthList() {
      
        this.report.EndMonthID = 0;
        var result = this.endMonthService.loadEndMonthList(this.report.SchoolID);
        result.subscribe(
            response => {
                this.EndMonthList = response;

                if (this.EndMonthList.length > 1) {
                    this.EndMonthList.unshift({
                        EndMonthID: 0,
                        EndMonthDesc: "All EndMonths"
                    })
                } else {
                    this.report.EndMonthID = this.EndMonthList[0].EndMonthID
                }


            },
            error => {
            }
        )

    }
    
    private loadEndYearList() {
      
        this.report.EndYearID = 0;
        var result = this.endYearService.loadEndYearList(this.report.SchoolID);
        result.subscribe(
            response => {
                this.EndYearList = response;

                if (this.EndYearList.length > 1) {
                    this.EndYearList.unshift({
                        EndYearID: 0,
                        EndYearDesc: "All EndYears"
                    })
                } else {
                    this.report.EndYearID = this.EndYearList[0].EndYearID
                }


            },
            error => {
            }
        )

    }
    
    private loadInfractionLevelList() {
      
        this.report.InfractionLevelID = 0;
        var result = this.infractionLevelService.loadInfractionLevelList(this.report.SchoolID);
        result.subscribe(
            response => {
                this.InfractionLevelList = response;

                if (this.InfractionLevelList.length > 1) {
                    this.InfractionLevelList.unshift({
                        InfractionLevelID: 0,
                        InfractionLevelDesc: "All InfractionLevels"
                    })
                } else {
                    this.report.InfractionLevelID = this.InfractionLevelList[0].InfractionLevelID
                }


            },
            error => {
            }
        )

    }
    Print() {

        var component = this;
        this.errorMessage = "";

        //Insert Custom Error Checks Here
		if (!this.report.SchoolXML) {
			this.errorMessage = "Select the SchoolXML"
			return;
		}

		if (!this.report.StartMonthID) {
			this.errorMessage = "Select the StartMonth"
			return;
		}

		if (!this.report.StartYearID) {
			this.errorMessage = "Select the StartYear"
			return;
		}

		if (!this.report.EndMonthID) {
			this.errorMessage = "Select the EndMonth"
			return;
		}

		if (!this.report.EndYearID) {
			this.errorMessage = "Select the EndYear"
			return;
		}

		if (!this.report.InfractionLevelID) {
			this.errorMessage = "Select the InfractionLevel"
			return;
		}

		if (!this.report.ShowDetail) {
			this.errorMessage = "Select the ShowDetail"
			return;
		}

      

        var strParam = "";
        this.isProcessing = true;
    
        //Insert Custom Parameters Here
        //Parameter 1: SchoolXML
        strParam += this.report.SchoolXML + "|SchoolXML";

        //Parameter 2: StartMonthID
        strParam += "," + this.report.StartMonthID + "|StartMonthID";

        //Parameter 3: StartYearID
        strParam += "," + this.report.StartYearID + "|StartYearID";

        //Parameter 4: EndMonthID
        strParam += "," + this.report.EndMonthID + "|EndMonthID";

        //Parameter 5: EndYearID
        strParam += "," + this.report.EndYearID + "|EndYearID";

        //Parameter 6: InfractionLevelID
        strParam += "," + this.report.InfractionLevelID + "|InfractionLevelID";

        //Parameter 7: ShowDetail
        strParam += "," + this.report.ShowDetail + "|ShowDetail";

        //Parameter 8: ImageLogo
        strParam += ",8C87B20B-5813-4F74-8375-9898FD7B0C74|Imagelogo"



        var reportID = 332;

        var result = this.reportService.Print(reportID, strParam, this.report.SchoolID);

        result.subscribe(
            (response: any) => {
                component.isProcessing = false;
                window.open(response);
            },
            error => {
                component.errorMessage = error
                component.isProcessing = false;
            }
        )
    }
}

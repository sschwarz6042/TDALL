import { Component, OnInit, AfterViewInit } from '@angular/core';
import { ReportService } from '../report.service';
//Import Custom Services Here
import { StaffPersonService } from '../../../shared/services/staffperson.service'
declare var moment: any;


@Component({
    templateUrl: './incidentsbystaff.component.html',

})
export class IncidentsbyStaffComponent implements OnInit {
    constructor(
        private reportService: ReportService,
        //Insert Custom Services Here
        private staffpersonService: StaffPersonService,

    ) {

    }
    report = {
        //Insert Custom Parameters Here
        SchoolXML: "",
        StartDate: ,
        EndDate: ,
        StaffPersonID: "",
        ShowDetail: "",
        ImageLogo: 0,

    }
    //Insert Custom Lists Here
    StaffPersonList: any = []
    ImageLogoList: any = []
    

    user: any;
    errorMessage: any = "";
    isProcessing: any = false;
    
    ShowDetailList = [
        //Insert Custom List Items Here
        {
			ShowDetailName: 'No'
        },
        {
			ShowDetailName: 'Yes'
        }

    ]

    ngOnInit() {
        //Insert Custom Init Methods Here
        this.loadStaffPersonList()
               
      }
    
    private loadStaffPersonList() {
      
        this.report.StaffPersonID = 0;
        var result = this.staffPersonService.loadStaffPersonList(this.report.SchoolID);
        result.subscribe(
            response => {
                this.StaffPersonList = response;

                if (this.StaffPersonList.length > 1) {
                    this.StaffPersonList.unshift({
                        StaffPersonID: 0,
                        StaffPersonDesc: "All StaffPersons"
                    })
                } else {
                    this.report.StaffPersonID = this.StaffPersonList[0].StaffPersonID
                }


            },
            error => {
            }
        )

    }
    Print() {

        var component = this;
        this.errorMessage = "";

        //Insert Custom Error Checks Here
		if (!this.report.SchoolXML) {
			this.errorMessage = "Select the SchoolXML"
			return;
		}

		if (!this.report.StartDate) {
			this.errorMessage = "Select the StartDate"
			return;
		}

		if (!this.report.EndDate) {
			this.errorMessage = "Select the EndDate"
			return;
		}

		if (!this.report.StaffPersonID) {
			this.errorMessage = "Select the StaffPerson"
			return;
		}

		if (!this.report.ShowDetail) {
			this.errorMessage = "Select the ShowDetail"
			return;
		}

      

        var strParam = "";
        this.isProcessing = true;
    
        //Insert Custom Parameters Here
        //Parameter 1: SchoolXML
        strParam += this.report.SchoolXML + "|SchoolXML";

        //Parameter 2: StartDate
        strParam += "," +  moment(this.report.StartDate).format("MM/DD/YYYY") + "|StartDate";

        //Parameter 3: EndDate
        strParam += "," +  moment(this.report.EndDate).format("MM/DD/YYYY") + "|EndDate";

        //Parameter 4: StaffPersonID
        strParam += "," + this.report.StaffPersonID + "|StaffPersonID";

        //Parameter 5: ShowDetail
        strParam += "," + this.report.ShowDetail + "|ShowDetail";

        //Parameter 6: ImageLogo
        strParam += ",8C87B20B-5813-4F74-8375-9898FD7B0C74|Imagelogo"



        var reportID = 335;

        var result = this.reportService.Print(reportID, strParam, this.report.SchoolID);

        result.subscribe(
            (response: any) => {
                component.isProcessing = false;
                window.open(response);
            },
            error => {
                component.errorMessage = error
                component.isProcessing = false;
            }
        )
    }
}

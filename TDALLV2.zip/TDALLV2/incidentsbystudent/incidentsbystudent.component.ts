import { Component, OnInit, AfterViewInit } from '@angular/core';
import { ReportService } from '../report.service';
//Import Custom Services Here
import { ActionTypeService } from '../../../shared/services/actiontype.service'
import { StudentService } from '../../../shared/services/student.service'
declare var moment: any;


@Component({
    templateUrl: './incidentsbystudent.component.html',

})
export class IncidentsbyStudentComponent implements OnInit {
    constructor(
        private reportService: ReportService,
        //Insert Custom Services Here
        private studentService: StudentService,
        private actiontypeService: ActionTypeService,

    ) {

    }
    report = {
        //Insert Custom Parameters Here
        SchoolXML: "",
        StartDate: ,
        EndDate: ,
        ActionType: 0,
        StudentID: "",
        SortBy: "",
        ShowDetail: "",
        ImageLogo: 0,

    }
    //Insert Custom Lists Here
    ActionTypeList: any = []
    StudentList: any = []
    ImageLogoList: any = []
    

    user: any;
    errorMessage: any = "";
    isProcessing: any = false;
    
    SortByList = [
        //Insert Custom List Items Here
        {
			SortByName: 'Incident Count'
        },
        {
			SortByName: 'Name'
        }

    ]

    
    ShowDetailList = [
        //Insert Custom List Items Here
        {
			ShowDetailName: 'School'
        },
        {
			ShowDetailName: 'Student'
        },
        {
			ShowDetailName: 'Summary'
        }

    ]

    ngOnInit() {
        //Insert Custom Init Methods Here
        this.loadActionTypeList()
        this.loadStudentList()
               
      }
    
    private loadActionTypeList() {
      
        this.report.ActionTypeID = 0;
        var result = this.actionTypeService.loadActionTypeList(this.report.SchoolID);
        result.subscribe(
            response => {
                this.ActionTypeList = response;

                if (this.ActionTypeList.length > 1) {
                    this.ActionTypeList.unshift({
                        ActionTypeID: 0,
                        ActionTypeDesc: "All ActionTypes"
                    })
                } else {
                    this.report.ActionTypeID = this.ActionTypeList[0].ActionTypeID
                }


            },
            error => {
            }
        )

    }
    
    private loadStudentList() {
      
        this.report.StudentID = 0;
        var result = this.studentService.loadStudentList(this.report.SchoolID);
        result.subscribe(
            response => {
                this.StudentList = response;

                if (this.StudentList.length > 1) {
                    this.StudentList.unshift({
                        StudentID: 0,
                        StudentDesc: "All Students"
                    })
                } else {
                    this.report.StudentID = this.StudentList[0].StudentID
                }


            },
            error => {
            }
        )

    }
    Print() {

        var component = this;
        this.errorMessage = "";

        //Insert Custom Error Checks Here
		if (!this.report.SchoolXML) {
			this.errorMessage = "Select the SchoolXML"
			return;
		}

		if (!this.report.StartDate) {
			this.errorMessage = "Select the StartDate"
			return;
		}

		if (!this.report.EndDate) {
			this.errorMessage = "Select the EndDate"
			return;
		}

		if (!this.report.ActionType) {
			this.errorMessage = "Select the ActionType"
			return;
		}

		if (!this.report.StudentID) {
			this.errorMessage = "Select the Student"
			return;
		}

		if (!this.report.SortBy) {
			this.errorMessage = "Select the SortBy"
			return;
		}

		if (!this.report.ShowDetail) {
			this.errorMessage = "Select the ShowDetail"
			return;
		}

      

        var strParam = "";
        this.isProcessing = true;
    
        //Insert Custom Parameters Here
        //Parameter 1: SchoolXML
        strParam += this.report.SchoolXML + "|SchoolXML";

        //Parameter 2: StartDate
        strParam += "," +  moment(this.report.StartDate).format("MM/DD/YYYY") + "|StartDate";

        //Parameter 3: EndDate
        strParam += "," +  moment(this.report.EndDate).format("MM/DD/YYYY") + "|EndDate";

        //Parameter 4: ActionType
        strParam += "," + this.report.ActionType + "|ActionType";

        //Parameter 5: StudentID
        strParam += "," + this.report.StudentID + "|StudentID";

        //Parameter 6: SortBy
        strParam += "," + this.report.SortBy + "|SortBy";

        //Parameter 7: ShowDetail
        strParam += "," + this.report.ShowDetail + "|ShowDetail";

        //Parameter 8: ImageLogo
        strParam += ",8C87B20B-5813-4F74-8375-9898FD7B0C74|Imagelogo"



        var reportID = 307;

        var result = this.reportService.Print(reportID, strParam, this.report.SchoolID);

        result.subscribe(
            (response: any) => {
                component.isProcessing = false;
                window.open(response);
            },
            error => {
                component.errorMessage = error
                component.isProcessing = false;
            }
        )
    }
}

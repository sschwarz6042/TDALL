import { Component, OnInit, AfterViewInit } from '@angular/core';
import { ReportService } from '../report.service';
//Import Custom Services Here
import { SchoolService } from '../../../shared/services/school.service'
import { InstructorPersonService } from '../../../shared/services/instructorperson.service'
import { GradeLevelService } from '../../../shared/services/gradelevel.service'
import { ACADEMYService } from '../../../shared/services/academy.service'
import { HOMEROOMService } from '../../../shared/services/homeroom.service'
import { GROUPService } from '../../../shared/services/group.service'
declare var moment: any;


@Component({
    templateUrl: './instructormerits/demerits.component.html',

})
export class InstructorMerits/DemeritsComponent implements OnInit {
    constructor(
        private reportService: ReportService,
        //Insert Custom Services Here
        private groupService: GROUPService,
        private homeroomService: HOMEROOMService,
        private academyService: ACADEMYService,
        private gradelevelService: GradeLevelService,
        private instructorpersonService: InstructorPersonService,
        private schoolService: SchoolService,

    ) {

    }
    report = {
        //Insert Custom Parameters Here
        SchoolID: 0,
        InstructorPersonID: 0,
        GradeLevelID: 0,
        ACADEMYID: 0,
        HOMEROOMID: 0,
        GROUPID: 0,
        STARTDATE: ,
        ENDDATE: ,
        MeritType: "",
        GroupPeriods: "",
        PageBy: "",
        ShowStudentName: "",
        ImageLogo: 0,

    }
    //Insert Custom Lists Here
    SchoolList: any = []
    InstructorPersonList: any = []
    GradeLevelList: any = []
    ACADEMYList: any = []
    HOMEROOMList: any = []
    GROUPList: any = []
    ImageLogoList: any = []
    

    user: any;
    errorMessage: any = "";
    isProcessing: any = false;
    
    MeritTypeList = [
        //Insert Custom List Items Here
        {
			MeritTypeName: 'All'
        },
        {
			MeritTypeName: 'Merit'
        },
        {
			MeritTypeName: 'Demerit'
        }

    ]

    
    GroupPeriodsList = [
        //Insert Custom List Items Here
        {
			GroupPeriodsName: 'Yes'
        },
        {
			GroupPeriodsName: 'No'
        }

    ]

    
    PageByList = [
        //Insert Custom List Items Here
        {
			PageByName: 'Yes'
        },
        {
			PageByName: 'No'
        }

    ]

    
    ShowStudentNameList = [
        //Insert Custom List Items Here
        {
			ShowStudentNameName: 'Yes'
        },
        {
			ShowStudentNameName: 'No'
        }

    ]

    ngOnInit() {
        //Insert Custom Init Methods Here
        this.loadSchoolList()
        this.loadInstructorPersonList()
        this.loadGradeLevelList()
        this.loadACADEMYList()
        this.loadHOMEROOMList()
        this.loadGROUPList()
               
      }
    
    private loadSchoolList() {
      
        this.report.SchoolID = 0;
        var result = this.schoolService.loadSchoolList(this.report.SchoolID);
        result.subscribe(
            response => {
                this.SchoolList = response;

                if (this.SchoolList.length > 1) {
                    this.SchoolList.unshift({
                        SchoolID: 0,
                        SchoolDesc: "All Schools"
                    })
                } else {
                    this.report.SchoolID = this.SchoolList[0].SchoolID
                }


            },
            error => {
            }
        )

    }
    
    private loadInstructorPersonList() {
      
        this.report.InstructorPersonID = 0;
        var result = this.instructorPersonService.loadInstructorPersonList(this.report.SchoolID);
        result.subscribe(
            response => {
                this.InstructorPersonList = response;

                if (this.InstructorPersonList.length > 1) {
                    this.InstructorPersonList.unshift({
                        InstructorPersonID: 0,
                        InstructorPersonDesc: "All InstructorPersons"
                    })
                } else {
                    this.report.InstructorPersonID = this.InstructorPersonList[0].InstructorPersonID
                }


            },
            error => {
            }
        )

    }
    
    private loadGradeLevelList() {
      
        this.report.GradeLevelID = 0;
        var result = this.gradeLevelService.loadGradeLevelList(this.report.SchoolID);
        result.subscribe(
            response => {
                this.GradeLevelList = response;

                if (this.GradeLevelList.length > 1) {
                    this.GradeLevelList.unshift({
                        GradeLevelID: 0,
                        GradeLevelDesc: "All GradeLevels"
                    })
                } else {
                    this.report.GradeLevelID = this.GradeLevelList[0].GradeLevelID
                }


            },
            error => {
            }
        )

    }
    
    private loadACADEMYList() {
      
        this.report.ACADEMYID = 0;
        var result = this.aCADEMYService.loadACADEMYList(this.report.SchoolID);
        result.subscribe(
            response => {
                this.ACADEMYList = response;

                if (this.ACADEMYList.length > 1) {
                    this.ACADEMYList.unshift({
                        ACADEMYID: 0,
                        ACADEMYDesc: "All ACADEMYs"
                    })
                } else {
                    this.report.ACADEMYID = this.ACADEMYList[0].ACADEMYID
                }


            },
            error => {
            }
        )

    }
    
    private loadHOMEROOMList() {
      
        this.report.HOMEROOMID = 0;
        var result = this.hOMEROOMService.loadHOMEROOMList(this.report.SchoolID);
        result.subscribe(
            response => {
                this.HOMEROOMList = response;

                if (this.HOMEROOMList.length > 1) {
                    this.HOMEROOMList.unshift({
                        HOMEROOMID: 0,
                        HOMEROOMDesc: "All HOMEROOMs"
                    })
                } else {
                    this.report.HOMEROOMID = this.HOMEROOMList[0].HOMEROOMID
                }


            },
            error => {
            }
        )

    }
    
    private loadGROUPList() {
      
        this.report.GROUPID = 0;
        var result = this.gROUPService.loadGROUPList(this.report.SchoolID);
        result.subscribe(
            response => {
                this.GROUPList = response;

                if (this.GROUPList.length > 1) {
                    this.GROUPList.unshift({
                        GROUPID: 0,
                        GROUPDesc: "All GROUPs"
                    })
                } else {
                    this.report.GROUPID = this.GROUPList[0].GROUPID
                }


            },
            error => {
            }
        )

    }
    Print() {

        var component = this;
        this.errorMessage = "";

        //Insert Custom Error Checks Here
		if (!this.report.SchoolID) {
			this.errorMessage = "Select the School"
			return;
		}

		if (!this.report.InstructorPersonID) {
			this.errorMessage = "Select the InstructorPerson"
			return;
		}

		if (!this.report.GradeLevelID) {
			this.errorMessage = "Select the GradeLevel"
			return;
		}

		if (!this.report.ACADEMYID) {
			this.errorMessage = "Select the ACADEMY"
			return;
		}

		if (!this.report.HOMEROOMID) {
			this.errorMessage = "Select the HOMEROOM"
			return;
		}

		if (!this.report.GROUPID) {
			this.errorMessage = "Select the GROUP"
			return;
		}

		if (!this.report.STARTDATE) {
			this.errorMessage = "Select the STARTDATE"
			return;
		}

		if (!this.report.ENDDATE) {
			this.errorMessage = "Select the ENDDATE"
			return;
		}

		if (!this.report.MeritType) {
			this.errorMessage = "Select the MeritType"
			return;
		}

		if (!this.report.GroupPeriods) {
			this.errorMessage = "Select the GroupPeriods"
			return;
		}

		if (!this.report.PageBy) {
			this.errorMessage = "Select the PageBy"
			return;
		}

		if (!this.report.ShowStudentName) {
			this.errorMessage = "Select the ShowStudentName"
			return;
		}

      

        var strParam = "";
        this.isProcessing = true;
    
        //Insert Custom Parameters Here
        //Parameter 1: SchoolID
        strParam += this.report.SchoolID + "|SchoolID";

        //Parameter 2: InstructorPersonID
        strParam += "," + this.report.InstructorPersonID + "|InstructorPersonID";

        //Parameter 3: GradeLevelID
        strParam += "," + this.report.GradeLevelID + "|GradeLevelID";

        //Parameter 4: ACADEMYID
        strParam += "," + this.report.ACADEMYID + "|ACADEMYID";

        //Parameter 5: HOMEROOMID
        strParam += "," + this.report.HOMEROOMID + "|HOMEROOMID";

        //Parameter 6: GROUPID
        strParam += "," + this.report.GROUPID + "|GROUPID";

        //Parameter 7: STARTDATE
        strParam += "," +  moment(this.report.STARTDATE).format("MM/DD/YYYY") + "|STARTDATE";

        //Parameter 8: ENDDATE
        strParam += "," +  moment(this.report.ENDDATE).format("MM/DD/YYYY") + "|ENDDATE";

        //Parameter 9: MeritType
        strParam += "," + this.report.MeritType + "|MeritType";

        //Parameter 10: GroupPeriods
        strParam += "," + this.report.GroupPeriods + "|GroupPeriods";

        //Parameter 11: PageBy
        strParam += "," + this.report.PageBy + "|PageBy";

        //Parameter 12: ShowStudentName
        strParam += "," + this.report.ShowStudentName + "|ShowStudentName";

        //Parameter 13: ImageLogo
        strParam += ",8C87B20B-5813-4F74-8375-9898FD7B0C74|Imagelogo"



        var reportID = 357;

        var result = this.reportService.Print(reportID, strParam, this.report.SchoolID);

        result.subscribe(
            (response: any) => {
                component.isProcessing = false;
                window.open(response);
            },
            error => {
                component.errorMessage = error
                component.isProcessing = false;
            }
        )
    }
}

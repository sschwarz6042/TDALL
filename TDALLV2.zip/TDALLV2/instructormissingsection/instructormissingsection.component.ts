import { Component, OnInit, AfterViewInit } from '@angular/core';
import { ReportService } from '../report.service';
//Import Custom Services Here
declare var moment: any;


@Component({
    templateUrl: './instructormissingsection.component.html',

})
export class InstructorMissingSectionComponent implements OnInit {
    constructor(
        private reportService: ReportService,
        //Insert Custom Services Here

    ) {

    }
    report = {
        //Insert Custom Parameters Here
        TrackingDate: ,

    }
    //Insert Custom Lists Here
    

    user: any;
    errorMessage: any = "";
    isProcessing: any = false;
    ngOnInit() {
        //Insert Custom Init Methods Here
               
      }
    Print() {

        var component = this;
        this.errorMessage = "";

        //Insert Custom Error Checks Here
		if (!this.report.TrackingDate) {
			this.errorMessage = "Select the TrackingDate"
			return;
		}

      

        var strParam = "";
        this.isProcessing = true;
    
        //Insert Custom Parameters Here
        //Parameter 1: TrackingDate
        strParam +=  moment(this.report.TrackingDate).format("MM/DD/YYYY") + "|TrackingDate";



        var reportID = 410;

        var result = this.reportService.Print(reportID, strParam, 202);

        result.subscribe(
            (response: any) => {
                component.isProcessing = false;
                window.open(response);
            },
            error => {
                component.errorMessage = error
                component.isProcessing = false;
            }
        )
    }
}

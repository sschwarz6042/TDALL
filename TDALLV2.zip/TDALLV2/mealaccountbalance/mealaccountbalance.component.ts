import { Component, OnInit, AfterViewInit } from '@angular/core';
import { ReportService } from '../report.service';
//Import Custom Services Here
import { SchoolService } from '../../../shared/services/school.service'
import { BalLoService } from '../../../shared/services/ballo.service'
import { BalHiService } from '../../../shared/services/balhi.service'
declare var moment: any;


@Component({
    templateUrl: './mealaccountbalance.component.html',

})
export class MealAccountBalanceComponent implements OnInit {
    constructor(
        private reportService: ReportService,
        //Insert Custom Services Here
        private balhiService: BalHiService,
        private balloService: BalLoService,
        private schoolService: SchoolService,

    ) {

    }
    report = {
        //Insert Custom Parameters Here
        SchoolID: 0,
        BalLo: ,
        BalHi: ,
        SortBy: "",
        StudentStatus: "",
        ImageLogo: 0,

    }
    //Insert Custom Lists Here
    SchoolList: any = []
    BalLoList: any = []
    BalHiList: any = []
    ImageLogoList: any = []
    

    user: any;
    errorMessage: any = "";
    isProcessing: any = false;
    
    SortByList = [
        //Insert Custom List Items Here
        {
			SortByName: 'Amount'
        },
        {
			SortByName: 'Academy'
        },
        {
			SortByName: 'Grade'
        },
        {
			SortByName: 'Homeroom'
        },
        {
			SortByName: 'Name'
        }

    ]

    
    StudentStatusList = [
        //Insert Custom List Items Here
        {
			StudentStatusName: 'Active'
        },
        {
			StudentStatusName: 'Inactive'
        },
        {
			StudentStatusName: 'All'
        }

    ]

    ngOnInit() {
        //Insert Custom Init Methods Here
        this.loadSchoolList()
        this.loadBalLoList()
        this.loadBalHiList()
               
      }
    
    private loadSchoolList() {
      
        this.report.SchoolID = 0;
        var result = this.schoolService.loadSchoolList(this.report.SchoolID);
        result.subscribe(
            response => {
                this.SchoolList = response;

                if (this.SchoolList.length > 1) {
                    this.SchoolList.unshift({
                        SchoolID: 0,
                        SchoolDesc: "All Schools"
                    })
                } else {
                    this.report.SchoolID = this.SchoolList[0].SchoolID
                }


            },
            error => {
            }
        )

    }
    
    private loadBalLoList() {
      
        this.report.BalLoID = 0;
        var result = this.balLoService.loadBalLoList(this.report.SchoolID);
        result.subscribe(
            response => {
                this.BalLoList = response;

                if (this.BalLoList.length > 1) {
                    this.BalLoList.unshift({
                        BalLoID: 0,
                        BalLoDesc: "All BalLos"
                    })
                } else {
                    this.report.BalLoID = this.BalLoList[0].BalLoID
                }


            },
            error => {
            }
        )

    }
    
    private loadBalHiList() {
      
        this.report.BalHiID = 0;
        var result = this.balHiService.loadBalHiList(this.report.SchoolID);
        result.subscribe(
            response => {
                this.BalHiList = response;

                if (this.BalHiList.length > 1) {
                    this.BalHiList.unshift({
                        BalHiID: 0,
                        BalHiDesc: "All BalHis"
                    })
                } else {
                    this.report.BalHiID = this.BalHiList[0].BalHiID
                }


            },
            error => {
            }
        )

    }
    Print() {

        var component = this;
        this.errorMessage = "";

        //Insert Custom Error Checks Here
		if (!this.report.SchoolID) {
			this.errorMessage = "Select the School"
			return;
		}

		if (!this.report.BalLo) {
			this.errorMessage = "Select the BalLo"
			return;
		}

		if (!this.report.BalHi) {
			this.errorMessage = "Select the BalHi"
			return;
		}

		if (!this.report.SortBy) {
			this.errorMessage = "Select the SortBy"
			return;
		}

		if (!this.report.StudentStatus) {
			this.errorMessage = "Select the StudentStatus"
			return;
		}

      

        var strParam = "";
        this.isProcessing = true;
    
        //Insert Custom Parameters Here
        //Parameter 1: SchoolID
        strParam += this.report.SchoolID + "|SchoolID";

        //Parameter 2: BalLo
        strParam += "," + this.report.BalLo + "|BalLo";

        //Parameter 3: BalHi
        strParam += "," + this.report.BalHi + "|BalHi";

        //Parameter 4: SortBy
        strParam += "," + this.report.SortBy + "|SortBy";

        //Parameter 5: StudentStatus
        strParam += "," + this.report.StudentStatus + "|StudentStatus";

        //Parameter 6: ImageLogo
        strParam += ",8C87B20B-5813-4F74-8375-9898FD7B0C74|Imagelogo"



        var reportID = 265;

        var result = this.reportService.Print(reportID, strParam, this.report.SchoolID);

        result.subscribe(
            (response: any) => {
                component.isProcessing = false;
                window.open(response);
            },
            error => {
                component.errorMessage = error
                component.isProcessing = false;
            }
        )
    }
}

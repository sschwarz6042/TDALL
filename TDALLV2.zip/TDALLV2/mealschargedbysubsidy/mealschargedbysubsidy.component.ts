import { Component, OnInit, AfterViewInit } from '@angular/core';
import { ReportService } from '../report.service';
//Import Custom Services Here
import { SchoolService } from '../../../shared/services/school.service'
import { MealService } from '../../../shared/services/meal.service'
import { MealSubsidyTypeService } from '../../../shared/services/mealsubsidytype.service'
declare var moment: any;


@Component({
    templateUrl: './mealschargedbysubsidy.component.html',

})
export class MealsChargedbySubsidyComponent implements OnInit {
    constructor(
        private reportService: ReportService,
        //Insert Custom Services Here
        private mealsubsidytypeService: MealSubsidyTypeService,
        private mealService: MealService,
        private schoolService: SchoolService,

    ) {

    }
    report = {
        //Insert Custom Parameters Here
        SchoolID: 0,
        STARTDATE: ,
        ENDDATE: ,
        MealID: 0,
        MealSubsidyTypeID: 0,
        ImageLogo: 0,

    }
    //Insert Custom Lists Here
    SchoolList: any = []
    MealList: any = []
    MealSubsidyTypeList: any = []
    ImageLogoList: any = []
    

    user: any;
    errorMessage: any = "";
    isProcessing: any = false;
    ngOnInit() {
        //Insert Custom Init Methods Here
        this.loadSchoolList()
        this.loadMealList()
        this.loadMealSubsidyTypeList()
               
      }
    
    private loadSchoolList() {
      
        this.report.SchoolID = 0;
        var result = this.schoolService.loadSchoolList(this.report.SchoolID);
        result.subscribe(
            response => {
                this.SchoolList = response;

                if (this.SchoolList.length > 1) {
                    this.SchoolList.unshift({
                        SchoolID: 0,
                        SchoolDesc: "All Schools"
                    })
                } else {
                    this.report.SchoolID = this.SchoolList[0].SchoolID
                }


            },
            error => {
            }
        )

    }
    
    private loadMealList() {
      
        this.report.MealID = 0;
        var result = this.mealService.loadMealList(this.report.SchoolID);
        result.subscribe(
            response => {
                this.MealList = response;

                if (this.MealList.length > 1) {
                    this.MealList.unshift({
                        MealID: 0,
                        MealDesc: "All Meals"
                    })
                } else {
                    this.report.MealID = this.MealList[0].MealID
                }


            },
            error => {
            }
        )

    }
    
    private loadMealSubsidyTypeList() {
      
        this.report.MealSubsidyTypeID = 0;
        var result = this.mealSubsidyTypeService.loadMealSubsidyTypeList(this.report.SchoolID);
        result.subscribe(
            response => {
                this.MealSubsidyTypeList = response;

                if (this.MealSubsidyTypeList.length > 1) {
                    this.MealSubsidyTypeList.unshift({
                        MealSubsidyTypeID: 0,
                        MealSubsidyTypeDesc: "All MealSubsidyTypes"
                    })
                } else {
                    this.report.MealSubsidyTypeID = this.MealSubsidyTypeList[0].MealSubsidyTypeID
                }


            },
            error => {
            }
        )

    }
    Print() {

        var component = this;
        this.errorMessage = "";

        //Insert Custom Error Checks Here
		if (!this.report.SchoolID) {
			this.errorMessage = "Select the School"
			return;
		}

		if (!this.report.STARTDATE) {
			this.errorMessage = "Select the STARTDATE"
			return;
		}

		if (!this.report.ENDDATE) {
			this.errorMessage = "Select the ENDDATE"
			return;
		}

		if (!this.report.MealID) {
			this.errorMessage = "Select the Meal"
			return;
		}

		if (!this.report.MealSubsidyTypeID) {
			this.errorMessage = "Select the MealSubsidyType"
			return;
		}

      

        var strParam = "";
        this.isProcessing = true;
    
        //Insert Custom Parameters Here
        //Parameter 1: SchoolID
        strParam += this.report.SchoolID + "|SchoolID";

        //Parameter 2: STARTDATE
        strParam += "," +  moment(this.report.STARTDATE).format("MM/DD/YYYY") + "|STARTDATE";

        //Parameter 3: ENDDATE
        strParam += "," +  moment(this.report.ENDDATE).format("MM/DD/YYYY") + "|ENDDATE";

        //Parameter 4: MealID
        strParam += "," + this.report.MealID + "|MealID";

        //Parameter 5: MealSubsidyTypeID
        strParam += "," + this.report.MealSubsidyTypeID + "|MealSubsidyTypeID";

        //Parameter 6: ImageLogo
        strParam += ",8C87B20B-5813-4F74-8375-9898FD7B0C74|Imagelogo"



        var reportID = 263;

        var result = this.reportService.Print(reportID, strParam, this.report.SchoolID);

        result.subscribe(
            (response: any) => {
                component.isProcessing = false;
                window.open(response);
            },
            error => {
                component.errorMessage = error
                component.isProcessing = false;
            }
        )
    }
}

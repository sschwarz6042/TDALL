import { Component, OnInit, AfterViewInit } from '@angular/core';
import { ReportService } from '../report.service';
//Import Custom Services Here
import { MealSubsidyTypeService } from '../../../shared/services/mealsubsidytype.service'
import { MealService } from '../../../shared/services/meal.service'
declare var moment: any;


@Component({
    templateUrl: './mealtypecounts.component.html',

})
export class MealTypeCountsComponent implements OnInit {
    constructor(
        private reportService: ReportService,
        //Insert Custom Services Here
        private mealService: MealService,
        private mealsubsidytypeService: MealSubsidyTypeService,

    ) {

    }
    report = {
        //Insert Custom Parameters Here
        MealSubsidyTypeID: 0,
        MealID: 0,
        STARTDATE: ,
        ENDDATE: ,
        ShowDetail: "",
        ImageLogo: 0,

    }
    //Insert Custom Lists Here
    MealSubsidyTypeList: any = []
    MealList: any = []
    ImageLogoList: any = []
    

    user: any;
    errorMessage: any = "";
    isProcessing: any = false;
    
    ShowDetailList = [
        //Insert Custom List Items Here
        {
			ShowDetailName: 'No'
        },
        {
			ShowDetailName: 'Yes'
        }

    ]

    ngOnInit() {
        //Insert Custom Init Methods Here
        this.loadMealSubsidyTypeList()
        this.loadMealList()
               
      }
    
    private loadMealSubsidyTypeList() {
      
        this.report.MealSubsidyTypeID = 0;
        var result = this.mealSubsidyTypeService.loadMealSubsidyTypeList(this.report.SchoolID);
        result.subscribe(
            response => {
                this.MealSubsidyTypeList = response;

                if (this.MealSubsidyTypeList.length > 1) {
                    this.MealSubsidyTypeList.unshift({
                        MealSubsidyTypeID: 0,
                        MealSubsidyTypeDesc: "All MealSubsidyTypes"
                    })
                } else {
                    this.report.MealSubsidyTypeID = this.MealSubsidyTypeList[0].MealSubsidyTypeID
                }


            },
            error => {
            }
        )

    }
    
    private loadMealList() {
      
        this.report.MealID = 0;
        var result = this.mealService.loadMealList(this.report.SchoolID);
        result.subscribe(
            response => {
                this.MealList = response;

                if (this.MealList.length > 1) {
                    this.MealList.unshift({
                        MealID: 0,
                        MealDesc: "All Meals"
                    })
                } else {
                    this.report.MealID = this.MealList[0].MealID
                }


            },
            error => {
            }
        )

    }
    Print() {

        var component = this;
        this.errorMessage = "";

        //Insert Custom Error Checks Here
		if (!this.report.MealSubsidyTypeID) {
			this.errorMessage = "Select the MealSubsidyType"
			return;
		}

		if (!this.report.MealID) {
			this.errorMessage = "Select the Meal"
			return;
		}

		if (!this.report.STARTDATE) {
			this.errorMessage = "Select the STARTDATE"
			return;
		}

		if (!this.report.ENDDATE) {
			this.errorMessage = "Select the ENDDATE"
			return;
		}

		if (!this.report.ShowDetail) {
			this.errorMessage = "Select the ShowDetail"
			return;
		}

      

        var strParam = "";
        this.isProcessing = true;
    
        //Insert Custom Parameters Here
        //Parameter 1: MealSubsidyTypeID
        strParam += this.report.MealSubsidyTypeID + "|MealSubsidyTypeID";

        //Parameter 2: MealID
        strParam += "," + this.report.MealID + "|MealID";

        //Parameter 3: STARTDATE
        strParam += "," +  moment(this.report.STARTDATE).format("MM/DD/YYYY") + "|STARTDATE";

        //Parameter 4: ENDDATE
        strParam += "," +  moment(this.report.ENDDATE).format("MM/DD/YYYY") + "|ENDDATE";

        //Parameter 5: ShowDetail
        strParam += "," + this.report.ShowDetail + "|ShowDetail";

        //Parameter 6: ImageLogo
        strParam += ",8C87B20B-5813-4F74-8375-9898FD7B0C74|Imagelogo"



        var reportID = 360;

        var result = this.reportService.Print(reportID, strParam, 202);

        result.subscribe(
            (response: any) => {
                component.isProcessing = false;
                window.open(response);
            },
            error => {
                component.errorMessage = error
                component.isProcessing = false;
            }
        )
    }
}

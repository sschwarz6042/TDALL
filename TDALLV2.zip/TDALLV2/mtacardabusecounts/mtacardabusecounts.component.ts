import { Component, OnInit, AfterViewInit } from '@angular/core';
import { ReportService } from '../report.service';
//Import Custom Services Here
import { DistrictSchoolService } from '../../../shared/services/districtschool.service'
import { MTACardTypeService } from '../../../shared/services/mtacardtype.service'
import { AbuseCountService } from '../../../shared/services/abusecount.service'
declare var moment: any;


@Component({
    templateUrl: './mtacardabusecounts.component.html',

})
export class MTACardAbuseCountsComponent implements OnInit {
    constructor(
        private reportService: ReportService,
        //Insert Custom Services Here
        private abusecountService: AbuseCountService,
        private mtacardtypeService: MTACardTypeService,
        private districtschoolService: DistrictSchoolService,

    ) {

    }
    report = {
        //Insert Custom Parameters Here
        DistrictSchoolID: 0,
        MTACardTypeID: 0,
        StartDate: ,
        EndDate: ,
        AbuseCount: 0,
        CountType: "",
        ImageLogo: 0,

    }
    //Insert Custom Lists Here
    DistrictSchoolList: any = []
    MTACardTypeList: any = []
    AbuseCountList: any = []
    ImageLogoList: any = []
    

    user: any;
    errorMessage: any = "";
    isProcessing: any = false;
    
    CountTypeList = [
        //Insert Custom List Items Here
        {
			CountTypeName: 'By day only'
        },
        {
			CountTypeName: 'Every scan'
        }

    ]

    ngOnInit() {
        //Insert Custom Init Methods Here
        this.loadDistrictSchoolList()
        this.loadMTACardTypeList()
        this.loadAbuseCountList()
               
      }
    
    private loadDistrictSchoolList() {
      
        this.report.DistrictSchoolID = 0;
        var result = this.districtSchoolService.loadDistrictSchoolList(this.report.SchoolID);
        result.subscribe(
            response => {
                this.DistrictSchoolList = response;

                if (this.DistrictSchoolList.length > 1) {
                    this.DistrictSchoolList.unshift({
                        DistrictSchoolID: 0,
                        DistrictSchoolDesc: "All DistrictSchools"
                    })
                } else {
                    this.report.DistrictSchoolID = this.DistrictSchoolList[0].DistrictSchoolID
                }


            },
            error => {
            }
        )

    }
    
    private loadMTACardTypeList() {
      
        this.report.MTACardTypeID = 0;
        var result = this.mTACardTypeService.loadMTACardTypeList(this.report.SchoolID);
        result.subscribe(
            response => {
                this.MTACardTypeList = response;

                if (this.MTACardTypeList.length > 1) {
                    this.MTACardTypeList.unshift({
                        MTACardTypeID: 0,
                        MTACardTypeDesc: "All MTACardTypes"
                    })
                } else {
                    this.report.MTACardTypeID = this.MTACardTypeList[0].MTACardTypeID
                }


            },
            error => {
            }
        )

    }
    
    private loadAbuseCountList() {
      
        this.report.AbuseCountID = 0;
        var result = this.abuseCountService.loadAbuseCountList(this.report.SchoolID);
        result.subscribe(
            response => {
                this.AbuseCountList = response;

                if (this.AbuseCountList.length > 1) {
                    this.AbuseCountList.unshift({
                        AbuseCountID: 0,
                        AbuseCountDesc: "All AbuseCounts"
                    })
                } else {
                    this.report.AbuseCountID = this.AbuseCountList[0].AbuseCountID
                }


            },
            error => {
            }
        )

    }
    Print() {

        var component = this;
        this.errorMessage = "";

        //Insert Custom Error Checks Here
		if (!this.report.DistrictSchoolID) {
			this.errorMessage = "Select the DistrictSchool"
			return;
		}

		if (!this.report.MTACardTypeID) {
			this.errorMessage = "Select the MTACardType"
			return;
		}

		if (!this.report.StartDate) {
			this.errorMessage = "Select the StartDate"
			return;
		}

		if (!this.report.EndDate) {
			this.errorMessage = "Select the EndDate"
			return;
		}

		if (!this.report.AbuseCount) {
			this.errorMessage = "Select the AbuseCount"
			return;
		}

		if (!this.report.CountType) {
			this.errorMessage = "Select the CountType"
			return;
		}

      

        var strParam = "";
        this.isProcessing = true;
    
        //Insert Custom Parameters Here
        //Parameter 1: DistrictSchoolID
        strParam += this.report.DistrictSchoolID + "|DistrictSchoolID";

        //Parameter 2: MTACardTypeID
        strParam += "," + this.report.MTACardTypeID + "|MTACardTypeID";

        //Parameter 3: StartDate
        strParam += "," +  moment(this.report.StartDate).format("MM/DD/YYYY") + "|StartDate";

        //Parameter 4: EndDate
        strParam += "," +  moment(this.report.EndDate).format("MM/DD/YYYY") + "|EndDate";

        //Parameter 5: AbuseCount
        strParam += "," + this.report.AbuseCount + "|AbuseCount";

        //Parameter 6: CountType
        strParam += "," + this.report.CountType + "|CountType";

        //Parameter 7: ImageLogo
        strParam += ",8C87B20B-5813-4F74-8375-9898FD7B0C74|Imagelogo"



        var reportID = 412;

        var result = this.reportService.Print(reportID, strParam, this.report.SchoolID);

        result.subscribe(
            (response: any) => {
                component.isProcessing = false;
                window.open(response);
            },
            error => {
                component.errorMessage = error
                component.isProcessing = false;
            }
        )
    }
}

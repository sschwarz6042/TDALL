import { Component, OnInit, AfterViewInit } from '@angular/core';
import { ReportService } from '../report.service';
//Import Custom Services Here
import { SchoolService } from '../../../shared/services/school.service'
import { GradeLevelService } from '../../../shared/services/gradelevel.service'
import { ACADEMYService } from '../../../shared/services/academy.service'
import { HOMEROOMService } from '../../../shared/services/homeroom.service'
declare var moment: any;


@Component({
    templateUrl: './photolabels.component.html',

})
export class PhotoLabelsComponent implements OnInit {
    constructor(
        private reportService: ReportService,
        //Insert Custom Services Here
        private homeroomService: HOMEROOMService,
        private academyService: ACADEMYService,
        private gradelevelService: GradeLevelService,
        private schoolService: SchoolService,

    ) {

    }
    report = {
        //Insert Custom Parameters Here
        SchoolID: 0,
        GradeLevelID: 0,
        ACADEMYID: 0,
        HOMEROOMID: 0,
        ORDERBY: "",
        W_ID: "",
        W_HPhone: "",
        W_HRoom: "",
        W_DOB: "",
        W_Name: "",

    }
    //Insert Custom Lists Here
    SchoolList: any = []
    GradeLevelList: any = []
    ACADEMYList: any = []
    HOMEROOMList: any = []
    

    user: any;
    errorMessage: any = "";
    isProcessing: any = false;
    
    ORDERBYList = [
        //Insert Custom List Items Here
        {
			ORDERBYName: 'Academy'
        },
        {
			ORDERBYName: 'Grade'
        },
        {
			ORDERBYName: 'Homeroom'
        },
        {
			ORDERBYName: 'Name'
        }

    ]

    
    W_List = [
        //Insert Custom List Items Here
        {
			W_Name: 'Yes'
        },
        {
			W_Name: 'No'
        }

    ]

    
    W_HPhoneList = [
        //Insert Custom List Items Here
        {
			W_HPhoneName: 'Yes'
        },
        {
			W_HPhoneName: 'No'
        }

    ]

    
    W_HRoomList = [
        //Insert Custom List Items Here
        {
			W_HRoomName: 'Yes'
        },
        {
			W_HRoomName: 'No'
        }

    ]

    
    W_DOBList = [
        //Insert Custom List Items Here
        {
			W_DOBName: 'Yes'
        },
        {
			W_DOBName: 'No'
        }

    ]

    
    W_NameList = [
        //Insert Custom List Items Here
        {
			W_NameName: 'Yes'
        },
        {
			W_NameName: 'No'
        }

    ]

    ngOnInit() {
        //Insert Custom Init Methods Here
        this.loadSchoolList()
        this.loadGradeLevelList()
        this.loadACADEMYList()
        this.loadHOMEROOMList()
               
      }
    
    private loadSchoolList() {
      
        this.report.SchoolID = 0;
        var result = this.schoolService.loadSchoolList(this.report.SchoolID);
        result.subscribe(
            response => {
                this.SchoolList = response;

                if (this.SchoolList.length > 1) {
                    this.SchoolList.unshift({
                        SchoolID: 0,
                        SchoolDesc: "All Schools"
                    })
                } else {
                    this.report.SchoolID = this.SchoolList[0].SchoolID
                }


            },
            error => {
            }
        )

    }
    
    private loadGradeLevelList() {
      
        this.report.GradeLevelID = 0;
        var result = this.gradeLevelService.loadGradeLevelList(this.report.SchoolID);
        result.subscribe(
            response => {
                this.GradeLevelList = response;

                if (this.GradeLevelList.length > 1) {
                    this.GradeLevelList.unshift({
                        GradeLevelID: 0,
                        GradeLevelDesc: "All GradeLevels"
                    })
                } else {
                    this.report.GradeLevelID = this.GradeLevelList[0].GradeLevelID
                }


            },
            error => {
            }
        )

    }
    
    private loadACADEMYList() {
      
        this.report.ACADEMYID = 0;
        var result = this.aCADEMYService.loadACADEMYList(this.report.SchoolID);
        result.subscribe(
            response => {
                this.ACADEMYList = response;

                if (this.ACADEMYList.length > 1) {
                    this.ACADEMYList.unshift({
                        ACADEMYID: 0,
                        ACADEMYDesc: "All ACADEMYs"
                    })
                } else {
                    this.report.ACADEMYID = this.ACADEMYList[0].ACADEMYID
                }


            },
            error => {
            }
        )

    }
    
    private loadHOMEROOMList() {
      
        this.report.HOMEROOMID = 0;
        var result = this.hOMEROOMService.loadHOMEROOMList(this.report.SchoolID);
        result.subscribe(
            response => {
                this.HOMEROOMList = response;

                if (this.HOMEROOMList.length > 1) {
                    this.HOMEROOMList.unshift({
                        HOMEROOMID: 0,
                        HOMEROOMDesc: "All HOMEROOMs"
                    })
                } else {
                    this.report.HOMEROOMID = this.HOMEROOMList[0].HOMEROOMID
                }


            },
            error => {
            }
        )

    }
    Print() {

        var component = this;
        this.errorMessage = "";

        //Insert Custom Error Checks Here
		if (!this.report.SchoolID) {
			this.errorMessage = "Select the School"
			return;
		}

		if (!this.report.GradeLevelID) {
			this.errorMessage = "Select the GradeLevel"
			return;
		}

		if (!this.report.ACADEMYID) {
			this.errorMessage = "Select the ACADEMY"
			return;
		}

		if (!this.report.HOMEROOMID) {
			this.errorMessage = "Select the HOMEROOM"
			return;
		}

		if (!this.report.ORDERBY) {
			this.errorMessage = "Select the ORDERBY"
			return;
		}

		if (!this.report.W_ID) {
			this.errorMessage = "Select the W_"
			return;
		}

		if (!this.report.W_HPhone) {
			this.errorMessage = "Select the W_HPhone"
			return;
		}

		if (!this.report.W_HRoom) {
			this.errorMessage = "Select the W_HRoom"
			return;
		}

		if (!this.report.W_DOB) {
			this.errorMessage = "Select the W_DOB"
			return;
		}

		if (!this.report.W_Name) {
			this.errorMessage = "Select the W_Name"
			return;
		}

      

        var strParam = "";
        this.isProcessing = true;
    
        //Insert Custom Parameters Here
        //Parameter 1: SchoolID
        strParam += this.report.SchoolID + "|SchoolID";

        //Parameter 2: GradeLevelID
        strParam += "," + this.report.GradeLevelID + "|GradeLevelID";

        //Parameter 3: ACADEMYID
        strParam += "," + this.report.ACADEMYID + "|ACADEMYID";

        //Parameter 4: HOMEROOMID
        strParam += "," + this.report.HOMEROOMID + "|HOMEROOMID";

        //Parameter 5: ORDERBY
        strParam += "," + this.report.ORDERBY + "|ORDERBY";

        //Parameter 6: W_ID
        strParam += "," + this.report.W_ID + "|W_ID";

        //Parameter 7: W_HPhone
        strParam += "," + this.report.W_HPhone + "|W_HPhone";

        //Parameter 8: W_HRoom
        strParam += "," + this.report.W_HRoom + "|W_HRoom";

        //Parameter 9: W_DOB
        strParam += "," + this.report.W_DOB + "|W_DOB";

        //Parameter 10: W_Name
        strParam += "," + this.report.W_Name + "|W_Name";



        var reportID = 222;

        var result = this.reportService.Print(reportID, strParam, this.report.SchoolID);

        result.subscribe(
            (response: any) => {
                component.isProcessing = false;
                window.open(response);
            },
            error => {
                component.errorMessage = error
                component.isProcessing = false;
            }
        )
    }
}

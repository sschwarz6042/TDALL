import { Component, OnInit, AfterViewInit } from '@angular/core';
import { ReportService } from '../report.service';
//Import Custom Services Here
import { SchoolService } from '../../../shared/services/school.service'
import { GradeLevelService } from '../../../shared/services/gradelevel.service'
import { ACADEMYService } from '../../../shared/services/academy.service'
import { HOMEROOMService } from '../../../shared/services/homeroom.service'
import { TopMarginService } from '../../../shared/services/topmargin.service'
import { LeftMarginService } from '../../../shared/services/leftmargin.service'
import { ColumnSpaceService } from '../../../shared/services/columnspace.service'
import { LabelHeightService } from '../../../shared/services/labelheight.service'
declare var moment: any;


@Component({
    templateUrl: './photolabels3columns.component.html',

})
export class PhotoLabels3ColumnsComponent implements OnInit {
    constructor(
        private reportService: ReportService,
        //Insert Custom Services Here
        private labelheightService: LabelHeightService,
        private columnspaceService: ColumnSpaceService,
        private leftmarginService: LeftMarginService,
        private topmarginService: TopMarginService,
        private homeroomService: HOMEROOMService,
        private academyService: ACADEMYService,
        private gradelevelService: GradeLevelService,
        private schoolService: SchoolService,

    ) {

    }
    report = {
        //Insert Custom Parameters Here
        SchoolID: 0,
        GradeLevelID: 0,
        ACADEMYID: 0,
        HOMEROOMID: 0,
        ORDERBY: "",
        W_ID: "",
        W_HPhone: "",
        W_HRoom: "",
        W_Name: "",
        TopMargin: 0,
        LeftMargin: 0,
        ColumnSpace: 0,
        LabelHeight: 0,

    }
    //Insert Custom Lists Here
    SchoolList: any = []
    GradeLevelList: any = []
    ACADEMYList: any = []
    HOMEROOMList: any = []
    TopMarginList: any = []
    LeftMarginList: any = []
    ColumnSpaceList: any = []
    LabelHeightList: any = []
    

    user: any;
    errorMessage: any = "";
    isProcessing: any = false;
    
    ORDERBYList = [
        //Insert Custom List Items Here
        {
			ORDERBYName: 'Academy'
        },
        {
			ORDERBYName: 'Grade'
        },
        {
			ORDERBYName: 'Homeroom'
        },
        {
			ORDERBYName: 'Name'
        }

    ]

    
    W_List = [
        //Insert Custom List Items Here
        {
			W_Name: 'Yes'
        },
        {
			W_Name: 'No'
        }

    ]

    
    W_HPhoneList = [
        //Insert Custom List Items Here
        {
			W_HPhoneName: 'Yes'
        },
        {
			W_HPhoneName: 'No'
        }

    ]

    
    W_HRoomList = [
        //Insert Custom List Items Here
        {
			W_HRoomName: 'Yes'
        },
        {
			W_HRoomName: 'No'
        }

    ]

    
    W_NameList = [
        //Insert Custom List Items Here
        {
			W_NameName: 'Yes'
        },
        {
			W_NameName: 'No'
        }

    ]

    ngOnInit() {
        //Insert Custom Init Methods Here
        this.loadSchoolList()
        this.loadGradeLevelList()
        this.loadACADEMYList()
        this.loadHOMEROOMList()
        this.loadTopMarginList()
        this.loadLeftMarginList()
        this.loadColumnSpaceList()
        this.loadLabelHeightList()
               
      }
    
    private loadSchoolList() {
      
        this.report.SchoolID = 0;
        var result = this.schoolService.loadSchoolList(this.report.SchoolID);
        result.subscribe(
            response => {
                this.SchoolList = response;

                if (this.SchoolList.length > 1) {
                    this.SchoolList.unshift({
                        SchoolID: 0,
                        SchoolDesc: "All Schools"
                    })
                } else {
                    this.report.SchoolID = this.SchoolList[0].SchoolID
                }


            },
            error => {
            }
        )

    }
    
    private loadGradeLevelList() {
      
        this.report.GradeLevelID = 0;
        var result = this.gradeLevelService.loadGradeLevelList(this.report.SchoolID);
        result.subscribe(
            response => {
                this.GradeLevelList = response;

                if (this.GradeLevelList.length > 1) {
                    this.GradeLevelList.unshift({
                        GradeLevelID: 0,
                        GradeLevelDesc: "All GradeLevels"
                    })
                } else {
                    this.report.GradeLevelID = this.GradeLevelList[0].GradeLevelID
                }


            },
            error => {
            }
        )

    }
    
    private loadACADEMYList() {
      
        this.report.ACADEMYID = 0;
        var result = this.aCADEMYService.loadACADEMYList(this.report.SchoolID);
        result.subscribe(
            response => {
                this.ACADEMYList = response;

                if (this.ACADEMYList.length > 1) {
                    this.ACADEMYList.unshift({
                        ACADEMYID: 0,
                        ACADEMYDesc: "All ACADEMYs"
                    })
                } else {
                    this.report.ACADEMYID = this.ACADEMYList[0].ACADEMYID
                }


            },
            error => {
            }
        )

    }
    
    private loadHOMEROOMList() {
      
        this.report.HOMEROOMID = 0;
        var result = this.hOMEROOMService.loadHOMEROOMList(this.report.SchoolID);
        result.subscribe(
            response => {
                this.HOMEROOMList = response;

                if (this.HOMEROOMList.length > 1) {
                    this.HOMEROOMList.unshift({
                        HOMEROOMID: 0,
                        HOMEROOMDesc: "All HOMEROOMs"
                    })
                } else {
                    this.report.HOMEROOMID = this.HOMEROOMList[0].HOMEROOMID
                }


            },
            error => {
            }
        )

    }
    
    private loadTopMarginList() {
      
        this.report.TopMarginID = 0;
        var result = this.topMarginService.loadTopMarginList(this.report.SchoolID);
        result.subscribe(
            response => {
                this.TopMarginList = response;

                if (this.TopMarginList.length > 1) {
                    this.TopMarginList.unshift({
                        TopMarginID: 0,
                        TopMarginDesc: "All TopMargins"
                    })
                } else {
                    this.report.TopMarginID = this.TopMarginList[0].TopMarginID
                }


            },
            error => {
            }
        )

    }
    
    private loadLeftMarginList() {
      
        this.report.LeftMarginID = 0;
        var result = this.leftMarginService.loadLeftMarginList(this.report.SchoolID);
        result.subscribe(
            response => {
                this.LeftMarginList = response;

                if (this.LeftMarginList.length > 1) {
                    this.LeftMarginList.unshift({
                        LeftMarginID: 0,
                        LeftMarginDesc: "All LeftMargins"
                    })
                } else {
                    this.report.LeftMarginID = this.LeftMarginList[0].LeftMarginID
                }


            },
            error => {
            }
        )

    }
    
    private loadColumnSpaceList() {
      
        this.report.ColumnSpaceID = 0;
        var result = this.columnSpaceService.loadColumnSpaceList(this.report.SchoolID);
        result.subscribe(
            response => {
                this.ColumnSpaceList = response;

                if (this.ColumnSpaceList.length > 1) {
                    this.ColumnSpaceList.unshift({
                        ColumnSpaceID: 0,
                        ColumnSpaceDesc: "All ColumnSpaces"
                    })
                } else {
                    this.report.ColumnSpaceID = this.ColumnSpaceList[0].ColumnSpaceID
                }


            },
            error => {
            }
        )

    }
    
    private loadLabelHeightList() {
      
        this.report.LabelHeightID = 0;
        var result = this.labelHeightService.loadLabelHeightList(this.report.SchoolID);
        result.subscribe(
            response => {
                this.LabelHeightList = response;

                if (this.LabelHeightList.length > 1) {
                    this.LabelHeightList.unshift({
                        LabelHeightID: 0,
                        LabelHeightDesc: "All LabelHeights"
                    })
                } else {
                    this.report.LabelHeightID = this.LabelHeightList[0].LabelHeightID
                }


            },
            error => {
            }
        )

    }
    Print() {

        var component = this;
        this.errorMessage = "";

        //Insert Custom Error Checks Here
		if (!this.report.SchoolID) {
			this.errorMessage = "Select the School"
			return;
		}

		if (!this.report.GradeLevelID) {
			this.errorMessage = "Select the GradeLevel"
			return;
		}

		if (!this.report.ACADEMYID) {
			this.errorMessage = "Select the ACADEMY"
			return;
		}

		if (!this.report.HOMEROOMID) {
			this.errorMessage = "Select the HOMEROOM"
			return;
		}

		if (!this.report.ORDERBY) {
			this.errorMessage = "Select the ORDERBY"
			return;
		}

		if (!this.report.W_ID) {
			this.errorMessage = "Select the W_"
			return;
		}

		if (!this.report.W_HPhone) {
			this.errorMessage = "Select the W_HPhone"
			return;
		}

		if (!this.report.W_HRoom) {
			this.errorMessage = "Select the W_HRoom"
			return;
		}

		if (!this.report.W_Name) {
			this.errorMessage = "Select the W_Name"
			return;
		}

		if (!this.report.TopMargin) {
			this.errorMessage = "Select the TopMargin"
			return;
		}

		if (!this.report.LeftMargin) {
			this.errorMessage = "Select the LeftMargin"
			return;
		}

		if (!this.report.ColumnSpace) {
			this.errorMessage = "Select the ColumnSpace"
			return;
		}

		if (!this.report.LabelHeight) {
			this.errorMessage = "Select the LabelHeight"
			return;
		}

      

        var strParam = "";
        this.isProcessing = true;
    
        //Insert Custom Parameters Here
        //Parameter 1: SchoolID
        strParam += this.report.SchoolID + "|SchoolID";

        //Parameter 2: GradeLevelID
        strParam += "," + this.report.GradeLevelID + "|GradeLevelID";

        //Parameter 3: ACADEMYID
        strParam += "," + this.report.ACADEMYID + "|ACADEMYID";

        //Parameter 4: HOMEROOMID
        strParam += "," + this.report.HOMEROOMID + "|HOMEROOMID";

        //Parameter 5: ORDERBY
        strParam += "," + this.report.ORDERBY + "|ORDERBY";

        //Parameter 6: W_ID
        strParam += "," + this.report.W_ID + "|W_ID";

        //Parameter 7: W_HPhone
        strParam += "," + this.report.W_HPhone + "|W_HPhone";

        //Parameter 8: W_HRoom
        strParam += "," + this.report.W_HRoom + "|W_HRoom";

        //Parameter 9: W_Name
        strParam += "," + this.report.W_Name + "|W_Name";

        //Parameter 10: TopMargin
        strParam += "," + this.report.TopMargin + "|TopMargin";

        //Parameter 11: LeftMargin
        strParam += "," + this.report.LeftMargin + "|LeftMargin";

        //Parameter 12: ColumnSpace
        strParam += "," + this.report.ColumnSpace + "|ColumnSpace";

        //Parameter 13: LabelHeight
        strParam += "," + this.report.LabelHeight + "|LabelHeight";



        var reportID = 347;

        var result = this.reportService.Print(reportID, strParam, this.report.SchoolID);

        result.subscribe(
            (response: any) => {
                component.isProcessing = false;
                window.open(response);
            },
            error => {
                component.errorMessage = error
                component.isProcessing = false;
            }
        )
    }
}

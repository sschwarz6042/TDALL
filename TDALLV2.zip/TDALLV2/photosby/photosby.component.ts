import { Component, OnInit, AfterViewInit } from '@angular/core';
import { ReportService } from '../report.service';
//Import Custom Services Here
import { SchoolService } from '../../../shared/services/school.service'
import { AcademyService } from '../../../shared/services/academy.service'
declare var moment: any;


@Component({
    templateUrl: './photosby.component.html',

})
export class PhotosbyComponent implements OnInit {
    constructor(
        private reportService: ReportService,
        //Insert Custom Services Here
        private academyService: AcademyService,
        private schoolService: SchoolService,

    ) {

    }
    report = {
        //Insert Custom Parameters Here
        SchoolID: 0,
        ByType: "",
        Columns: "",
        AcademyID: 0,
        PageByACAD: "",
        W_ID: "",
        W_HPhone: "",
        W_HRoom: "",
        W_DOB: "",
        W_Name: "",

    }
    //Insert Custom Lists Here
    SchoolList: any = []
    AcademyList: any = []
    

    user: any;
    errorMessage: any = "";
    isProcessing: any = false;
    
    ByTypeList = [
        //Insert Custom List Items Here
        {
			ByTypeName: 'Academy'
        },
        {
			ByTypeName: 'Grade'
        },
        {
			ByTypeName: 'Group'
        },
        {
			ByTypeName: 'Homeroom'
        },
        {
			ByTypeName: 'Instructor'
        },
        {
			ByTypeName: 'School'
        }

    ]

    
    ColumnsList = [
        //Insert Custom List Items Here
        {
			ColumnsName: '3'
        },
        {
			ColumnsName: '4'
        }

    ]

    
    PageByACADList = [
        //Insert Custom List Items Here
        {
			PageByACADName: 'Yes'
        },
        {
			PageByACADName: 'No'
        }

    ]

    
    W_List = [
        //Insert Custom List Items Here
        {
			W_Name: 'Yes'
        },
        {
			W_Name: 'No'
        }

    ]

    
    W_HPhoneList = [
        //Insert Custom List Items Here
        {
			W_HPhoneName: 'Yes'
        },
        {
			W_HPhoneName: 'No'
        }

    ]

    
    W_HRoomList = [
        //Insert Custom List Items Here
        {
			W_HRoomName: 'Yes'
        },
        {
			W_HRoomName: 'No'
        }

    ]

    
    W_DOBList = [
        //Insert Custom List Items Here
        {
			W_DOBName: 'Yes'
        },
        {
			W_DOBName: 'No'
        }

    ]

    
    W_NameList = [
        //Insert Custom List Items Here
        {
			W_NameName: 'Yes'
        },
        {
			W_NameName: 'No'
        }

    ]

    ngOnInit() {
        //Insert Custom Init Methods Here
        this.loadSchoolList()
        this.loadAcademyList()
               
      }
    
    private loadSchoolList() {
      
        this.report.SchoolID = 0;
        var result = this.schoolService.loadSchoolList(this.report.SchoolID);
        result.subscribe(
            response => {
                this.SchoolList = response;

                if (this.SchoolList.length > 1) {
                    this.SchoolList.unshift({
                        SchoolID: 0,
                        SchoolDesc: "All Schools"
                    })
                } else {
                    this.report.SchoolID = this.SchoolList[0].SchoolID
                }


            },
            error => {
            }
        )

    }
    
    private loadAcademyList() {
      
        this.report.AcademyID = 0;
        var result = this.academyService.loadAcademyList(this.report.SchoolID);
        result.subscribe(
            response => {
                this.AcademyList = response;

                if (this.AcademyList.length > 1) {
                    this.AcademyList.unshift({
                        AcademyID: 0,
                        AcademyDesc: "All Academys"
                    })
                } else {
                    this.report.AcademyID = this.AcademyList[0].AcademyID
                }


            },
            error => {
            }
        )

    }
    Print() {

        var component = this;
        this.errorMessage = "";

        //Insert Custom Error Checks Here
		if (!this.report.SchoolID) {
			this.errorMessage = "Select the School"
			return;
		}

		if (!this.report.ByType) {
			this.errorMessage = "Select the ByType"
			return;
		}

		if (!this.report.Columns) {
			this.errorMessage = "Select the Columns"
			return;
		}

		if (!this.report.AcademyID) {
			this.errorMessage = "Select the Academy"
			return;
		}

		if (!this.report.PageByACAD) {
			this.errorMessage = "Select the PageByACAD"
			return;
		}

		if (!this.report.W_ID) {
			this.errorMessage = "Select the W_"
			return;
		}

		if (!this.report.W_HPhone) {
			this.errorMessage = "Select the W_HPhone"
			return;
		}

		if (!this.report.W_HRoom) {
			this.errorMessage = "Select the W_HRoom"
			return;
		}

		if (!this.report.W_DOB) {
			this.errorMessage = "Select the W_DOB"
			return;
		}

		if (!this.report.W_Name) {
			this.errorMessage = "Select the W_Name"
			return;
		}

      

        var strParam = "";
        this.isProcessing = true;
    
        //Insert Custom Parameters Here
        //Parameter 1: SchoolID
        strParam += this.report.SchoolID + "|SchoolID";

        //Parameter 2: ByType
        strParam += "," + this.report.ByType + "|ByType";

        //Parameter 3: Columns
        strParam += "," + this.report.Columns + "|Columns";

        //Parameter 4: AcademyID
        strParam += "," + this.report.AcademyID + "|AcademyID";

        //Parameter 5: PageByACAD
        strParam += "," + this.report.PageByACAD + "|PageByACAD";

        //Parameter 6: W_ID
        strParam += "," + this.report.W_ID + "|W_ID";

        //Parameter 7: W_HPhone
        strParam += "," + this.report.W_HPhone + "|W_HPhone";

        //Parameter 8: W_HRoom
        strParam += "," + this.report.W_HRoom + "|W_HRoom";

        //Parameter 9: W_DOB
        strParam += "," + this.report.W_DOB + "|W_DOB";

        //Parameter 10: W_Name
        strParam += "," + this.report.W_Name + "|W_Name";



        var reportID = 214;

        var result = this.reportService.Print(reportID, strParam, this.report.SchoolID);

        result.subscribe(
            (response: any) => {
                component.isProcessing = false;
                window.open(response);
            },
            error => {
                component.errorMessage = error
                component.isProcessing = false;
            }
        )
    }
}

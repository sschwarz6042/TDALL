import { Component, OnInit, AfterViewInit } from '@angular/core';
import { ReportService } from '../report.service';
//Import Custom Services Here
declare var moment: any;


@Component({
    templateUrl: './principal/schoolstatistics.component.html',

})
export class Principal/SchoolStatisticsComponent implements OnInit {
    constructor(
        private reportService: ReportService,
        //Insert Custom Services Here

    ) {

    }
    report = {
        //Insert Custom Parameters Here
        RunDate: ,

    }
    //Insert Custom Lists Here
    

    user: any;
    errorMessage: any = "";
    isProcessing: any = false;
    ngOnInit() {
        //Insert Custom Init Methods Here
               
      }
    Print() {

        var component = this;
        this.errorMessage = "";

        //Insert Custom Error Checks Here
		if (!this.report.RunDate) {
			this.errorMessage = "Select the RunDate"
			return;
		}

      

        var strParam = "";
        this.isProcessing = true;
    
        //Insert Custom Parameters Here
        //Parameter 1: RunDate
        strParam +=  moment(this.report.RunDate).format("MM/DD/YYYY") + "|RunDate";



        var reportID = 399;

        var result = this.reportService.Print(reportID, strParam, 202);

        result.subscribe(
            (response: any) => {
                component.isProcessing = false;
                window.open(response);
            },
            error => {
                component.errorMessage = error
                component.isProcessing = false;
            }
        )
    }
}

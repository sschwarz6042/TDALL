import { Component, OnInit, AfterViewInit } from '@angular/core';
import { ReportService } from '../report.service';
//Import Custom Services Here
import { AttendanceStatusService } from '../../../shared/services/attendancestatus.service'
import { ScanStationService } from '../../../shared/services/scanstation.service'
declare var moment: any;


@Component({
    templateUrl: './scanstationattendance.component.html',

})
export class ScanStationAttendanceComponent implements OnInit {
    constructor(
        private reportService: ReportService,
        //Insert Custom Services Here
        private scanstationService: ScanStationService,
        private attendancestatusService: AttendanceStatusService,

    ) {

    }
    report = {
        //Insert Custom Parameters Here
        SchoolXML: "",
        GivenDate: ,
        AttendanceStatusID: 0,
        ScanStationID: "",
        ShowDetail: "",
        ImageLogo: 0,

    }
    //Insert Custom Lists Here
    AttendanceStatusList: any = []
    ScanStationList: any = []
    ImageLogoList: any = []
    

    user: any;
    errorMessage: any = "";
    isProcessing: any = false;
    
    ShowDetailList = [
        //Insert Custom List Items Here
        {
			ShowDetailName: 'No'
        },
        {
			ShowDetailName: 'Yes'
        }

    ]

    ngOnInit() {
        //Insert Custom Init Methods Here
        this.loadAttendanceStatusList()
        this.loadScanStationList()
               
      }
    
    private loadAttendanceStatusList() {
      
        this.report.AttendanceStatusID = 0;
        var result = this.attendanceStatusService.loadAttendanceStatusList(this.report.SchoolID);
        result.subscribe(
            response => {
                this.AttendanceStatusList = response;

                if (this.AttendanceStatusList.length > 1) {
                    this.AttendanceStatusList.unshift({
                        AttendanceStatusID: 0,
                        AttendanceStatusDesc: "All AttendanceStatuss"
                    })
                } else {
                    this.report.AttendanceStatusID = this.AttendanceStatusList[0].AttendanceStatusID
                }


            },
            error => {
            }
        )

    }
    
    private loadScanStationList() {
      
        this.report.ScanStationID = 0;
        var result = this.scanStationService.loadScanStationList(this.report.SchoolID);
        result.subscribe(
            response => {
                this.ScanStationList = response;

                if (this.ScanStationList.length > 1) {
                    this.ScanStationList.unshift({
                        ScanStationID: 0,
                        ScanStationDesc: "All ScanStations"
                    })
                } else {
                    this.report.ScanStationID = this.ScanStationList[0].ScanStationID
                }


            },
            error => {
            }
        )

    }
    Print() {

        var component = this;
        this.errorMessage = "";

        //Insert Custom Error Checks Here
		if (!this.report.SchoolXML) {
			this.errorMessage = "Select the SchoolXML"
			return;
		}

		if (!this.report.GivenDate) {
			this.errorMessage = "Select the GivenDate"
			return;
		}

		if (!this.report.AttendanceStatusID) {
			this.errorMessage = "Select the AttendanceStatus"
			return;
		}

		if (!this.report.ScanStationID) {
			this.errorMessage = "Select the ScanStation"
			return;
		}

		if (!this.report.ShowDetail) {
			this.errorMessage = "Select the ShowDetail"
			return;
		}

      

        var strParam = "";
        this.isProcessing = true;
    
        //Insert Custom Parameters Here
        //Parameter 1: SchoolXML
        strParam += this.report.SchoolXML + "|SchoolXML";

        //Parameter 2: GivenDate
        strParam += "," +  moment(this.report.GivenDate).format("MM/DD/YYYY") + "|GivenDate";

        //Parameter 3: AttendanceStatusID
        strParam += "," + this.report.AttendanceStatusID + "|AttendanceStatusID";

        //Parameter 4: ScanStationID
        strParam += "," + this.report.ScanStationID + "|ScanStationID";

        //Parameter 5: ShowDetail
        strParam += "," + this.report.ShowDetail + "|ShowDetail";

        //Parameter 6: ImageLogo
        strParam += ",8C87B20B-5813-4F74-8375-9898FD7B0C74|Imagelogo"



        var reportID = 25;

        var result = this.reportService.Print(reportID, strParam, this.report.SchoolID);

        result.subscribe(
            (response: any) => {
                component.isProcessing = false;
                window.open(response);
            },
            error => {
                component.errorMessage = error
                component.isProcessing = false;
            }
        )
    }
}

import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';
import { HttpclientService } from './httpclient.service';


@Injectable()
export class BalHiService {
    constructor(private httpclientService: HttpclientService) { }
    loadBalHiList(applicationItemID) {
      var postResult$ = new Subject();
      var url='Security/BalHiGetList?ApplicationItemID=' + applicationItemID;
      
      var promise$ = this.httpclientService.post(url, null);
      promise$.subscribe(response => {
        postResult$.next(response);
      }
      
      )
      return postResult$;
    }
}

import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';
import { HttpclientService } from './httpclient.service';


@Injectable()
export class ClassAttendanceEntryTypeService {
    constructor(private httpclientService: HttpclientService) { }
    loadClassAttendanceEntryTypeList(applicationItemID) {
      var postResult$ = new Subject();
      var url='Security/ClassAttendanceEntryTypeGetList?ApplicationItemID=' + applicationItemID;
      
      var promise$ = this.httpclientService.post(url, null);
      promise$.subscribe(response => {
        postResult$.next(response);
      }
      
      )
      return postResult$;
    }
}

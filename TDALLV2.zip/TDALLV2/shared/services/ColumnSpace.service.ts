import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';
import { HttpclientService } from './httpclient.service';


@Injectable()
export class ColumnSpaceService {
    constructor(private httpclientService: HttpclientService) { }
    loadColumnSpaceList(applicationItemID) {
      var postResult$ = new Subject();
      var url='Security/ColumnSpaceGetList?ApplicationItemID=' + applicationItemID;
      
      var promise$ = this.httpclientService.post(url, null);
      promise$.subscribe(response => {
        postResult$.next(response);
      }
      
      )
      return postResult$;
    }
}

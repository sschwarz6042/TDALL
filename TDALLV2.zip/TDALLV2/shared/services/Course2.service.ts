import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';
import { HttpclientService } from './httpclient.service';


@Injectable()
export class Course2Service {
    constructor(private httpclientService: HttpclientService) { }
    loadCourse2List(applicationItemID) {
      var postResult$ = new Subject();
      var url='Security/Course2GetList?ApplicationItemID=' + applicationItemID;
      
      var promise$ = this.httpclientService.post(url, null);
      promise$.subscribe(response => {
        postResult$.next(response);
      }
      
      )
      return postResult$;
    }
}

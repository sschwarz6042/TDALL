import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';
import { HttpclientService } from './httpclient.service';


@Injectable()
export class HomeroomService {
    constructor(private httpclientService: HttpclientService) { }
    loadHomeroomList(applicationItemID) {
      var postResult$ = new Subject();
      var url='Security/HomeroomGetList?ApplicationItemID=' + applicationItemID;
      
      var promise$ = this.httpclientService.post(url, null);
      promise$.subscribe(response => {
        postResult$.next(response);
      }
      
      )
      return postResult$;
    }
}

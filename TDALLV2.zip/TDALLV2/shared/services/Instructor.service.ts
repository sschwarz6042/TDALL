import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';
import { HttpclientService } from './httpclient.service';


@Injectable()
export class InstructorService {
    constructor(private httpclientService: HttpclientService) { }
    loadInstructorList(applicationItemID) {
      var postResult$ = new Subject();
      var url='Security/InstructorGetList?ApplicationItemID=' + applicationItemID;
      
      var promise$ = this.httpclientService.post(url, null);
      promise$.subscribe(response => {
        postResult$.next(response);
      }
      
      )
      return postResult$;
    }
}

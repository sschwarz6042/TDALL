import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';
import { HttpclientService } from './httpclient.service';


@Injectable()
export class InstructorPersonService {
    constructor(private httpclientService: HttpclientService) { }
    loadInstructorPersonList(applicationItemID) {
      var postResult$ = new Subject();
      var url='Security/InstructorPersonGetList?ApplicationItemID=' + applicationItemID;
      
      var promise$ = this.httpclientService.post(url, null);
      promise$.subscribe(response => {
        postResult$.next(response);
      }
      
      )
      return postResult$;
    }
}

import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';
import { HttpclientService } from './httpclient.service';


@Injectable()
export class LeftMarginService {
    constructor(private httpclientService: HttpclientService) { }
    loadLeftMarginList(applicationItemID) {
      var postResult$ = new Subject();
      var url='Security/LeftMarginGetList?ApplicationItemID=' + applicationItemID;
      
      var promise$ = this.httpclientService.post(url, null);
      promise$.subscribe(response => {
        postResult$.next(response);
      }
      
      )
      return postResult$;
    }
}

import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';
import { HttpclientService } from './httpclient.service';


@Injectable()
export class MTACardTypeService {
    constructor(private httpclientService: HttpclientService) { }
    loadMTACardTypeList(applicationItemID) {
      var postResult$ = new Subject();
      var url='Security/MTACardTypeGetList?ApplicationItemID=' + applicationItemID;
      
      var promise$ = this.httpclientService.post(url, null);
      promise$.subscribe(response => {
        postResult$.next(response);
      }
      
      )
      return postResult$;
    }
}

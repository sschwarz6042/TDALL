import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';
import { HttpclientService } from './httpclient.service';


@Injectable()
export class PeriodService {
    constructor(private httpclientService: HttpclientService) { }
    loadPeriodList(applicationItemID) {
      var postResult$ = new Subject();
      var url='Security/PeriodGetList?ApplicationItemID=' + applicationItemID;
      
      var promise$ = this.httpclientService.post(url, null);
      promise$.subscribe(response => {
        postResult$.next(response);
      }
      
      )
      return postResult$;
    }
}

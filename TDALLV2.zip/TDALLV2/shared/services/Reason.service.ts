import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';
import { HttpclientService } from './httpclient.service';


@Injectable()
export class ReasonService {
    constructor(private httpclientService: HttpclientService) { }
    loadReasonList(applicationItemID) {
      var postResult$ = new Subject();
      var url='Security/ReasonGetList?ApplicationItemID=' + applicationItemID;
      
      var promise$ = this.httpclientService.post(url, null);
      promise$.subscribe(response => {
        postResult$.next(response);
      }
      
      )
      return postResult$;
    }
}

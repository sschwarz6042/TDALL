import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';
import { HttpclientService } from './httpclient.service';


@Injectable()
export class TeacherPersonService {
    constructor(private httpclientService: HttpclientService) { }
    loadTeacherPersonList(applicationItemID) {
      var postResult$ = new Subject();
      var url='Security/TeacherPersonGetList?ApplicationItemID=' + applicationItemID;
      
      var promise$ = this.httpclientService.post(url, null);
      promise$.subscribe(response => {
        postResult$.next(response);
      }
      
      )
      return postResult$;
    }
}

import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';
import { HttpclientService } from './httpclient.service';


@Injectable()
export class TopMarginService {
    constructor(private httpclientService: HttpclientService) { }
    loadTopMarginList(applicationItemID) {
      var postResult$ = new Subject();
      var url='Security/TopMarginGetList?ApplicationItemID=' + applicationItemID;
      
      var promise$ = this.httpclientService.post(url, null);
      promise$.subscribe(response => {
        postResult$.next(response);
      }
      
      )
      return postResult$;
    }
}

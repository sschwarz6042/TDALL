import { Component, OnInit, AfterViewInit } from '@angular/core';
import { ReportService } from '../report.service';
//Import Custom Services Here
import { NumberOfService } from '../../../shared/services/numberof.service'
declare var moment: any;


@Component({
    templateUrl: './studentabsent/tardyexcuses.component.html',

})
export class StudentAbsent/TardyExcusesComponent implements OnInit {
    constructor(
        private reportService: ReportService,
        //Insert Custom Services Here
        private numberofService: NumberOfService,

    ) {

    }
    report = {
        //Insert Custom Parameters Here
        SchoolXML: "",
        Status: "",
        STARTDATE: ,
        ENDDATE: ,
        NumberOf: 0,
        ORDERBY: "",
        WExcuse: "",
        ShowDetail: "",
        ImageLogo: 0,

    }
    //Insert Custom Lists Here
    NumberOfList: any = []
    ImageLogoList: any = []
    

    user: any;
    errorMessage: any = "";
    isProcessing: any = false;
    
    StatusList = [
        //Insert Custom List Items Here
        {
			StatusName: 'Absent'
        },
        {
			StatusName: 'Tardy'
        },
        {
			StatusName: 'Both'
        }

    ]

    
    ORDERBYList = [
        //Insert Custom List Items Here
        {
			ORDERBYName: 'Absent/Tardy'
        },
        {
			ORDERBYName: 'Count'
        },
        {
			ORDERBYName: 'Grade'
        },
        {
			ORDERBYName: 'Homeroom'
        },
        {
			ORDERBYName: 'Name'
        }

    ]

    
    WExcuseList = [
        //Insert Custom List Items Here
        {
			WExcuseName: 'Excused And Unexcused'
        },
        {
			WExcuseName: 'Excused Only'
        },
        {
			WExcuseName: 'Unexcused Only'
        }

    ]

    
    ShowDetailList = [
        //Insert Custom List Items Here
        {
			ShowDetailName: 'No'
        },
        {
			ShowDetailName: 'Yes'
        }

    ]

    ngOnInit() {
        //Insert Custom Init Methods Here
        this.loadNumberOfList()
               
      }
    
    private loadNumberOfList() {
      
        this.report.NumberOfID = 0;
        var result = this.numberOfService.loadNumberOfList(this.report.SchoolID);
        result.subscribe(
            response => {
                this.NumberOfList = response;

                if (this.NumberOfList.length > 1) {
                    this.NumberOfList.unshift({
                        NumberOfID: 0,
                        NumberOfDesc: "All NumberOfs"
                    })
                } else {
                    this.report.NumberOfID = this.NumberOfList[0].NumberOfID
                }


            },
            error => {
            }
        )

    }
    Print() {

        var component = this;
        this.errorMessage = "";

        //Insert Custom Error Checks Here
		if (!this.report.SchoolXML) {
			this.errorMessage = "Select the SchoolXML"
			return;
		}

		if (!this.report.Status) {
			this.errorMessage = "Select the Status"
			return;
		}

		if (!this.report.STARTDATE) {
			this.errorMessage = "Select the STARTDATE"
			return;
		}

		if (!this.report.ENDDATE) {
			this.errorMessage = "Select the ENDDATE"
			return;
		}

		if (!this.report.NumberOf) {
			this.errorMessage = "Select the NumberOf"
			return;
		}

		if (!this.report.ORDERBY) {
			this.errorMessage = "Select the ORDERBY"
			return;
		}

		if (!this.report.WExcuse) {
			this.errorMessage = "Select the WExcuse"
			return;
		}

		if (!this.report.ShowDetail) {
			this.errorMessage = "Select the ShowDetail"
			return;
		}

      

        var strParam = "";
        this.isProcessing = true;
    
        //Insert Custom Parameters Here
        //Parameter 1: SchoolXML
        strParam += this.report.SchoolXML + "|SchoolXML";

        //Parameter 2: Status
        strParam += "," + this.report.Status + "|Status";

        //Parameter 3: STARTDATE
        strParam += "," +  moment(this.report.STARTDATE).format("MM/DD/YYYY") + "|STARTDATE";

        //Parameter 4: ENDDATE
        strParam += "," +  moment(this.report.ENDDATE).format("MM/DD/YYYY") + "|ENDDATE";

        //Parameter 5: NumberOf
        strParam += "," + this.report.NumberOf + "|NumberOf";

        //Parameter 6: ORDERBY
        strParam += "," + this.report.ORDERBY + "|ORDERBY";

        //Parameter 7: WExcuse
        strParam += "," + this.report.WExcuse + "|WExcuse";

        //Parameter 8: ShowDetail
        strParam += "," + this.report.ShowDetail + "|ShowDetail";

        //Parameter 9: ImageLogo
        strParam += ",8C87B20B-5813-4F74-8375-9898FD7B0C74|Imagelogo"



        var reportID = 151;

        var result = this.reportService.Print(reportID, strParam, this.report.SchoolID);

        result.subscribe(
            (response: any) => {
                component.isProcessing = false;
                window.open(response);
            },
            error => {
                component.errorMessage = error
                component.isProcessing = false;
            }
        )
    }
}

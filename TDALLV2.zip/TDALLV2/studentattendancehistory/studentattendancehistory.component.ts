import { Component, OnInit, AfterViewInit } from '@angular/core';
import { ReportService } from '../report.service';
//Import Custom Services Here
import { PersonService } from '../../../shared/services/person.service'
declare var moment: any;


@Component({
    templateUrl: './studentattendancehistory.component.html',

})
export class StudentAttendanceHistoryComponent implements OnInit {
    constructor(
        private reportService: ReportService,
        //Insert Custom Services Here
        private personService: PersonService,

    ) {

    }
    report = {
        //Insert Custom Parameters Here
        PersonID: 0,
        EntryDate: ,

    }
    //Insert Custom Lists Here
    PersonList: any = []
    

    user: any;
    errorMessage: any = "";
    isProcessing: any = false;
    ngOnInit() {
        //Insert Custom Init Methods Here
        this.loadPersonList()
               
      }
    
    private loadPersonList() {
      
        this.report.PersonID = 0;
        var result = this.personService.loadPersonList(this.report.SchoolID);
        result.subscribe(
            response => {
                this.PersonList = response;

                if (this.PersonList.length > 1) {
                    this.PersonList.unshift({
                        PersonID: 0,
                        PersonDesc: "All Persons"
                    })
                } else {
                    this.report.PersonID = this.PersonList[0].PersonID
                }


            },
            error => {
            }
        )

    }
    Print() {

        var component = this;
        this.errorMessage = "";

        //Insert Custom Error Checks Here
		if (!this.report.PersonID) {
			this.errorMessage = "Select the Person"
			return;
		}

		if (!this.report.EntryDate) {
			this.errorMessage = "Select the EntryDate"
			return;
		}

      

        var strParam = "";
        this.isProcessing = true;
    
        //Insert Custom Parameters Here
        //Parameter 1: PersonID
        strParam += this.report.PersonID + "|PersonID";

        //Parameter 2: EntryDate
        strParam += "," +  moment(this.report.EntryDate).format("MM/DD/YYYY") + "|EntryDate";



        var reportID = 349;

        var result = this.reportService.Print(reportID, strParam, 202);

        result.subscribe(
            (response: any) => {
                component.isProcessing = false;
                window.open(response);
            },
            error => {
                component.errorMessage = error
                component.isProcessing = false;
            }
        )
    }
}

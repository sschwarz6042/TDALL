import { Component, OnInit, AfterViewInit } from '@angular/core';
import { ReportService } from '../report.service';
//Import Custom Services Here
import { AttendanceStatusService } from '../../../shared/services/attendancestatus.service'
import { PrimarySortService } from '../../../shared/services/primarysort.service'
import { SecondarySortService } from '../../../shared/services/secondarysort.service'
declare var moment: any;


@Component({
    templateUrl: './studentattendancestatus.component.html',

})
export class STUDENTATTENDANCESTATUSComponent implements OnInit {
    constructor(
        private reportService: ReportService,
        //Insert Custom Services Here
        private secondarysortService: SecondarySortService,
        private primarysortService: PrimarySortService,
        private attendancestatusService: AttendanceStatusService,

    ) {

    }
    report = {
        //Insert Custom Parameters Here
        EntryDate_Start: ,
        AttendanceStatusID: 0,
        PrimarySort: "",
        SecondarySort: "",

    }
    //Insert Custom Lists Here
    AttendanceStatusList: any = []
    PrimarySortList: any = []
    SecondarySortList: any = []
    

    user: any;
    errorMessage: any = "";
    isProcessing: any = false;
    ngOnInit() {
        //Insert Custom Init Methods Here
        this.loadAttendanceStatusList()
        this.loadPrimarySortList()
        this.loadSecondarySortList()
               
      }
    
    private loadAttendanceStatusList() {
      
        this.report.AttendanceStatusID = 0;
        var result = this.attendanceStatusService.loadAttendanceStatusList(this.report.SchoolID);
        result.subscribe(
            response => {
                this.AttendanceStatusList = response;

                if (this.AttendanceStatusList.length > 1) {
                    this.AttendanceStatusList.unshift({
                        AttendanceStatusID: 0,
                        AttendanceStatusDesc: "All AttendanceStatuss"
                    })
                } else {
                    this.report.AttendanceStatusID = this.AttendanceStatusList[0].AttendanceStatusID
                }


            },
            error => {
            }
        )

    }
    
    private loadPrimarySortList() {
      
        this.report.PrimarySortID = 0;
        var result = this.primarySortService.loadPrimarySortList(this.report.SchoolID);
        result.subscribe(
            response => {
                this.PrimarySortList = response;

                if (this.PrimarySortList.length > 1) {
                    this.PrimarySortList.unshift({
                        PrimarySortID: 0,
                        PrimarySortDesc: "All PrimarySorts"
                    })
                } else {
                    this.report.PrimarySortID = this.PrimarySortList[0].PrimarySortID
                }


            },
            error => {
            }
        )

    }
    
    private loadSecondarySortList() {
      
        this.report.SecondarySortID = 0;
        var result = this.secondarySortService.loadSecondarySortList(this.report.SchoolID);
        result.subscribe(
            response => {
                this.SecondarySortList = response;

                if (this.SecondarySortList.length > 1) {
                    this.SecondarySortList.unshift({
                        SecondarySortID: 0,
                        SecondarySortDesc: "All SecondarySorts"
                    })
                } else {
                    this.report.SecondarySortID = this.SecondarySortList[0].SecondarySortID
                }


            },
            error => {
            }
        )

    }
    Print() {

        var component = this;
        this.errorMessage = "";

        //Insert Custom Error Checks Here
		if (!this.report.EntryDate_Start) {
			this.errorMessage = "Select the EntryDate_Start"
			return;
		}

		if (!this.report.AttendanceStatusID) {
			this.errorMessage = "Select the AttendanceStatus"
			return;
		}

		if (!this.report.PrimarySort) {
			this.errorMessage = "Select the PrimarySort"
			return;
		}

		if (!this.report.SecondarySort) {
			this.errorMessage = "Select the SecondarySort"
			return;
		}

      

        var strParam = "";
        this.isProcessing = true;
    
        //Insert Custom Parameters Here
        //Parameter 1: EntryDate_Start
        strParam +=  moment(this.report.EntryDate_Start).format("MM/DD/YYYY") + "|EntryDate_Start";

        //Parameter 2: AttendanceStatusID
        strParam += "," + this.report.AttendanceStatusID + "|AttendanceStatusID";

        //Parameter 3: PrimarySort
        strParam += "," + this.report.PrimarySort + "|PrimarySort";

        //Parameter 4: SecondarySort
        strParam += "," + this.report.SecondarySort + "|SecondarySort";



        var reportID = 5321;

        var result = this.reportService.Print(reportID, strParam, 202);

        result.subscribe(
            (response: any) => {
                component.isProcessing = false;
                window.open(response);
            },
            error => {
                component.errorMessage = error
                component.isProcessing = false;
            }
        )
    }
}

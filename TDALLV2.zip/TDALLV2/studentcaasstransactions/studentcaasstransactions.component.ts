import { Component, OnInit, AfterViewInit } from '@angular/core';
import { ReportService } from '../report.service';
//Import Custom Services Here
import { DistrictSchoolService } from '../../../shared/services/districtschool.service'
import { MTACardTypeService } from '../../../shared/services/mtacardtype.service'
declare var moment: any;


@Component({
    templateUrl: './studentcaasstransactions.component.html',

})
export class StudentCaassTransactionsComponent implements OnInit {
    constructor(
        private reportService: ReportService,
        //Insert Custom Services Here
        private mtacardtypeService: MTACardTypeService,
        private districtschoolService: DistrictSchoolService,

    ) {

    }
    report = {
        //Insert Custom Parameters Here
        DistrictSchoolID: 0,
        MTACardTypeID: 0,
        StartDate: ,
        EndDate: ,
        SortBy: "",
        ImageLogo: 0,

    }
    //Insert Custom Lists Here
    DistrictSchoolList: any = []
    MTACardTypeList: any = []
    ImageLogoList: any = []
    

    user: any;
    errorMessage: any = "";
    isProcessing: any = false;
    
    SortByList = [
        //Insert Custom List Items Here
        {
			SortByName: 'Date'
        },
        {
			SortByName: 'Name'
        },
        {
			SortByName: 'Farebox'
        },
        {
			SortByName: 'Route/Station'
        },
        {
			SortByName: 'Attendance Status'
        }

    ]

    ngOnInit() {
        //Insert Custom Init Methods Here
        this.loadDistrictSchoolList()
        this.loadMTACardTypeList()
               
      }
    
    private loadDistrictSchoolList() {
      
        this.report.DistrictSchoolID = 0;
        var result = this.districtSchoolService.loadDistrictSchoolList(this.report.SchoolID);
        result.subscribe(
            response => {
                this.DistrictSchoolList = response;

                if (this.DistrictSchoolList.length > 1) {
                    this.DistrictSchoolList.unshift({
                        DistrictSchoolID: 0,
                        DistrictSchoolDesc: "All DistrictSchools"
                    })
                } else {
                    this.report.DistrictSchoolID = this.DistrictSchoolList[0].DistrictSchoolID
                }


            },
            error => {
            }
        )

    }
    
    private loadMTACardTypeList() {
      
        this.report.MTACardTypeID = 0;
        var result = this.mTACardTypeService.loadMTACardTypeList(this.report.SchoolID);
        result.subscribe(
            response => {
                this.MTACardTypeList = response;

                if (this.MTACardTypeList.length > 1) {
                    this.MTACardTypeList.unshift({
                        MTACardTypeID: 0,
                        MTACardTypeDesc: "All MTACardTypes"
                    })
                } else {
                    this.report.MTACardTypeID = this.MTACardTypeList[0].MTACardTypeID
                }


            },
            error => {
            }
        )

    }
    Print() {

        var component = this;
        this.errorMessage = "";

        //Insert Custom Error Checks Here
		if (!this.report.DistrictSchoolID) {
			this.errorMessage = "Select the DistrictSchool"
			return;
		}

		if (!this.report.MTACardTypeID) {
			this.errorMessage = "Select the MTACardType"
			return;
		}

		if (!this.report.StartDate) {
			this.errorMessage = "Select the StartDate"
			return;
		}

		if (!this.report.EndDate) {
			this.errorMessage = "Select the EndDate"
			return;
		}

		if (!this.report.SortBy) {
			this.errorMessage = "Select the SortBy"
			return;
		}

      

        var strParam = "";
        this.isProcessing = true;
    
        //Insert Custom Parameters Here
        //Parameter 1: DistrictSchoolID
        strParam += this.report.DistrictSchoolID + "|DistrictSchoolID";

        //Parameter 2: MTACardTypeID
        strParam += "," + this.report.MTACardTypeID + "|MTACardTypeID";

        //Parameter 3: StartDate
        strParam += "," +  moment(this.report.StartDate).format("MM/DD/YYYY") + "|StartDate";

        //Parameter 4: EndDate
        strParam += "," +  moment(this.report.EndDate).format("MM/DD/YYYY") + "|EndDate";

        //Parameter 5: SortBy
        strParam += "," + this.report.SortBy + "|SortBy";

        //Parameter 6: ImageLogo
        strParam += ",8C87B20B-5813-4F74-8375-9898FD7B0C74|Imagelogo"



        var reportID = 405;

        var result = this.reportService.Print(reportID, strParam, this.report.SchoolID);

        result.subscribe(
            (response: any) => {
                component.isProcessing = false;
                window.open(response);
            },
            error => {
                component.errorMessage = error
                component.isProcessing = false;
            }
        )
    }
}

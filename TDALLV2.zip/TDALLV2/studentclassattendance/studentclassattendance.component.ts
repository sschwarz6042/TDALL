import { Component, OnInit, AfterViewInit } from '@angular/core';
import { ReportService } from '../report.service';
//Import Custom Services Here
import { SemesterService } from '../../../shared/services/semester.service'
import { TeacherPersonService } from '../../../shared/services/teacherperson.service'
import { DayService } from '../../../shared/services/day.service'
import { PeriodService } from '../../../shared/services/period.service'
declare var moment: any;


@Component({
    templateUrl: './studentclassattendance.component.html',

})
export class StudentClassAttendanceComponent implements OnInit {
    constructor(
        private reportService: ReportService,
        //Insert Custom Services Here
        private periodService: PeriodService,
        private dayService: DayService,
        private teacherpersonService: TeacherPersonService,
        private semesterService: SemesterService,

    ) {

    }
    report = {
        //Insert Custom Parameters Here
        StudentID: "",
        SemesterID: 0,
        TeacherPersonID: 0,
        DayID: 0,
        PeriodID: 0,

    }
    //Insert Custom Lists Here
    SemesterList: any = []
    TeacherPersonList: any = []
    DayList: any = []
    PeriodList: any = []
    

    user: any;
    errorMessage: any = "";
    isProcessing: any = false;
    ngOnInit() {
        //Insert Custom Init Methods Here
        this.loadSemesterList()
        this.loadTeacherPersonList()
        this.loadDayList()
        this.loadPeriodList()
               
      }
    
    private loadSemesterList() {
      
        this.report.SemesterID = 0;
        var result = this.semesterService.loadSemesterList(this.report.SchoolID);
        result.subscribe(
            response => {
                this.SemesterList = response;

                if (this.SemesterList.length > 1) {
                    this.SemesterList.unshift({
                        SemesterID: 0,
                        SemesterDesc: "All Semesters"
                    })
                } else {
                    this.report.SemesterID = this.SemesterList[0].SemesterID
                }


            },
            error => {
            }
        )

    }
    
    private loadTeacherPersonList() {
      
        this.report.TeacherPersonID = 0;
        var result = this.teacherPersonService.loadTeacherPersonList(this.report.SchoolID);
        result.subscribe(
            response => {
                this.TeacherPersonList = response;

                if (this.TeacherPersonList.length > 1) {
                    this.TeacherPersonList.unshift({
                        TeacherPersonID: 0,
                        TeacherPersonDesc: "All TeacherPersons"
                    })
                } else {
                    this.report.TeacherPersonID = this.TeacherPersonList[0].TeacherPersonID
                }


            },
            error => {
            }
        )

    }
    
    private loadDayList() {
      
        this.report.DayID = 0;
        var result = this.dayService.loadDayList(this.report.SchoolID);
        result.subscribe(
            response => {
                this.DayList = response;

                if (this.DayList.length > 1) {
                    this.DayList.unshift({
                        DayID: 0,
                        DayDesc: "All Days"
                    })
                } else {
                    this.report.DayID = this.DayList[0].DayID
                }


            },
            error => {
            }
        )

    }
    
    private loadPeriodList() {
      
        this.report.PeriodID = 0;
        var result = this.periodService.loadPeriodList(this.report.SchoolID);
        result.subscribe(
            response => {
                this.PeriodList = response;

                if (this.PeriodList.length > 1) {
                    this.PeriodList.unshift({
                        PeriodID: 0,
                        PeriodDesc: "All Periods"
                    })
                } else {
                    this.report.PeriodID = this.PeriodList[0].PeriodID
                }


            },
            error => {
            }
        )

    }
    Print() {

        var component = this;
        this.errorMessage = "";

        //Insert Custom Error Checks Here
		if (!this.report.StudentID) {
			this.errorMessage = "Select the Student"
			return;
		}

		if (!this.report.SemesterID) {
			this.errorMessage = "Select the Semester"
			return;
		}

		if (!this.report.TeacherPersonID) {
			this.errorMessage = "Select the TeacherPerson"
			return;
		}

		if (!this.report.DayID) {
			this.errorMessage = "Select the Day"
			return;
		}

		if (!this.report.PeriodID) {
			this.errorMessage = "Select the Period"
			return;
		}

      

        var strParam = "";
        this.isProcessing = true;
    
        //Insert Custom Parameters Here
        //Parameter 1: StudentID
        strParam += this.report.StudentID + "|StudentID";

        //Parameter 2: SemesterID
        strParam += "," + this.report.SemesterID + "|SemesterID";

        //Parameter 3: TeacherPersonID
        strParam += "," + this.report.TeacherPersonID + "|TeacherPersonID";

        //Parameter 4: DayID
        strParam += "," + this.report.DayID + "|DayID";

        //Parameter 5: PeriodID
        strParam += "," + this.report.PeriodID + "|PeriodID";



        var reportID = 237;

        var result = this.reportService.Print(reportID, strParam, 202);

        result.subscribe(
            (response: any) => {
                component.isProcessing = false;
                window.open(response);
            },
            error => {
                component.errorMessage = error
                component.isProcessing = false;
            }
        )
    }
}

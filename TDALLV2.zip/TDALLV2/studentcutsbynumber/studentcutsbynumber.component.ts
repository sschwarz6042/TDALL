import { Component, OnInit, AfterViewInit } from '@angular/core';
import { ReportService } from '../report.service';
//Import Custom Services Here
import { NumCutsService } from '../../../shared/services/numcuts.service'
declare var moment: any;


@Component({
    templateUrl: './studentcutsbynumber.component.html',

})
export class StudentCutsbyNumberComponent implements OnInit {
    constructor(
        private reportService: ReportService,
        //Insert Custom Services Here
        private numcutsService: NumCutsService,

    ) {

    }
    report = {
        //Insert Custom Parameters Here
        SchoolXML: "",
        StartDate: ,
        EndDate: ,
        NumCuts: 0,
        OrderBy: "",
        ImageLogo: 0,

    }
    //Insert Custom Lists Here
    NumCutsList: any = []
    ImageLogoList: any = []
    

    user: any;
    errorMessage: any = "";
    isProcessing: any = false;
    
    OrderByList = [
        //Insert Custom List Items Here
        {
			OrderByName: 'Academy'
        },
        {
			OrderByName: 'Cuts'
        },
        {
			OrderByName: 'Grade'
        },
        {
			OrderByName: 'Homeroom'
        },
        {
			OrderByName: 'Name'
        }

    ]

    ngOnInit() {
        //Insert Custom Init Methods Here
        this.loadNumCutsList()
               
      }
    
    private loadNumCutsList() {
      
        this.report.NumCutsID = 0;
        var result = this.numCutsService.loadNumCutsList(this.report.SchoolID);
        result.subscribe(
            response => {
                this.NumCutsList = response;

                if (this.NumCutsList.length > 1) {
                    this.NumCutsList.unshift({
                        NumCutsID: 0,
                        NumCutsDesc: "All NumCutss"
                    })
                } else {
                    this.report.NumCutsID = this.NumCutsList[0].NumCutsID
                }


            },
            error => {
            }
        )

    }
    Print() {

        var component = this;
        this.errorMessage = "";

        //Insert Custom Error Checks Here
		if (!this.report.SchoolXML) {
			this.errorMessage = "Select the SchoolXML"
			return;
		}

		if (!this.report.StartDate) {
			this.errorMessage = "Select the StartDate"
			return;
		}

		if (!this.report.EndDate) {
			this.errorMessage = "Select the EndDate"
			return;
		}

		if (!this.report.NumCuts) {
			this.errorMessage = "Select the NumCuts"
			return;
		}

		if (!this.report.OrderBy) {
			this.errorMessage = "Select the OrderBy"
			return;
		}

      

        var strParam = "";
        this.isProcessing = true;
    
        //Insert Custom Parameters Here
        //Parameter 1: SchoolXML
        strParam += this.report.SchoolXML + "|SchoolXML";

        //Parameter 2: StartDate
        strParam += "," +  moment(this.report.StartDate).format("MM/DD/YYYY") + "|StartDate";

        //Parameter 3: EndDate
        strParam += "," +  moment(this.report.EndDate).format("MM/DD/YYYY") + "|EndDate";

        //Parameter 4: NumCuts
        strParam += "," + this.report.NumCuts + "|NumCuts";

        //Parameter 5: OrderBy
        strParam += "," + this.report.OrderBy + "|OrderBy";

        //Parameter 6: ImageLogo
        strParam += ",8C87B20B-5813-4F74-8375-9898FD7B0C74|Imagelogo"



        var reportID = 27;

        var result = this.reportService.Print(reportID, strParam, this.report.SchoolID);

        result.subscribe(
            (response: any) => {
                component.isProcessing = false;
                window.open(response);
            },
            error => {
                component.errorMessage = error
                component.isProcessing = false;
            }
        )
    }
}

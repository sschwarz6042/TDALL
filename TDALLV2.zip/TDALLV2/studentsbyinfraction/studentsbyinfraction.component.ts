import { Component, OnInit, AfterViewInit } from '@angular/core';
import { ReportService } from '../report.service';
//Import Custom Services Here
import { INFRACTIONService } from '../../../shared/services/infraction.service'
declare var moment: any;


@Component({
    templateUrl: './studentsbyinfraction.component.html',

})
export class StudentsbyInfractionComponent implements OnInit {
    constructor(
        private reportService: ReportService,
        //Insert Custom Services Here
        private infractionService: INFRACTIONService,

    ) {

    }
    report = {
        //Insert Custom Parameters Here
        SchoolXML: "",
        INFRACTIONID: 0,
        STARTDATE: ,
        ENDDATE: ,
        ShowDetail: "",
        ORDERBY: "",
        ImageLogo: 0,

    }
    //Insert Custom Lists Here
    INFRACTIONList: any = []
    ImageLogoList: any = []
    

    user: any;
    errorMessage: any = "";
    isProcessing: any = false;
    
    ShowDetailList = [
        //Insert Custom List Items Here
        {
			ShowDetailName: 'No'
        },
        {
			ShowDetailName: 'Yes'
        }

    ]

    
    ORDERBYList = [
        //Insert Custom List Items Here
        {
			ORDERBYName: 'Date'
        },
        {
			ORDERBYName: 'Grade'
        },
        {
			ORDERBYName: 'Homeroom'
        },
        {
			ORDERBYName: 'Infraction'
        },
        {
			ORDERBYName: 'Name'
        },
        {
			ORDERBYName: 'Penalty'
        }

    ]

    ngOnInit() {
        //Insert Custom Init Methods Here
        this.loadINFRACTIONList()
               
      }
    
    private loadINFRACTIONList() {
      
        this.report.INFRACTIONID = 0;
        var result = this.iNFRACTIONService.loadINFRACTIONList(this.report.SchoolID);
        result.subscribe(
            response => {
                this.INFRACTIONList = response;

                if (this.INFRACTIONList.length > 1) {
                    this.INFRACTIONList.unshift({
                        INFRACTIONID: 0,
                        INFRACTIONDesc: "All INFRACTIONs"
                    })
                } else {
                    this.report.INFRACTIONID = this.INFRACTIONList[0].INFRACTIONID
                }


            },
            error => {
            }
        )

    }
    Print() {

        var component = this;
        this.errorMessage = "";

        //Insert Custom Error Checks Here
		if (!this.report.SchoolXML) {
			this.errorMessage = "Select the SchoolXML"
			return;
		}

		if (!this.report.INFRACTIONID) {
			this.errorMessage = "Select the INFRACTION"
			return;
		}

		if (!this.report.STARTDATE) {
			this.errorMessage = "Select the STARTDATE"
			return;
		}

		if (!this.report.ENDDATE) {
			this.errorMessage = "Select the ENDDATE"
			return;
		}

		if (!this.report.ShowDetail) {
			this.errorMessage = "Select the ShowDetail"
			return;
		}

		if (!this.report.ORDERBY) {
			this.errorMessage = "Select the ORDERBY"
			return;
		}

      

        var strParam = "";
        this.isProcessing = true;
    
        //Insert Custom Parameters Here
        //Parameter 1: SchoolXML
        strParam += this.report.SchoolXML + "|SchoolXML";

        //Parameter 2: INFRACTIONID
        strParam += "," + this.report.INFRACTIONID + "|INFRACTIONID";

        //Parameter 3: STARTDATE
        strParam += "," +  moment(this.report.STARTDATE).format("MM/DD/YYYY") + "|STARTDATE";

        //Parameter 4: ENDDATE
        strParam += "," +  moment(this.report.ENDDATE).format("MM/DD/YYYY") + "|ENDDATE";

        //Parameter 5: ShowDetail
        strParam += "," + this.report.ShowDetail + "|ShowDetail";

        //Parameter 6: ORDERBY
        strParam += "," + this.report.ORDERBY + "|ORDERBY";

        //Parameter 7: ImageLogo
        strParam += ",8C87B20B-5813-4F74-8375-9898FD7B0C74|Imagelogo"



        var reportID = 155;

        var result = this.reportService.Print(reportID, strParam, this.report.SchoolID);

        result.subscribe(
            (response: any) => {
                component.isProcessing = false;
                window.open(response);
            },
            error => {
                component.errorMessage = error
                component.isProcessing = false;
            }
        )
    }
}

import { Component, OnInit, AfterViewInit } from '@angular/core';
import { ReportService } from '../report.service';
//Import Custom Services Here
import { GradeLevelService } from '../../../shared/services/gradelevel.service'
import { AcademyService } from '../../../shared/services/academy.service'
import { HomeroomService } from '../../../shared/services/homeroom.service'
import { SemesterService } from '../../../shared/services/semester.service'
import { DayService } from '../../../shared/services/day.service'
declare var moment: any;


@Component({
    templateUrl: './studentschedulelabels.component.html',

})
export class StudentScheduleLabelsComponent implements OnInit {
    constructor(
        private reportService: ReportService,
        //Insert Custom Services Here
        private dayService: DayService,
        private semesterService: SemesterService,
        private homeroomService: HomeroomService,
        private academyService: AcademyService,
        private gradelevelService: GradeLevelService,

    ) {

    }
    report = {
        //Insert Custom Parameters Here
        GradeLevelID: 0,
        AcademyID: 0,
        HomeroomID: 0,
        SemesterID: 0,
        DayID: 0,
        OrderBy: "",

    }
    //Insert Custom Lists Here
    GradeLevelList: any = []
    AcademyList: any = []
    HomeroomList: any = []
    SemesterList: any = []
    DayList: any = []
    

    user: any;
    errorMessage: any = "";
    isProcessing: any = false;
    
    OrderByList = [
        //Insert Custom List Items Here
        {
			OrderByName: 'Period Description'
        },
        {
			OrderByName: 'Start Time'
        }

    ]

    ngOnInit() {
        //Insert Custom Init Methods Here
        this.loadGradeLevelList()
        this.loadAcademyList()
        this.loadHomeroomList()
        this.loadSemesterList()
        this.loadDayList()
               
      }
    
    private loadGradeLevelList() {
      
        this.report.GradeLevelID = 0;
        var result = this.gradeLevelService.loadGradeLevelList(this.report.SchoolID);
        result.subscribe(
            response => {
                this.GradeLevelList = response;

                if (this.GradeLevelList.length > 1) {
                    this.GradeLevelList.unshift({
                        GradeLevelID: 0,
                        GradeLevelDesc: "All GradeLevels"
                    })
                } else {
                    this.report.GradeLevelID = this.GradeLevelList[0].GradeLevelID
                }


            },
            error => {
            }
        )

    }
    
    private loadAcademyList() {
      
        this.report.AcademyID = 0;
        var result = this.academyService.loadAcademyList(this.report.SchoolID);
        result.subscribe(
            response => {
                this.AcademyList = response;

                if (this.AcademyList.length > 1) {
                    this.AcademyList.unshift({
                        AcademyID: 0,
                        AcademyDesc: "All Academys"
                    })
                } else {
                    this.report.AcademyID = this.AcademyList[0].AcademyID
                }


            },
            error => {
            }
        )

    }
    
    private loadHomeroomList() {
      
        this.report.HomeroomID = 0;
        var result = this.homeroomService.loadHomeroomList(this.report.SchoolID);
        result.subscribe(
            response => {
                this.HomeroomList = response;

                if (this.HomeroomList.length > 1) {
                    this.HomeroomList.unshift({
                        HomeroomID: 0,
                        HomeroomDesc: "All Homerooms"
                    })
                } else {
                    this.report.HomeroomID = this.HomeroomList[0].HomeroomID
                }


            },
            error => {
            }
        )

    }
    
    private loadSemesterList() {
      
        this.report.SemesterID = 0;
        var result = this.semesterService.loadSemesterList(this.report.SchoolID);
        result.subscribe(
            response => {
                this.SemesterList = response;

                if (this.SemesterList.length > 1) {
                    this.SemesterList.unshift({
                        SemesterID: 0,
                        SemesterDesc: "All Semesters"
                    })
                } else {
                    this.report.SemesterID = this.SemesterList[0].SemesterID
                }


            },
            error => {
            }
        )

    }
    
    private loadDayList() {
      
        this.report.DayID = 0;
        var result = this.dayService.loadDayList(this.report.SchoolID);
        result.subscribe(
            response => {
                this.DayList = response;

                if (this.DayList.length > 1) {
                    this.DayList.unshift({
                        DayID: 0,
                        DayDesc: "All Days"
                    })
                } else {
                    this.report.DayID = this.DayList[0].DayID
                }


            },
            error => {
            }
        )

    }
    Print() {

        var component = this;
        this.errorMessage = "";

        //Insert Custom Error Checks Here
		if (!this.report.GradeLevelID) {
			this.errorMessage = "Select the GradeLevel"
			return;
		}

		if (!this.report.AcademyID) {
			this.errorMessage = "Select the Academy"
			return;
		}

		if (!this.report.HomeroomID) {
			this.errorMessage = "Select the Homeroom"
			return;
		}

		if (!this.report.SemesterID) {
			this.errorMessage = "Select the Semester"
			return;
		}

		if (!this.report.DayID) {
			this.errorMessage = "Select the Day"
			return;
		}

		if (!this.report.OrderBy) {
			this.errorMessage = "Select the OrderBy"
			return;
		}

      

        var strParam = "";
        this.isProcessing = true;
    
        //Insert Custom Parameters Here
        //Parameter 1: GradeLevelID
        strParam += this.report.GradeLevelID + "|GradeLevelID";

        //Parameter 2: AcademyID
        strParam += "," + this.report.AcademyID + "|AcademyID";

        //Parameter 3: HomeroomID
        strParam += "," + this.report.HomeroomID + "|HomeroomID";

        //Parameter 4: SemesterID
        strParam += "," + this.report.SemesterID + "|SemesterID";

        //Parameter 5: DayID
        strParam += "," + this.report.DayID + "|DayID";

        //Parameter 6: OrderBy
        strParam += "," + this.report.OrderBy + "|OrderBy";



        var reportID = 232;

        var result = this.reportService.Print(reportID, strParam, 202);

        result.subscribe(
            (response: any) => {
                component.isProcessing = false;
                window.open(response);
            },
            error => {
                component.errorMessage = error
                component.isProcessing = false;
            }
        )
    }
}

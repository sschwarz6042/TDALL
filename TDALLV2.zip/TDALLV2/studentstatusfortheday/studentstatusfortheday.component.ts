import { Component, OnInit, AfterViewInit } from '@angular/core';
import { ReportService } from '../report.service';
//Import Custom Services Here
import { AttendanceStatusService } from '../../../shared/services/attendancestatus.service'
import { GradeLevelService } from '../../../shared/services/gradelevel.service'
import { HomeroomService } from '../../../shared/services/homeroom.service'
import { GroupService } from '../../../shared/services/group.service'
declare var moment: any;


@Component({
    templateUrl: './studentstatusfortheday.component.html',

})
export class StudentStatusforthedayComponent implements OnInit {
    constructor(
        private reportService: ReportService,
        //Insert Custom Services Here
        private groupService: GroupService,
        private homeroomService: HomeroomService,
        private gradelevelService: GradeLevelService,
        private attendancestatusService: AttendanceStatusService,

    ) {

    }
    report = {
        //Insert Custom Parameters Here
        SchoolXML: "",
        AttendanceStatusID: "",
        GradeLevelID: 0,
        HomeroomID: 0,
        GroupID: 0,
        GivenDate: ,
        ShowDetail: "",
        OrderBy: "",
        ImageLogo: 0,

    }
    //Insert Custom Lists Here
    AttendanceStatusList: any = []
    GradeLevelList: any = []
    HomeroomList: any = []
    GroupList: any = []
    ImageLogoList: any = []
    

    user: any;
    errorMessage: any = "";
    isProcessing: any = false;
    
    ShowDetailList = [
        //Insert Custom List Items Here
        {
			ShowDetailName: 'No'
        },
        {
			ShowDetailName: 'Yes'
        }

    ]

    
    OrderByList = [
        //Insert Custom List Items Here
        {
			OrderByName: 'Attendance Status'
        },
        {
			OrderByName: 'Grade'
        },
        {
			OrderByName: 'Homeroom'
        },
        {
			OrderByName: 'Name'
        }

    ]

    ngOnInit() {
        //Insert Custom Init Methods Here
        this.loadAttendanceStatusList()
        this.loadGradeLevelList()
        this.loadHomeroomList()
        this.loadGroupList()
               
      }
    
    private loadAttendanceStatusList() {
      
        this.report.AttendanceStatusID = 0;
        var result = this.attendanceStatusService.loadAttendanceStatusList(this.report.SchoolID);
        result.subscribe(
            response => {
                this.AttendanceStatusList = response;

                if (this.AttendanceStatusList.length > 1) {
                    this.AttendanceStatusList.unshift({
                        AttendanceStatusID: 0,
                        AttendanceStatusDesc: "All AttendanceStatuss"
                    })
                } else {
                    this.report.AttendanceStatusID = this.AttendanceStatusList[0].AttendanceStatusID
                }


            },
            error => {
            }
        )

    }
    
    private loadGradeLevelList() {
      
        this.report.GradeLevelID = 0;
        var result = this.gradeLevelService.loadGradeLevelList(this.report.SchoolID);
        result.subscribe(
            response => {
                this.GradeLevelList = response;

                if (this.GradeLevelList.length > 1) {
                    this.GradeLevelList.unshift({
                        GradeLevelID: 0,
                        GradeLevelDesc: "All GradeLevels"
                    })
                } else {
                    this.report.GradeLevelID = this.GradeLevelList[0].GradeLevelID
                }


            },
            error => {
            }
        )

    }
    
    private loadHomeroomList() {
      
        this.report.HomeroomID = 0;
        var result = this.homeroomService.loadHomeroomList(this.report.SchoolID);
        result.subscribe(
            response => {
                this.HomeroomList = response;

                if (this.HomeroomList.length > 1) {
                    this.HomeroomList.unshift({
                        HomeroomID: 0,
                        HomeroomDesc: "All Homerooms"
                    })
                } else {
                    this.report.HomeroomID = this.HomeroomList[0].HomeroomID
                }


            },
            error => {
            }
        )

    }
    
    private loadGroupList() {
      
        this.report.GroupID = 0;
        var result = this.groupService.loadGroupList(this.report.SchoolID);
        result.subscribe(
            response => {
                this.GroupList = response;

                if (this.GroupList.length > 1) {
                    this.GroupList.unshift({
                        GroupID: 0,
                        GroupDesc: "All Groups"
                    })
                } else {
                    this.report.GroupID = this.GroupList[0].GroupID
                }


            },
            error => {
            }
        )

    }
    Print() {

        var component = this;
        this.errorMessage = "";

        //Insert Custom Error Checks Here
		if (!this.report.SchoolXML) {
			this.errorMessage = "Select the SchoolXML"
			return;
		}

		if (!this.report.AttendanceStatusID) {
			this.errorMessage = "Select the AttendanceStatus"
			return;
		}

		if (!this.report.GradeLevelID) {
			this.errorMessage = "Select the GradeLevel"
			return;
		}

		if (!this.report.HomeroomID) {
			this.errorMessage = "Select the Homeroom"
			return;
		}

		if (!this.report.GroupID) {
			this.errorMessage = "Select the Group"
			return;
		}

		if (!this.report.GivenDate) {
			this.errorMessage = "Select the GivenDate"
			return;
		}

		if (!this.report.ShowDetail) {
			this.errorMessage = "Select the ShowDetail"
			return;
		}

		if (!this.report.OrderBy) {
			this.errorMessage = "Select the OrderBy"
			return;
		}

      

        var strParam = "";
        this.isProcessing = true;
    
        //Insert Custom Parameters Here
        //Parameter 1: SchoolXML
        strParam += this.report.SchoolXML + "|SchoolXML";

        //Parameter 2: AttendanceStatusID
        strParam += "," + this.report.AttendanceStatusID + "|AttendanceStatusID";

        //Parameter 3: GradeLevelID
        strParam += "," + this.report.GradeLevelID + "|GradeLevelID";

        //Parameter 4: HomeroomID
        strParam += "," + this.report.HomeroomID + "|HomeroomID";

        //Parameter 5: GroupID
        strParam += "," + this.report.GroupID + "|GroupID";

        //Parameter 6: GivenDate
        strParam += "," +  moment(this.report.GivenDate).format("MM/DD/YYYY") + "|GivenDate";

        //Parameter 7: ShowDetail
        strParam += "," + this.report.ShowDetail + "|ShowDetail";

        //Parameter 8: OrderBy
        strParam += "," + this.report.OrderBy + "|OrderBy";

        //Parameter 9: ImageLogo
        strParam += ",8C87B20B-5813-4F74-8375-9898FD7B0C74|Imagelogo"



        var reportID = 18;

        var result = this.reportService.Print(reportID, strParam, this.report.SchoolID);

        result.subscribe(
            (response: any) => {
                component.isProcessing = false;
                window.open(response);
            },
            error => {
                component.errorMessage = error
                component.isProcessing = false;
            }
        )
    }
}

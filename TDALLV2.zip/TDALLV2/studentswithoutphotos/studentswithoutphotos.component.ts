import { Component, OnInit, AfterViewInit } from '@angular/core';
import { ReportService } from '../report.service';
//Import Custom Services Here
import { SchoolService } from '../../../shared/services/school.service'
import { GradeLevelService } from '../../../shared/services/gradelevel.service'
import { AcademyService } from '../../../shared/services/academy.service'
import { HomeroomService } from '../../../shared/services/homeroom.service'
import { GroupService } from '../../../shared/services/group.service'
declare var moment: any;


@Component({
    templateUrl: './studentswithoutphotos.component.html',

})
export class StudentsWithoutPhotosComponent implements OnInit {
    constructor(
        private reportService: ReportService,
        //Insert Custom Services Here
        private groupService: GroupService,
        private homeroomService: HomeroomService,
        private academyService: AcademyService,
        private gradelevelService: GradeLevelService,
        private schoolService: SchoolService,

    ) {

    }
    report = {
        //Insert Custom Parameters Here
        SchoolID: 0,
        GradeLevelID: 0,
        AcademyID: 0,
        HomeroomID: 0,
        GroupID: 0,
        OrderBy: "",
        ImageLogo: 0,

    }
    //Insert Custom Lists Here
    SchoolList: any = []
    GradeLevelList: any = []
    AcademyList: any = []
    HomeroomList: any = []
    GroupList: any = []
    ImageLogoList: any = []
    

    user: any;
    errorMessage: any = "";
    isProcessing: any = false;
    
    OrderByList = [
        //Insert Custom List Items Here
        {
			OrderByName: 'Academy'
        },
        {
			OrderByName: 'Grade'
        },
        {
			OrderByName: 'Homeroom'
        },
        {
			OrderByName: 'Name'
        }

    ]

    ngOnInit() {
        //Insert Custom Init Methods Here
        this.loadSchoolList()
        this.loadGradeLevelList()
        this.loadAcademyList()
        this.loadHomeroomList()
        this.loadGroupList()
               
      }
    
    private loadSchoolList() {
      
        this.report.SchoolID = 0;
        var result = this.schoolService.loadSchoolList(this.report.SchoolID);
        result.subscribe(
            response => {
                this.SchoolList = response;

                if (this.SchoolList.length > 1) {
                    this.SchoolList.unshift({
                        SchoolID: 0,
                        SchoolDesc: "All Schools"
                    })
                } else {
                    this.report.SchoolID = this.SchoolList[0].SchoolID
                }


            },
            error => {
            }
        )

    }
    
    private loadGradeLevelList() {
      
        this.report.GradeLevelID = 0;
        var result = this.gradeLevelService.loadGradeLevelList(this.report.SchoolID);
        result.subscribe(
            response => {
                this.GradeLevelList = response;

                if (this.GradeLevelList.length > 1) {
                    this.GradeLevelList.unshift({
                        GradeLevelID: 0,
                        GradeLevelDesc: "All GradeLevels"
                    })
                } else {
                    this.report.GradeLevelID = this.GradeLevelList[0].GradeLevelID
                }


            },
            error => {
            }
        )

    }
    
    private loadAcademyList() {
      
        this.report.AcademyID = 0;
        var result = this.academyService.loadAcademyList(this.report.SchoolID);
        result.subscribe(
            response => {
                this.AcademyList = response;

                if (this.AcademyList.length > 1) {
                    this.AcademyList.unshift({
                        AcademyID: 0,
                        AcademyDesc: "All Academys"
                    })
                } else {
                    this.report.AcademyID = this.AcademyList[0].AcademyID
                }


            },
            error => {
            }
        )

    }
    
    private loadHomeroomList() {
      
        this.report.HomeroomID = 0;
        var result = this.homeroomService.loadHomeroomList(this.report.SchoolID);
        result.subscribe(
            response => {
                this.HomeroomList = response;

                if (this.HomeroomList.length > 1) {
                    this.HomeroomList.unshift({
                        HomeroomID: 0,
                        HomeroomDesc: "All Homerooms"
                    })
                } else {
                    this.report.HomeroomID = this.HomeroomList[0].HomeroomID
                }


            },
            error => {
            }
        )

    }
    
    private loadGroupList() {
      
        this.report.GroupID = 0;
        var result = this.groupService.loadGroupList(this.report.SchoolID);
        result.subscribe(
            response => {
                this.GroupList = response;

                if (this.GroupList.length > 1) {
                    this.GroupList.unshift({
                        GroupID: 0,
                        GroupDesc: "All Groups"
                    })
                } else {
                    this.report.GroupID = this.GroupList[0].GroupID
                }


            },
            error => {
            }
        )

    }
    Print() {

        var component = this;
        this.errorMessage = "";

        //Insert Custom Error Checks Here
		if (!this.report.SchoolID) {
			this.errorMessage = "Select the School"
			return;
		}

		if (!this.report.GradeLevelID) {
			this.errorMessage = "Select the GradeLevel"
			return;
		}

		if (!this.report.AcademyID) {
			this.errorMessage = "Select the Academy"
			return;
		}

		if (!this.report.HomeroomID) {
			this.errorMessage = "Select the Homeroom"
			return;
		}

		if (!this.report.GroupID) {
			this.errorMessage = "Select the Group"
			return;
		}

		if (!this.report.OrderBy) {
			this.errorMessage = "Select the OrderBy"
			return;
		}

      

        var strParam = "";
        this.isProcessing = true;
    
        //Insert Custom Parameters Here
        //Parameter 1: SchoolID
        strParam += this.report.SchoolID + "|SchoolID";

        //Parameter 2: GradeLevelID
        strParam += "," + this.report.GradeLevelID + "|GradeLevelID";

        //Parameter 3: AcademyID
        strParam += "," + this.report.AcademyID + "|AcademyID";

        //Parameter 4: HomeroomID
        strParam += "," + this.report.HomeroomID + "|HomeroomID";

        //Parameter 5: GroupID
        strParam += "," + this.report.GroupID + "|GroupID";

        //Parameter 6: OrderBy
        strParam += "," + this.report.OrderBy + "|OrderBy";

        //Parameter 7: ImageLogo
        strParam += ",8C87B20B-5813-4F74-8375-9898FD7B0C74|Imagelogo"



        var reportID = 22;

        var result = this.reportService.Print(reportID, strParam, this.report.SchoolID);

        result.subscribe(
            (response: any) => {
                component.isProcessing = false;
                window.open(response);
            },
            error => {
                component.errorMessage = error
                component.isProcessing = false;
            }
        )
    }
}

import { Component, OnInit, AfterViewInit } from '@angular/core';
import { ReportService } from '../report.service';
//Import Custom Services Here
import { SchoolService } from '../../../shared/services/school.service'
import { SemesterService } from '../../../shared/services/semester.service'
import { PeriodService } from '../../../shared/services/period.service'
import { MstrDateService } from '../../../shared/services/mstrdate.service'
import { InstructorService } from '../../../shared/services/instructor.service'
declare var moment: any;


@Component({
    templateUrl: './teacherattendanceverification.component.html',

})
export class TeacherAttendanceVerificationComponent implements OnInit {
    constructor(
        private reportService: ReportService,
        //Insert Custom Services Here
        private instructorService: InstructorService,
        private mstrdateService: MstrDateService,
        private periodService: PeriodService,
        private semesterService: SemesterService,
        private schoolService: SchoolService,

    ) {

    }
    report = {
        //Insert Custom Parameters Here
        SchoolID: 0,
        SemesterID: 0,
        PeriodID: 0,
        MstrDate: 0,
        InstructorID: 0,
        MPDateStart: ,
        MPDateEnd: ,
        ORDERBY: "",
        ImageLogo: 0,

    }
    //Insert Custom Lists Here
    SchoolList: any = []
    SemesterList: any = []
    PeriodList: any = []
    MstrDateList: any = []
    InstructorList: any = []
    ImageLogoList: any = []
    

    user: any;
    errorMessage: any = "";
    isProcessing: any = false;
    
    ORDERBYList = [
        //Insert Custom List Items Here
        {
			ORDERBYName: 'Course Number'
        },
        {
			ORDERBYName: 'Course Name'
        },
        {
			ORDERBYName: 'Instructor'
        },
        {
			ORDERBYName: 'Room Number'
        }

    ]

    ngOnInit() {
        //Insert Custom Init Methods Here
        this.loadSchoolList()
        this.loadSemesterList()
        this.loadPeriodList()
        this.loadMstrDateList()
        this.loadInstructorList()
               
      }
    
    private loadSchoolList() {
      
        this.report.SchoolID = 0;
        var result = this.schoolService.loadSchoolList(this.report.SchoolID);
        result.subscribe(
            response => {
                this.SchoolList = response;

                if (this.SchoolList.length > 1) {
                    this.SchoolList.unshift({
                        SchoolID: 0,
                        SchoolDesc: "All Schools"
                    })
                } else {
                    this.report.SchoolID = this.SchoolList[0].SchoolID
                }


            },
            error => {
            }
        )

    }
    
    private loadSemesterList() {
      
        this.report.SemesterID = 0;
        var result = this.semesterService.loadSemesterList(this.report.SchoolID);
        result.subscribe(
            response => {
                this.SemesterList = response;

                if (this.SemesterList.length > 1) {
                    this.SemesterList.unshift({
                        SemesterID: 0,
                        SemesterDesc: "All Semesters"
                    })
                } else {
                    this.report.SemesterID = this.SemesterList[0].SemesterID
                }


            },
            error => {
            }
        )

    }
    
    private loadPeriodList() {
      
        this.report.PeriodID = 0;
        var result = this.periodService.loadPeriodList(this.report.SchoolID);
        result.subscribe(
            response => {
                this.PeriodList = response;

                if (this.PeriodList.length > 1) {
                    this.PeriodList.unshift({
                        PeriodID: 0,
                        PeriodDesc: "All Periods"
                    })
                } else {
                    this.report.PeriodID = this.PeriodList[0].PeriodID
                }


            },
            error => {
            }
        )

    }
    
    private loadMstrDateList() {
      
        this.report.MstrDateID = 0;
        var result = this.mstrDateService.loadMstrDateList(this.report.SchoolID);
        result.subscribe(
            response => {
                this.MstrDateList = response;

                if (this.MstrDateList.length > 1) {
                    this.MstrDateList.unshift({
                        MstrDateID: 0,
                        MstrDateDesc: "All MstrDates"
                    })
                } else {
                    this.report.MstrDateID = this.MstrDateList[0].MstrDateID
                }


            },
            error => {
            }
        )

    }
    
    private loadInstructorList() {
      
        this.report.InstructorID = 0;
        var result = this.instructorService.loadInstructorList(this.report.SchoolID);
        result.subscribe(
            response => {
                this.InstructorList = response;

                if (this.InstructorList.length > 1) {
                    this.InstructorList.unshift({
                        InstructorID: 0,
                        InstructorDesc: "All Instructors"
                    })
                } else {
                    this.report.InstructorID = this.InstructorList[0].InstructorID
                }


            },
            error => {
            }
        )

    }
    Print() {

        var component = this;
        this.errorMessage = "";

        //Insert Custom Error Checks Here
		if (!this.report.SchoolID) {
			this.errorMessage = "Select the School"
			return;
		}

		if (!this.report.SemesterID) {
			this.errorMessage = "Select the Semester"
			return;
		}

		if (!this.report.PeriodID) {
			this.errorMessage = "Select the Period"
			return;
		}

		if (!this.report.MstrDate) {
			this.errorMessage = "Select the MstrDate"
			return;
		}

		if (!this.report.InstructorID) {
			this.errorMessage = "Select the Instructor"
			return;
		}

		if (!this.report.MPDateStart) {
			this.errorMessage = "Select the MPDateStart"
			return;
		}

		if (!this.report.MPDateEnd) {
			this.errorMessage = "Select the MPDateEnd"
			return;
		}

		if (!this.report.ORDERBY) {
			this.errorMessage = "Select the ORDERBY"
			return;
		}

      

        var strParam = "";
        this.isProcessing = true;
    
        //Insert Custom Parameters Here
        //Parameter 1: SchoolID
        strParam += this.report.SchoolID + "|SchoolID";

        //Parameter 2: SemesterID
        strParam += "," + this.report.SemesterID + "|SemesterID";

        //Parameter 3: PeriodID
        strParam += "," + this.report.PeriodID + "|PeriodID";

        //Parameter 4: MstrDate
        strParam += "," + this.report.MstrDate + "|MstrDate";

        //Parameter 5: InstructorID
        strParam += "," + this.report.InstructorID + "|InstructorID";

        //Parameter 6: MPDateStart
        strParam += "," +  moment(this.report.MPDateStart).format("MM/DD/YYYY") + "|MPDateStart";

        //Parameter 7: MPDateEnd
        strParam += "," +  moment(this.report.MPDateEnd).format("MM/DD/YYYY") + "|MPDateEnd";

        //Parameter 8: ORDERBY
        strParam += "," + this.report.ORDERBY + "|ORDERBY";

        //Parameter 9: ImageLogo
        strParam += ",8C87B20B-5813-4F74-8375-9898FD7B0C74|Imagelogo"



        var reportID = 223;

        var result = this.reportService.Print(reportID, strParam, this.report.SchoolID);

        result.subscribe(
            (response: any) => {
                component.isProcessing = false;
                window.open(response);
            },
            error => {
                component.errorMessage = error
                component.isProcessing = false;
            }
        )
    }
}

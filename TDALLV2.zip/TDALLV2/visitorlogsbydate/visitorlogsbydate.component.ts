import { Component, OnInit, AfterViewInit } from '@angular/core';
import { ReportService } from '../report.service';
//Import Custom Services Here
import { FacilityService } from '../../../shared/services/facility.service'
declare var moment: any;


@Component({
    templateUrl: './visitorlogsbydate.component.html',

})
export class VisitorLogsbyDateComponent implements OnInit {
    constructor(
        private reportService: ReportService,
        //Insert Custom Services Here
        private facilityService: FacilityService,

    ) {

    }
    report = {
        //Insert Custom Parameters Here
        FacilityID: 0,
        StartDate: ,
        EndDate: ,
        OrderBy: 0,
        ImageLogo: 0,
        UserID: "",

    }
    //Insert Custom Lists Here
    FacilityList: any = []
    ImageLogoList: any = []
    

    user: any;
    errorMessage: any = "";
    isProcessing: any = false;
    
    OrderByList = [
        //Insert Custom List Items Here
        {
			OrderByName: 'Date Ascending'
        },
        {
			OrderByName: 'Date Descending'
        }

    ]

    ngOnInit() {
        //Insert Custom Init Methods Here
        this.loadFacilityList()
               
      }
    
    private loadFacilityList() {
      
        this.report.FacilityID = 0;
        var result = this.facilityService.loadFacilityList(this.report.SchoolID);
        result.subscribe(
            response => {
                this.FacilityList = response;

                if (this.FacilityList.length > 1) {
                    this.FacilityList.unshift({
                        FacilityID: 0,
                        FacilityDesc: "All Facilitys"
                    })
                } else {
                    this.report.FacilityID = this.FacilityList[0].FacilityID
                }


            },
            error => {
            }
        )

    }
    Print() {

        var component = this;
        this.errorMessage = "";

        //Insert Custom Error Checks Here
		if (!this.report.FacilityID) {
			this.errorMessage = "Select the Facility"
			return;
		}

		if (!this.report.StartDate) {
			this.errorMessage = "Select the StartDate"
			return;
		}

		if (!this.report.EndDate) {
			this.errorMessage = "Select the EndDate"
			return;
		}

		if (!this.report.OrderBy) {
			this.errorMessage = "Select the OrderBy"
			return;
		}

		if (!this.report.UserID) {
			this.errorMessage = "Select the User"
			return;
		}

      

        var strParam = "";
        this.isProcessing = true;
    
        //Insert Custom Parameters Here
        //Parameter 1: FacilityID
        strParam += this.report.FacilityID + "|FacilityID";

        //Parameter 2: StartDate
        strParam += "," +  moment(this.report.StartDate).format("MM/DD/YYYY") + "|StartDate";

        //Parameter 3: EndDate
        strParam += "," +  moment(this.report.EndDate).format("MM/DD/YYYY") + "|EndDate";

        //Parameter 4: OrderBy
        strParam += "," + this.report.OrderBy + "|OrderBy";

        //Parameter 5: ImageLogo
        strParam += ",8C87B20B-5813-4F74-8375-9898FD7B0C74|Imagelogo"

        //Parameter 6: UserID
        strParam += "," + this.report.UserID + "|UserID";



        var reportID = 380;

        var result = this.reportService.Print(reportID, strParam, 202);

        result.subscribe(
            (response: any) => {
                component.isProcessing = false;
                window.open(response);
            },
            error => {
                component.errorMessage = error
                component.isProcessing = false;
            }
        )
    }
}

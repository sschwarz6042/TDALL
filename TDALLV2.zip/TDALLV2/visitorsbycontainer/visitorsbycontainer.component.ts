import { Component, OnInit, AfterViewInit } from '@angular/core';
import { ReportService } from '../report.service';
//Import Custom Services Here
import { SchoolGroupService } from '../../../shared/services/schoolgroup.service'
import { VisitorStatusService } from '../../../shared/services/visitorstatus.service'
import { VisitorTypeService } from '../../../shared/services/visitortype.service'
declare var moment: any;


@Component({
    templateUrl: './visitorsbycontainer.component.html',

})
export class VisitorsbyContainerComponent implements OnInit {
    constructor(
        private reportService: ReportService,
        //Insert Custom Services Here
        private visitortypeService: VisitorTypeService,
        private visitorstatusService: VisitorStatusService,
        private schoolgroupService: SchoolGroupService,

    ) {

    }
    report = {
        //Insert Custom Parameters Here
        SchoolGroupID: 0,
        StartDate: ,
        EndDate: ,
        Period: 0,
        VisitorStatusID: 0,
        VisitorTypeID: 0,
        ShowDetail: "",
        ImageLogo: 0,
        UserID: "",

    }
    //Insert Custom Lists Here
    SchoolGroupList: any = []
    VisitorStatusList: any = []
    VisitorTypeList: any = []
    ImageLogoList: any = []
    

    user: any;
    errorMessage: any = "";
    isProcessing: any = false;
    
    PeriodList = [
        //Insert Custom List Items Here
        {
			PeriodName: 'Today'
        },
        {
			PeriodName: 'Current week'
        },
        {
			PeriodName: 'Current month'
        },
        {
			PeriodName: 'Date range'
        }

    ]

    
    ShowDetailList = [
        //Insert Custom List Items Here
        {
			ShowDetailName: 'No'
        },
        {
			ShowDetailName: 'Yes'
        }

    ]

    ngOnInit() {
        //Insert Custom Init Methods Here
        this.loadSchoolGroupList()
        this.loadVisitorStatusList()
        this.loadVisitorTypeList()
               
      }
    
    private loadSchoolGroupList() {
      
        this.report.SchoolGroupID = 0;
        var result = this.schoolGroupService.loadSchoolGroupList(this.report.SchoolID);
        result.subscribe(
            response => {
                this.SchoolGroupList = response;

                if (this.SchoolGroupList.length > 1) {
                    this.SchoolGroupList.unshift({
                        SchoolGroupID: 0,
                        SchoolGroupDesc: "All SchoolGroups"
                    })
                } else {
                    this.report.SchoolGroupID = this.SchoolGroupList[0].SchoolGroupID
                }


            },
            error => {
            }
        )

    }
    
    private loadVisitorStatusList() {
      
        this.report.VisitorStatusID = 0;
        var result = this.visitorStatusService.loadVisitorStatusList(this.report.SchoolID);
        result.subscribe(
            response => {
                this.VisitorStatusList = response;

                if (this.VisitorStatusList.length > 1) {
                    this.VisitorStatusList.unshift({
                        VisitorStatusID: 0,
                        VisitorStatusDesc: "All VisitorStatuss"
                    })
                } else {
                    this.report.VisitorStatusID = this.VisitorStatusList[0].VisitorStatusID
                }


            },
            error => {
            }
        )

    }
    
    private loadVisitorTypeList() {
      
        this.report.VisitorTypeID = 0;
        var result = this.visitorTypeService.loadVisitorTypeList(this.report.SchoolID);
        result.subscribe(
            response => {
                this.VisitorTypeList = response;

                if (this.VisitorTypeList.length > 1) {
                    this.VisitorTypeList.unshift({
                        VisitorTypeID: 0,
                        VisitorTypeDesc: "All VisitorTypes"
                    })
                } else {
                    this.report.VisitorTypeID = this.VisitorTypeList[0].VisitorTypeID
                }


            },
            error => {
            }
        )

    }
    Print() {

        var component = this;
        this.errorMessage = "";

        //Insert Custom Error Checks Here
		if (!this.report.SchoolGroupID) {
			this.errorMessage = "Select the SchoolGroup"
			return;
		}

		if (!this.report.StartDate) {
			this.errorMessage = "Select the StartDate"
			return;
		}

		if (!this.report.EndDate) {
			this.errorMessage = "Select the EndDate"
			return;
		}

		if (!this.report.Period) {
			this.errorMessage = "Select the Period"
			return;
		}

		if (!this.report.VisitorStatusID) {
			this.errorMessage = "Select the VisitorStatus"
			return;
		}

		if (!this.report.VisitorTypeID) {
			this.errorMessage = "Select the VisitorType"
			return;
		}

		if (!this.report.ShowDetail) {
			this.errorMessage = "Select the ShowDetail"
			return;
		}

		if (!this.report.UserID) {
			this.errorMessage = "Select the User"
			return;
		}

      

        var strParam = "";
        this.isProcessing = true;
    
        //Insert Custom Parameters Here
        //Parameter 1: SchoolGroupID
        strParam += this.report.SchoolGroupID + "|SchoolGroupID";

        //Parameter 2: StartDate
        strParam += "," +  moment(this.report.StartDate).format("MM/DD/YYYY") + "|StartDate";

        //Parameter 3: EndDate
        strParam += "," +  moment(this.report.EndDate).format("MM/DD/YYYY") + "|EndDate";

        //Parameter 4: Period
        strParam += "," + this.report.Period + "|Period";

        //Parameter 5: VisitorStatusID
        strParam += "," + this.report.VisitorStatusID + "|VisitorStatusID";

        //Parameter 6: VisitorTypeID
        strParam += "," + this.report.VisitorTypeID + "|VisitorTypeID";

        //Parameter 7: ShowDetail
        strParam += "," + this.report.ShowDetail + "|ShowDetail";

        //Parameter 8: ImageLogo
        strParam += ",8C87B20B-5813-4F74-8375-9898FD7B0C74|Imagelogo"

        //Parameter 9: UserID
        strParam += "," + this.report.UserID + "|UserID";



        var reportID = 394;

        var result = this.reportService.Print(reportID, strParam, this.report.SchoolID);

        result.subscribe(
            (response: any) => {
                component.isProcessing = false;
                window.open(response);
            },
            error => {
                component.errorMessage = error
                component.isProcessing = false;
            }
        )
    }
}

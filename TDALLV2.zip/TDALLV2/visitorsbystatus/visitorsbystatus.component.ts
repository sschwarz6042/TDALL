import { Component, OnInit, AfterViewInit } from '@angular/core';
import { ReportService } from '../report.service';
//Import Custom Services Here
import { FacilityService } from '../../../shared/services/facility.service'
import { VisitorStatusService } from '../../../shared/services/visitorstatus.service'
import { VisitorTypeService } from '../../../shared/services/visitortype.service'
declare var moment: any;


@Component({
    templateUrl: './visitorsbystatus.component.html',

})
export class VisitorsbyStatusComponent implements OnInit {
    constructor(
        private reportService: ReportService,
        //Insert Custom Services Here
        private visitortypeService: VisitorTypeService,
        private visitorstatusService: VisitorStatusService,
        private facilityService: FacilityService,

    ) {

    }
    report = {
        //Insert Custom Parameters Here
        FacilityID: 0,
        StartDate: ,
        EndDate: ,
        VisitorStatusID: 0,
        VisitorTypeID: 0,
        ImageLogo: 0,
        UserID: "",

    }
    //Insert Custom Lists Here
    FacilityList: any = []
    VisitorStatusList: any = []
    VisitorTypeList: any = []
    ImageLogoList: any = []
    

    user: any;
    errorMessage: any = "";
    isProcessing: any = false;
    ngOnInit() {
        //Insert Custom Init Methods Here
        this.loadFacilityList()
        this.loadVisitorStatusList()
        this.loadVisitorTypeList()
               
      }
    
    private loadFacilityList() {
      
        this.report.FacilityID = 0;
        var result = this.facilityService.loadFacilityList(this.report.SchoolID);
        result.subscribe(
            response => {
                this.FacilityList = response;

                if (this.FacilityList.length > 1) {
                    this.FacilityList.unshift({
                        FacilityID: 0,
                        FacilityDesc: "All Facilitys"
                    })
                } else {
                    this.report.FacilityID = this.FacilityList[0].FacilityID
                }


            },
            error => {
            }
        )

    }
    
    private loadVisitorStatusList() {
      
        this.report.VisitorStatusID = 0;
        var result = this.visitorStatusService.loadVisitorStatusList(this.report.SchoolID);
        result.subscribe(
            response => {
                this.VisitorStatusList = response;

                if (this.VisitorStatusList.length > 1) {
                    this.VisitorStatusList.unshift({
                        VisitorStatusID: 0,
                        VisitorStatusDesc: "All VisitorStatuss"
                    })
                } else {
                    this.report.VisitorStatusID = this.VisitorStatusList[0].VisitorStatusID
                }


            },
            error => {
            }
        )

    }
    
    private loadVisitorTypeList() {
      
        this.report.VisitorTypeID = 0;
        var result = this.visitorTypeService.loadVisitorTypeList(this.report.SchoolID);
        result.subscribe(
            response => {
                this.VisitorTypeList = response;

                if (this.VisitorTypeList.length > 1) {
                    this.VisitorTypeList.unshift({
                        VisitorTypeID: 0,
                        VisitorTypeDesc: "All VisitorTypes"
                    })
                } else {
                    this.report.VisitorTypeID = this.VisitorTypeList[0].VisitorTypeID
                }


            },
            error => {
            }
        )

    }
    Print() {

        var component = this;
        this.errorMessage = "";

        //Insert Custom Error Checks Here
		if (!this.report.FacilityID) {
			this.errorMessage = "Select the Facility"
			return;
		}

		if (!this.report.StartDate) {
			this.errorMessage = "Select the StartDate"
			return;
		}

		if (!this.report.EndDate) {
			this.errorMessage = "Select the EndDate"
			return;
		}

		if (!this.report.VisitorStatusID) {
			this.errorMessage = "Select the VisitorStatus"
			return;
		}

		if (!this.report.VisitorTypeID) {
			this.errorMessage = "Select the VisitorType"
			return;
		}

		if (!this.report.UserID) {
			this.errorMessage = "Select the User"
			return;
		}

      

        var strParam = "";
        this.isProcessing = true;
    
        //Insert Custom Parameters Here
        //Parameter 1: FacilityID
        strParam += this.report.FacilityID + "|FacilityID";

        //Parameter 2: StartDate
        strParam += "," +  moment(this.report.StartDate).format("MM/DD/YYYY") + "|StartDate";

        //Parameter 3: EndDate
        strParam += "," +  moment(this.report.EndDate).format("MM/DD/YYYY") + "|EndDate";

        //Parameter 4: VisitorStatusID
        strParam += "," + this.report.VisitorStatusID + "|VisitorStatusID";

        //Parameter 5: VisitorTypeID
        strParam += "," + this.report.VisitorTypeID + "|VisitorTypeID";

        //Parameter 6: ImageLogo
        strParam += ",8C87B20B-5813-4F74-8375-9898FD7B0C74|Imagelogo"

        //Parameter 7: UserID
        strParam += "," + this.report.UserID + "|UserID";



        var reportID = 378;

        var result = this.reportService.Print(reportID, strParam, 202);

        result.subscribe(
            (response: any) => {
                component.isProcessing = false;
                window.open(response);
            },
            error => {
                component.errorMessage = error
                component.isProcessing = false;
            }
        )
    }
}

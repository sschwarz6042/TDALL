import { Component, OnInit, AfterViewInit } from '@angular/core';
import { ReportService } from '../report.service';
//Import Custom Services Here
import { FacilityService } from '../../../shared/services/facility.service'
declare var moment: any;


@Component({
    templateUrl: './visitorstoday.component.html',

})
export class VisitorsTodayComponent implements OnInit {
    constructor(
        private reportService: ReportService,
        //Insert Custom Services Here
        private facilityService: FacilityService,

    ) {

    }
    report = {
        //Insert Custom Parameters Here
        FacilityID: "",
        InFacility: "",
        ShowPhoto: "",
        OrderBy: "",
        ImageLogo: 0,
        UserID: "",

    }
    //Insert Custom Lists Here
    FacilityList: any = []
    ImageLogoList: any = []
    

    user: any;
    errorMessage: any = "";
    isProcessing: any = false;
    
    InFacilityList = [
        //Insert Custom List Items Here
        {
			InFacilityName: 'All'
        },
        {
			InFacilityName: 'Yes'
        },
        {
			InFacilityName: 'No'
        }

    ]

    
    ShowPhotoList = [
        //Insert Custom List Items Here
        {
			ShowPhotoName: 'Yes'
        },
        {
			ShowPhotoName: 'No'
        }

    ]

    
    OrderByList = [
        //Insert Custom List Items Here
        {
			OrderByName: 'Name'
        },
        {
			OrderByName: 'Comment'
        },
        {
			OrderByName: 'Company'
        },
        {
			OrderByName: 'Destination'
        },
        {
			OrderByName: 'Entry Location'
        }

    ]

    ngOnInit() {
        //Insert Custom Init Methods Here
        this.loadFacilityList()
               
      }
    
    private loadFacilityList() {
      
        this.report.FacilityID = 0;
        var result = this.facilityService.loadFacilityList(this.report.SchoolID);
        result.subscribe(
            response => {
                this.FacilityList = response;

                if (this.FacilityList.length > 1) {
                    this.FacilityList.unshift({
                        FacilityID: 0,
                        FacilityDesc: "All Facilitys"
                    })
                } else {
                    this.report.FacilityID = this.FacilityList[0].FacilityID
                }


            },
            error => {
            }
        )

    }
    Print() {

        var component = this;
        this.errorMessage = "";

        //Insert Custom Error Checks Here
		if (!this.report.FacilityID) {
			this.errorMessage = "Select the Facility"
			return;
		}

		if (!this.report.InFacility) {
			this.errorMessage = "Select the InFacility"
			return;
		}

		if (!this.report.ShowPhoto) {
			this.errorMessage = "Select the ShowPhoto"
			return;
		}

		if (!this.report.OrderBy) {
			this.errorMessage = "Select the OrderBy"
			return;
		}

		if (!this.report.UserID) {
			this.errorMessage = "Select the User"
			return;
		}

      

        var strParam = "";
        this.isProcessing = true;
    
        //Insert Custom Parameters Here
        //Parameter 1: FacilityID
        strParam += this.report.FacilityID + "|FacilityID";

        //Parameter 2: InFacility
        strParam += "," + this.report.InFacility + "|InFacility";

        //Parameter 3: ShowPhoto
        strParam += "," + this.report.ShowPhoto + "|ShowPhoto";

        //Parameter 4: OrderBy
        strParam += "," + this.report.OrderBy + "|OrderBy";

        //Parameter 5: ImageLogo
        strParam += ",8C87B20B-5813-4F74-8375-9898FD7B0C74|Imagelogo"

        //Parameter 6: UserID
        strParam += "," + this.report.UserID + "|UserID";



        var reportID = 391;

        var result = this.reportService.Print(reportID, strParam, 202);

        result.subscribe(
            (response: any) => {
                component.isProcessing = false;
                window.open(response);
            },
            error => {
                component.errorMessage = error
                component.isProcessing = false;
            }
        )
    }
}

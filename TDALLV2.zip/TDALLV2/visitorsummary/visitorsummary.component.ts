import { Component, OnInit, AfterViewInit } from '@angular/core';
import { ReportService } from '../report.service';
//Import Custom Services Here
import { SchoolGroupService } from '../../../shared/services/schoolgroup.service'
declare var moment: any;


@Component({
    templateUrl: './visitorsummary.component.html',

})
export class VisitorSummaryComponent implements OnInit {
    constructor(
        private reportService: ReportService,
        //Insert Custom Services Here
        private schoolgroupService: SchoolGroupService,

    ) {

    }
    report = {
        //Insert Custom Parameters Here
        SchoolGroupID: 0,
        StartDate: ,
        EndDate: ,
        Period: 0,
        SchoolVisitStatus: 0,
        ShowContainer: 0,
        OrderBy: "",
        ImageLogo: 0,
        UserID: "",

    }
    //Insert Custom Lists Here
    SchoolGroupList: any = []
    ImageLogoList: any = []
    

    user: any;
    errorMessage: any = "";
    isProcessing: any = false;
    
    PeriodList = [
        //Insert Custom List Items Here
        {
			PeriodName: 'Today'
        },
        {
			PeriodName: 'Current week'
        },
        {
			PeriodName: 'Current month'
        },
        {
			PeriodName: 'Date range'
        }

    ]

    
    SchoolVisitStatusList = [
        //Insert Custom List Items Here
        {
			SchoolVisitStatusName: 'All'
        },
        {
			SchoolVisitStatusName: 'Only with visitors'
        },
        {
			SchoolVisitStatusName: 'No visitors'
        }

    ]

    
    ShowContainerList = [
        //Insert Custom List Items Here
        {
			ShowContainerName: 'Yes'
        },
        {
			ShowContainerName: 'No'
        }

    ]

    
    OrderByList = [
        //Insert Custom List Items Here
        {
			OrderByName: 'container'
        },
        {
			OrderByName: 'school number'
        },
        {
			OrderByName: 'school name'
        },
        {
			OrderByName: 'visit count'
        },
        {
			OrderByName: 'require verification count'
        },
        {
			OrderByName: 'deny entry count'
        }

    ]

    ngOnInit() {
        //Insert Custom Init Methods Here
        this.loadSchoolGroupList()
               
      }
    
    private loadSchoolGroupList() {
      
        this.report.SchoolGroupID = 0;
        var result = this.schoolGroupService.loadSchoolGroupList(this.report.SchoolID);
        result.subscribe(
            response => {
                this.SchoolGroupList = response;

                if (this.SchoolGroupList.length > 1) {
                    this.SchoolGroupList.unshift({
                        SchoolGroupID: 0,
                        SchoolGroupDesc: "All SchoolGroups"
                    })
                } else {
                    this.report.SchoolGroupID = this.SchoolGroupList[0].SchoolGroupID
                }


            },
            error => {
            }
        )

    }
    Print() {

        var component = this;
        this.errorMessage = "";

        //Insert Custom Error Checks Here
		if (!this.report.SchoolGroupID) {
			this.errorMessage = "Select the SchoolGroup"
			return;
		}

		if (!this.report.StartDate) {
			this.errorMessage = "Select the StartDate"
			return;
		}

		if (!this.report.EndDate) {
			this.errorMessage = "Select the EndDate"
			return;
		}

		if (!this.report.Period) {
			this.errorMessage = "Select the Period"
			return;
		}

		if (!this.report.SchoolVisitStatus) {
			this.errorMessage = "Select the SchoolVisitStatus"
			return;
		}

		if (!this.report.ShowContainer) {
			this.errorMessage = "Select the ShowContainer"
			return;
		}

		if (!this.report.OrderBy) {
			this.errorMessage = "Select the OrderBy"
			return;
		}

		if (!this.report.UserID) {
			this.errorMessage = "Select the User"
			return;
		}

      

        var strParam = "";
        this.isProcessing = true;
    
        //Insert Custom Parameters Here
        //Parameter 1: SchoolGroupID
        strParam += this.report.SchoolGroupID + "|SchoolGroupID";

        //Parameter 2: StartDate
        strParam += "," +  moment(this.report.StartDate).format("MM/DD/YYYY") + "|StartDate";

        //Parameter 3: EndDate
        strParam += "," +  moment(this.report.EndDate).format("MM/DD/YYYY") + "|EndDate";

        //Parameter 4: Period
        strParam += "," + this.report.Period + "|Period";

        //Parameter 5: SchoolVisitStatus
        strParam += "," + this.report.SchoolVisitStatus + "|SchoolVisitStatus";

        //Parameter 6: ShowContainer
        strParam += "," + this.report.ShowContainer + "|ShowContainer";

        //Parameter 7: OrderBy
        strParam += "," + this.report.OrderBy + "|OrderBy";

        //Parameter 8: ImageLogo
        strParam += ",8C87B20B-5813-4F74-8375-9898FD7B0C74|Imagelogo"

        //Parameter 9: UserID
        strParam += "," + this.report.UserID + "|UserID";



        var reportID = 395;

        var result = this.reportService.Print(reportID, strParam, this.report.SchoolID);

        result.subscribe(
            (response: any) => {
                component.isProcessing = false;
                window.open(response);
            },
            error => {
                component.errorMessage = error
                component.isProcessing = false;
            }
        )
    }
}
